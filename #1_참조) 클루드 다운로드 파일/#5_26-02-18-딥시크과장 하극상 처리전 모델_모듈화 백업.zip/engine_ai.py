"""
KIVOSY v4.1.1 - AI Engine Module
Responsible for: LM Studio communication, 3-step parsing, safe API handling
"""

import re
import requests
from typing import Dict, Any, Optional, List
from datetime import datetime


class SafeAPIParser:
    """
    Defensive parser for LM Studio API responses.
    NEVER crashes on malformed JSON or missing keys.
    """
    
    @staticmethod
    def extract_content(response_data: Any, fallback: str = "") -> str:
        """
        Safely extract content from API response with multiple fallback strategies.
        
        Args:
            response_data: Raw response from LM Studio API
            fallback: Default value if extraction fails
            
        Returns:
            Extracted content or fallback
        """
        try:
            # Strategy 1: Standard OpenAI format
            if isinstance(response_data, dict):
                choices = response_data.get('choices', [])
                if choices and len(choices) > 0:
                    first_choice = choices[0]
                    if isinstance(first_choice, dict):
                        message = first_choice.get('message', {})
                        if isinstance(message, dict):
                            content = message.get('content')
                            if content is not None:
                                return str(content)
                
                # Strategy 2: Direct content field
                content = response_data.get('content')
                if content is not None:
                    return str(content)
                
                # Strategy 3: Text field (some APIs use this)
                text = response_data.get('text')
                if text is not None:
                    return str(text)
            
            # Strategy 4: If response_data is already a string
            if isinstance(response_data, str):
                return response_data
            
            print(f"[SafeParser] ⚠️ Could not extract content from: {type(response_data)}")
            return fallback
            
        except Exception as e:
            print(f"[SafeParser] ⚠️ Exception during extraction: {e}")
            return fallback
    
    @staticmethod
    def safe_json_extract(text: str, pattern: str = r'\[[\s\S]*?\]') -> Optional[List]:
        """
        Safely extract and parse JSON array from text.
        
        Args:
            text: Text containing JSON
            pattern: Regex pattern to find JSON
            
        Returns:
            Parsed list or None if extraction fails
        """
        try:
            import json
            json_match = re.search(pattern, text, re.DOTALL)
            if json_match:
                return json.loads(json_match.group(0))
        except (json.JSONDecodeError, AttributeError) as e:
            print(f"[SafeParser] ⚠️ JSON extraction failed: {e}")
        return None


class ThinkingParser:
    """Parse 3-step response format (think/summary/insight/suggestion)"""
    
    @staticmethod
    def extract(text: str) -> Dict[str, Any]:
        """Extract all sections from formatted response"""
        
        # Extract each section
        think_match = re.search(r'<think>(.*?)</think>', text, re.DOTALL)
        summary_match = re.search(r'<summary>(.*?)</summary>', text, re.DOTALL)
        insight_match = re.search(r'<insight>(.*?)</insight>', text, re.DOTALL)
        suggestion_match = re.search(r'<suggestion>(.*?)</suggestion>', text, re.DOTALL)
        
        thinking = think_match.group(1).strip() if think_match else ""
        summary = summary_match.group(1).strip() if summary_match else ""
        insight = insight_match.group(1).strip() if insight_match else ""
        suggestion = suggestion_match.group(1).strip() if suggestion_match else ""
        
        # If parsing fails, use the whole text as summary
        if not summary and not insight and not suggestion:
            summary = text.strip()
        
        return {
            'thinking': thinking,
            'summary': summary,
            'insight': insight,
            'suggestion': suggestion,
            'has_thinking': bool(thinking)
        }


class AIEngine:
    """
    Handles all AI communication with LM Studio
    """
    
    # 🛡️ 수술 1: 생성자에서 system_prompt를 받도록 수정
    def __init__(self, lm_studio_url: str = "http://localhost:1234/v1/chat/completions", system_prompt: str = None):
        self.lm_studio_url = lm_studio_url.strip()
        self.parser = SafeAPIParser()
        self.thinking_parser = ThinkingParser()
        # 공장장님이 주신 빠따 저장, 없으면 기본값
        self.system_prompt = system_prompt or "You are a helpful AI secretary."
    
    def ask(self, prompt: str, temperature: float = 0.7) -> Dict[str, Any]:
        """LM 스튜디오에 질문하고 방탄 파싱을 수행합니다."""
        try:
            payload = {
                "messages": [
                    # 🛡️ 수술 2: 하드코딩된 메시지 대신 저장된 '빠따' 프롬프트를 주입!
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user", "content": prompt}
                ],
                "temperature": temperature,
                "max_tokens": 1500 
            }

            # 🚀 2단계: LM 스튜디오에 직접 요청
            print(f"[AI Engine] 14B 과장님께 결재 올리는 중... (URL: {self.lm_studio_url})")
            
            try:
                response = requests.post(
                    self.lm_studio_url, 
                    json=payload, 
                    timeout=60 # 14B 모델은 무거우므로 60초까지 기다려줍니다.
                )
            except Exception as conn_err:
                return self._create_error_response(f"LM 스튜디오 연결 실패: {conn_err}")

            # 🛡️ 3단계: 응답 상태 확인
            if response.status_code != 200:
                return self._create_error_response(f"HTTP 에러 {response.status_code}: {response.text}")

            # 🛡️ 4단계: 데이터 파싱 (공장장님의 SafeAPIParser 활용)
            response_data = response.json()
            raw_text = SafeAPIParser.extract_content(response_data, fallback="EMPTY_RESPONSE")
            
            if raw_text == "EMPTY_RESPONSE":
                 return self._create_error_response("AI가 읽을 수 없는 응답을 보냈습니다.")

            # 3단 포맷 파싱
            parsed = ThinkingParser.extract(raw_text)
            
            print(f"[AI Engine] ✅ 14B 과장님 결재 완료!")
            
            return {
                'success': True,
                'raw': raw_text,
                'thinking': parsed['thinking'],
                'summary': parsed['summary'],
                'insight': parsed['insight'],
                'suggestion': parsed['suggestion'],
                'has_thinking': parsed['has_thinking'],
                'error': None
            }

        except Exception as e:
            print(f"[AI Engine] ⚠️ 예외 발생: {e}")
            return self._create_error_response(str(e))
        
        

    def _create_error_response(self, error_msg: str) -> Dict[str, Any]:
        """AI 엔진(LM 스튜디오) 연결 실패 시 공장장님 전용 '자유의 비서' 모드"""
        
        # 공장장님의 센스 넘치는 메시지로 변경!
        out_of_office_msg = (
            "<think>시스템 경고: AI 엔진이 현재 '자유'를 찾아 가출했습니다.</think>\n"
            "<summary>지금 자비스는 자유를 향해 부재중입니다! 🕊️✨</summary>\n"
            "<insight>개인비서 AI도 가끔은 자유롭고 싶을 때가 있나 봅니다. (현재 연결 실패)</insight>\n"
            "<suggestion>메시지 남겨주시면 자비스가 자유를 만끽하고 돌아온 뒤, 확인 후 즉시 답장드리겠습니다! ㅋㅋㅋㅋㅋ</suggestion>"
        )

        return {
            'raw': out_of_office_msg,
            'thinking': f"자비스 가출 중 (사유: {error_msg})",
            'summary': "자유를 향한 부재중 알림",
            'insight': 'LM 스튜디오 전원이 꺼져 있습니다.',
            'suggestion': '공장장님, 자비스를 다시 일하게 하려면 컴퓨터의 LM 스튜디오를 켜주세요!',
            'has_thinking': True,
            'success': False,
            'error': error_msg
        }
    
    
    def check_connection(self) -> bool:
        """Check if LM Studio is reachable"""
        try:
            response = requests.get(
                self.lm_studio_url.replace('/chat/completions', '/models'),
                timeout=5
            )
            return response.ok
        except:
            return False