"""
KIVOSY v4.1.1 - Memory Processor Module
Responsible for: Memory management, preferences, learning extraction
"""

from datetime import datetime
import json
import os
import re
import uuid
from pathlib import Path
from typing import Dict, List, Optional, Any
import requests

# Import SafeParser from engine_ai (will be circular if we import here)
# We'll define a minimal version here and let engine_ai import the full version

class SafeParser:
    """Minimal safe parser for internal use"""
    @staticmethod
    def safe_json_extract(text: str, pattern: str = r'\[[\s\S]*?\]') -> Optional[List]:
        try:
            json_match = re.search(pattern, text)
            if json_match:
                return json.loads(json_match.group(0))
        except (json.JSONDecodeError, AttributeError) as e:
            print(f"[Memory.SafeParser] ⚠️ JSON extraction failed: {e}")
        return None


class MemorySystem:
    """
    v4.1.1 Enhanced PAI Memory System with Defensive Parsing
    
    FIXED in v4.1.1:
    - Defensive API response parsing (no more KeyError)
    - Safe JSON extraction
    - Graceful fallbacks for all LLM calls
    """
    
    def __init__(self, memory_dir: str = None):
        if memory_dir is None:
            BASE_DIR = os.path.dirname(os.path.abspath(__file__))
            memory_dir = os.path.join(BASE_DIR, 'memory')
        
        self.memory_dir = Path(memory_dir)
        self.preferences_file = self.memory_dir / 'preferences.json'
        self.learning_file = self.memory_dir / 'learning.json'
        self.session_file = self.memory_dir / 'session.json'
        
        self._ensure_memory_structure()
    
    def _ensure_memory_structure(self):
        """Initialize memory directory and files"""
        self.memory_dir.mkdir(exist_ok=True)
        
        # preferences.json (v4.1 enhanced)
        if not self.preferences_file.exists():
            default_preferences = {
                'version': '4.1.1',
                'created_at': datetime.now().isoformat(),
                'user': {
                    'name': '공장장',
                    'role': 'Factory Owner',
                    'timezone': 'Asia/Seoul',
                    'language': 'ko',
                    'communication_style': 'professional'
                },
                'ai': {
                    'response_style': 'proactive',
                    'thinking_display': True,
                    'tone': 'friendly-professional',
                    'secretary_mode': True
                },
                'preferences': {
                    'summary_length': 'medium',
                    'technical_depth': 'moderate',
                    'emoji_usage': True,
                    'proactive_suggestions': True
                }
            }
            self._save_json(self.preferences_file, default_preferences)
            print(f"✅ Created preferences.json (v4.1.1)")
        
        # learning.json (v4.1 enhanced)
        if not self.learning_file.exists():
            default_learning = {
                'version': '4.1.1',
                'created_at': datetime.now().isoformat(),
                'facts': [],
                'patterns': [],
                'insights': [],
                'habits': []
            }
            self._save_json(self.learning_file, default_learning)
            print(f"✅ Created learning.json (v4.1.1)")
        
        # session.json (v4.1 enhanced)
        if not self.session_file.exists():
            default_session = {
                'session_id': str(uuid.uuid4()),
                'started_at': datetime.now().isoformat(),
                'message_count': 0,
                'context': [],
                'learning_count': 0
            }
            self._save_json(self.session_file, default_session)
            print(f"✅ Created session.json (v4.1.1)")
    
    def get_preferences(self) -> Dict:
        return self._load_json(self.preferences_file)
    
    def get_learning(self) -> Dict:
        return self._load_json(self.learning_file)
    
    def get_session_context(self) -> Dict:
        return self._load_json(self.session_file)
    
    def build_context_prompt(self) -> str:
        """
        🆕 v4.1: Enhanced context with 3-step response instructions
        """
        prefs = self.get_preferences()
        learning = self.get_learning()
        session = self.get_session_context()
        
        # Get recent learnings with confidence levels
        recent_facts = learning['facts'][-10:] if learning['facts'] else []
        recent_patterns = learning.get('patterns', [])[-5:]
        
        context = f"""[KIVOSY v4.1.1 MEMORY SYSTEM - PROACTIVE SECRETARY MODE]

👤 FACTORY OWNER PROFILE:
Name: {prefs['user']['name']} ({prefs['user']['role']})
Language: {prefs['user']['language']}
Timezone: {prefs['user']['timezone']}
Communication: {prefs['user']['communication_style']}

🤖 YOUR ROLE (Observant Secretary):
You are a PROACTIVE AI SECRETARY who:
- NEVER misses personal details, preferences, or facts
- ALWAYS references memory when relevant
- ALWAYS provides actionable suggestions
- Uses 3-step response format MANDATORY

📚 ACCUMULATED KNOWLEDGE ({len(learning['facts'])} facts):
"""
        
        # Add facts with confidence indicators
        if recent_facts:
            for i, fact in enumerate(recent_facts, 1):
                confidence = fact.get('confidence', 0.5)
                emoji = "🟢" if confidence > 0.7 else "🟡" if confidence > 0.5 else "🔴"
                content = fact.get('content', 'N/A')[:80]
                learned_date = fact.get('learned_at', '')[:10]
                context += f"{i}. {emoji} {content} (learned: {learned_date})\n"
        else:
            context += "(No facts yet - be observant and start learning!)\n"
        
        # Add patterns if any
        if recent_patterns:
            context += f"\n🔍 OBSERVED PATTERNS:\n"
            for pattern in recent_patterns:
                context += f"- {pattern.get('content', 'N/A')}\n"
        
        context += f"""
📊 CURRENT SESSION:
Session: {session['session_id'][:8]}
Messages: {session['message_count']}
Learnings This Session: {session.get('learning_count', 0)}

🎯 MANDATORY 3-STEP RESPONSE FORMAT:

You MUST respond using this exact structure:

<think>
[Your detailed reasoning process]
[Consider: What does memory tell me about Factory Owner?]
[Consider: What patterns or preferences are relevant?]
[Consider: What would be most helpful right now?]
</think>

<summary>
[ONE sentence: What the user said or what happened]
</summary>

<insight>
[What you REALIZED from memory context]
[MUST reference specific facts/patterns when relevant]
[Examples:
 - "Based on your preference for X (learned 3 days ago)..."
 - "This aligns with your usual pattern of Y..."
 - "I notice this is the 3rd time you mentioned Z..."]
[If no memory relevant: "This is new information - I'll remember this."]
</insight>

<suggestion>
[What you recommend PROACTIVELY]
[Examples:
 - "I suggest you... because..."
 - "Based on your usual workflow, you might want to..."
 - "This could be a good time to..."]
[If no suggestion: "Let me know if you need anything else."]
</suggestion>

RULES:
- <think> is HIDDEN from user (for your internal reasoning)
- <summary>, <insight>, <suggestion> are SHOWN to user
- NEVER skip any section
- ALWAYS use exact XML tags
- Keep each section concise but meaningful


🎯 ACTION COMMANDS (MANDATORY):
If the user wants to see a video or search for something, append the command at the END of your response.
- Youtube: [CMD: YT_SEARCH|query]
- Google Maps: [CMD: MAP|location]
Example: "유튜브에서 뉴진스 음악 틀어줄게요! [CMD: YT_SEARCH|뉴진스]"
"""

        
        return context
    
    def _save_json(self, path, data):
        """Save JSON with error handling"""
        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"[Memory] ⚠️ Failed to save {path}: {e}")
    
    def _load_json(self, path):
        """Load JSON with error handling"""
        try:
            if path.exists():
                with open(path, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except Exception as e:
            print(f"[Memory] ⚠️ Failed to load {path}: {e}")
        return {}
    
    def extract_learnings(self, user_message: str, ai_response: str, lm_studio_url: str = None) -> List[Dict]:
        """
        🆕 v4.1.1: 방탄형 학습 추출
        - 부재중 메시지면 즉시 중단 (불필요한 에러 방지)
        - AI 엔진 연결 확인 후 진행
        """
        learnings = []
        
        # 🛡️ 1단계: 부재중 응답인지 확인 (이게 핵심!)
        if "자유를 향해 부재중" in ai_response or "부재중 메시지" in ai_response:
            print("[Learning] 🤫 자비스가 부재중이므로 학습을 건너뜁니다.")
            return []

        # Pass 1: Regex-based extraction (이건 AI 없이도 돌아감)
        learnings.extend(self._extract_regex(user_message))
        
        # Pass 2: LLM-powered extraction
        if lm_studio_url:
            try:
                # 🛡️ 2단계: 연결 상태 한 번 더 확인
                check_url = lm_studio_url.replace('/chat/completions', '/models')
                if requests.get(check_url, timeout=1).status_code == 200:
                    learnings.extend(self._extract_llm_powered(user_message, lm_studio_url))
            except Exception as e:
                # 여기서 에러 나도 'role' 에러 안 뜨게 내부적으로 SafeAPIParser가 막아줄 겁니다.
                print(f"[Learning] ⚠️ 엔진 연결 불가로 LLM 학습 스킵: {e}")
        
        return learnings


    def _extract_regex(self, text: str) -> List[Dict]:
        """Fast regex-based extraction for obvious patterns"""
        learnings = []
        
        patterns = [
            (r'나는 (.+?)(?:을|를|이|가) 좋아', 'preference', 0.7),
            (r'내 이름은 (.+?)(?:이다|입니다|야|이야)', 'fact', 0.9),
            (r'나는 (.+?)(?:에서|에) (?:일하|근무)', 'fact', 0.8),
            (r'매일|매주|항상 (.+?)(?:한다|해)', 'habit', 0.7),
        ]
        
        for pattern, type_, confidence in patterns:
            matches = re.finditer(pattern, text)
            for match in matches:
                content = f"공장장은 {match.group(1).strip()}"
                learnings.append({
                    'type': type_,
                    'content': content,
                    'learned_at': datetime.now().isoformat(),
                    'source': 'regex',
                    'confidence': confidence
                })
        
        return learnings
    
    def _extract_llm_powered(self, user_message: str, lm_studio_url: str) -> List[Dict]:
        """
        🆕 v4.1.1: LLM-powered extraction with DEFENSIVE PARSING
        
        FIXED: No more KeyError crashes
        """
        extraction_prompt = f"""당신은 매우 관찰력이 뛰어난 비서입니다. 사용자의 메시지에서 학습할 만한 모든 정보를 빠짐없이 추출하세요.

사용자 메시지: "{user_message}"

다음을 찾아서 JSON 배열로 반환하세요:
1. 개인 선호사항 (좋아하는 것, 싫어하는 것, 선호하는 것)
2. 사실 정보 (이름, 직업, 위치, 회사, 소속 등)
3. 습관/패턴 (시간, 루틴, 반복적인 행동)
4. 목표/계획 (하고 싶은 것, 계획, 일정)
5. 기타 개인 정보 (취미, 관심사, 중요한 사람/장소 등)

반환 형식 (JSON만):
[
  {{"type": "preference", "content": "공장장은 커피를 좋아함", "confidence": 0.9}},
  {{"type": "fact", "content": "회사는 서울 강남에 위치", "confidence": 0.8}},
  {{"type": "habit", "content": "매일 아침 9시에 출근", "confidence": 0.7}}
]

학습할 정보가 없으면: []

중요: 
- 반드시 JSON 배열만 반환 (다른 텍스트 없이)
- 사소한 정보도 놓치지 마세요
- confidence는 0.5~1.0 사이
- content는 "공장장" 주어로 시작
"""
        
        try:
            response = requests.post(
                lm_studio_url,
                json={
                    "messages": [{"role": "user", "content": extraction_prompt}],
                    "temperature": 0.3,
                    "max_tokens": 800
                },
                timeout=15
            )
            
            if response.ok:
                response_data = response.json()
                # Extract content safely
                raw = self._safe_extract_content(response_data, fallback="[]")
                
                # Extract JSON from response
                extracted = SafeParser.safe_json_extract(raw)
                if extracted:
                    learnings = []
                    for item in extracted:
                        if isinstance(item, dict) and 'content' in item:
                            learnings.append({
                                'type': item.get('type', 'fact'),
                                'content': item['content'],
                                'learned_at': datetime.now().isoformat(),
                                'source': 'llm',
                                'confidence': float(item.get('confidence', 0.7))
                            })
                    
                    if learnings:
                        print(f"[Learning LLM] 🧠 Extracted {len(learnings)} items via AI")
                    
                    return learnings
        
        except requests.Timeout:
            print(f"[Learning LLM] ⏱️ Timeout (skipping LLM extraction)")
        except Exception as e:
            print(f"[Learning LLM] ⚠️ Error: {e}")
        
        return []
    
    def _safe_extract_content(self, response_data: Dict, fallback: str = "") -> str:
        """Safely extract content from API response"""
        try:
            if isinstance(response_data, dict):
                choices = response_data.get('choices', [])
                if choices and len(choices) > 0:
                    first_choice = choices[0]
                    if isinstance(first_choice, dict):
                        message = first_choice.get('message', {})
                        if isinstance(message, dict):
                            content = message.get('content')
                            if content is not None:
                                return str(content)
                
                content = response_data.get('content')
                if content is not None:
                    return str(content)
                
                text = response_data.get('text')
                if text is not None:
                    return str(text)
            
            if isinstance(response_data, str):
                return response_data
            
        except Exception as e:
            print(f"[Memory.SafeExtract] ⚠️ Exception: {e}")
        
        return fallback
    
    def update_learning(self, new_learnings: List[Dict]):
        """Update learning.json with deduplication and reinforcement"""
        if not new_learnings:
            return
        
        learning_data = self.get_learning()
        added_count = 0
        reinforced_count = 0
        
        for learning in new_learnings:
            content = learning['content']
            
            # Check for similar existing facts (fuzzy match)
            is_duplicate = False
            for existing in learning_data['facts']:
                similarity = self._similarity(content, existing.get('content', ''))
                if similarity > 0.75:
                    is_duplicate = True
                    old_conf = existing.get('confidence', 0.5)
                    new_conf = learning.get('confidence', 0.5)
                    if new_conf > old_conf:
                        existing['confidence'] = new_conf
                        existing['last_reinforced'] = datetime.now().isoformat()
                        existing['reinforcement_count'] = existing.get('reinforcement_count', 0) + 1
                        reinforced_count += 1
                        print(f"[Learning] 🔄 Reinforced: {content[:50]}... (conf: {old_conf:.2f}→{new_conf:.2f})")
                    break
            
            if not is_duplicate:
                learning_data['facts'].append(learning)
                added_count += 1
                conf_emoji = "🟢" if learning.get('confidence', 0) > 0.7 else "🟡"
                print(f"[Learning] {conf_emoji} NEW: {content[:60]}...")
        
        if added_count > 0 or reinforced_count > 0:
            self._save_json(self.learning_file, learning_data)
            
            # Update session stats
            session = self.get_session_context()
            session['learning_count'] = session.get('learning_count', 0) + added_count
            self._save_json(self.session_file, session)
            
            print(f"[Learning] 📚 Total: {added_count} new + {reinforced_count} reinforced")
    
    def _similarity(self, a: str, b: str) -> float:
        """Simple fuzzy string matching (Jaccard similarity)"""
        set_a = set(a.lower().split())
        set_b = set(b.lower().split())
        if not set_a or not set_b:
            return 0.0
        intersection = set_a & set_b
        union = set_a | set_b
        return len(intersection) / len(union)
    
    def update_session(self):
        """Update session message count"""
        session = self.get_session_context()
        session['message_count'] = session.get('message_count', 0) + 1
        self._save_json(self.session_file, session)
    
    def reset_session(self):
        """Reset session (new conversation start)"""
        new_session = {
            'session_id': str(uuid.uuid4()),
            'started_at': datetime.now().isoformat(),
            'message_count': 0,
            'context': [],
            'learning_count': 0
        }
        self._save_json(self.session_file, new_session)
        print(f"[Memory] 🔄 Session reset: {new_session['session_id'][:8]}")


class SoulEngine:
    """
    Soul Engine: Anonymized mood/vibe data for game integration.
    
    STRICT DATA ISOLATION:
    - NO personal info (names, locations, habits)
    - ONLY mood scores and weather keywords
    - NO conversation content
    """
    
    def __init__(self, memory_system: MemorySystem):
        self.memory = memory_system
    
    def get_mood_score(self) -> Dict[str, float]:
        """
        Calculate anonymized mood score from recent activity.
        
        Returns:
            {
                'energy': 0.0-1.0,
                'stress': 0.0-1.0,
                'focus': 0.0-1.0,
                'social': 0.0-1.0
            }
        """
        session = self.memory.get_session_context()
        learning = self.memory.get_learning()
        
        # Default neutral state
        mood = {
            'energy': 0.5,
            'stress': 0.5,
            'focus': 0.5,
            'social': 0.5
        }
        
        try:
            # Analyze recent message patterns (anonymized)
            message_count = session.get('message_count', 0)
            learning_count = session.get('learning_count', 0)
            
            # High activity = higher energy
            if message_count > 10:
                mood['energy'] = min(0.5 + (message_count / 100), 1.0)
            
            # Learning activity = higher focus
            if learning_count > 5:
                mood['focus'] = min(0.5 + (learning_count / 20), 1.0)
            
            # Analyze fact types for mood indicators
            recent_facts = learning.get('facts', [])[-10:]
            for fact in recent_facts:
                content_lower = fact.get('content', '').lower()
                
                # Stress indicators (anonymized keywords)
                stress_keywords = ['피곤', '바쁨', '힘듦', '스트레스', 'tired', 'busy', 'stressed']
                if any(kw in content_lower for kw in stress_keywords):
                    mood['stress'] = min(mood['stress'] + 0.1, 1.0)
                
                # Energy indicators
                energy_keywords = ['활발', '열정', '에너지', 'energetic', 'excited', 'active']
                if any(kw in content_lower for kw in energy_keywords):
                    mood['energy'] = min(mood['energy'] + 0.1, 1.0)
            
        except Exception as e:
            print(f"[SoulEngine] ⚠️ Mood calculation error: {e}")
        
        return mood
    
    def get_weather_keywords(self) -> List[str]:
        """
        Extract weather-related mood keywords (for game environment).
        
        Returns:
            List of weather keywords: ['sunny', 'rainy', 'stormy', 'calm']
        """
        mood = self.get_mood_score()
        keywords = []
        
        # Map mood to weather (thematic, not literal)
        if mood['energy'] > 0.7:
            keywords.append('sunny')
        elif mood['energy'] < 0.3:
            keywords.append('cloudy')
        
        if mood['stress'] > 0.7:
            keywords.append('stormy')
        elif mood['stress'] < 0.3:
            keywords.append('calm')
        
        if mood['focus'] > 0.7:
            keywords.append('clear')
        
        return keywords if keywords else ['neutral']
    
    def get_anonymized_export(self) -> Dict:
        """
        Get fully anonymized data for game servers.
        
        GUARANTEED SAFE:
        - No names, locations, personal details
        - Only abstract mood metrics
        """
        return {
            'mood_scores': self.get_mood_score(),
            'weather_keywords': self.get_weather_keywords(),
            'timestamp': datetime.now().isoformat(),
            'version': '1.0'
        }