"""
KIVOSY v4.1.1 - Gateway Database Module
Responsible for: Node storage, JSON file operations, channel management
"""

import json
import uuid
import webbrowser # 웹 브라우저 제어용
import re  # <--- 이 녀석이 범인입니다! 이걸 꼭 넣어주세요.Regular Expression(정규표현식)
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any



# Channel configurations
CHANNELS = {
    'kakao': {'name': 'KakaoTalk', 'icon': '💬', 'color': '#FAE100'},
    'whatsapp': {'name': 'WhatsApp', 'icon': '🟢', 'color': '#25D366'},
    'line': {'name': 'LINE', 'icon': '💚', 'color': '#00B900'}
}


class NodeDatabase:
    """
    Manages node storage and retrieval
    """
    
    def __init__(self, base_dir: str = None, nodes_file: str = 'nodes.json'):
        if base_dir is None:
            import os
            base_dir = os.path.dirname(os.path.abspath(__file__))
        
        self.base_dir = Path(base_dir)
        self.nodes_path = self.base_dir / nodes_file
    
    def save_node(self, channel: str, content: str, ai_result: Dict[str, Any]) -> str:
        """
        Save node with v4.1 enhanced structure
        
        Args:
            channel: Channel name (kakao/whatsapp/line)
            content: Original user message
            ai_result: AI response from engine_ai
            
        Returns:
            node_id: Generated node ID
        """
        if channel not in CHANNELS:
            raise ValueError(f"지원하지 않는 채널: {channel}")
        
        nodes = self._load()
        
        new_node = {
            "id": str(uuid.uuid4()),
            "timestamp": datetime.now().isoformat(),
            "channel": channel,
            "content": content,
            "ai_response": ai_result.get('raw', ''),
            "ai": {
                "thinking": ai_result.get('thinking', ''),
                "summary": ai_result.get('summary', ''),
                "insight": ai_result.get('insight', ''),
                "suggestion": ai_result.get('suggestion', ''),
                "has_thinking": ai_result.get('has_thinking', False),
                "language": ai_result.get('language', 'auto'),
                "learnings_extracted": ai_result.get('learnings_extracted', 0)
            }
        }
        
        nodes.append(new_node)
        self._save(nodes)
        
        icon = CHANNELS.get(channel, {}).get('icon', '📱')
        print(f"[저장] {icon} {channel} | ID: {new_node['id'][:8]} | 학습: {ai_result.get('learnings_extracted', 0)}개")
        
        return new_node['id']
    
    def get_nodes(self, channel_filter: Optional[str] = None) -> List[Dict]:
        """Get all nodes, optionally filtered by channel"""
        nodes = self._load()
        if channel_filter and channel_filter in CHANNELS:
            nodes = [n for n in nodes if n.get('channel') == channel_filter]
        return nodes
    
    def get_node_count(self) -> int:
        """Get total number of nodes"""
        return len(self._load())
    
    def _load(self) -> List[Dict]:
        """Load nodes from JSON file"""
        try:
            if self.nodes_path.exists():
                with open(self.nodes_path, "r", encoding="utf-8") as f:
                    return json.load(f)
        except Exception as e:
            print(f"[Gateway.DB] ⚠️ Failed to load nodes: {e}")
        return []
    
    def _save(self, nodes: List[Dict]):
        """Save nodes to JSON file"""
        try:
            with open(self.nodes_path, "w", encoding="utf-8") as f:
                json.dump(nodes, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"[Gateway.DB] ⚠️ Failed to save nodes: {e}")


class ChannelGateway:
    """
    Unified gateway for all messaging channels
    """
    
    def __init__(self, db: NodeDatabase, ai_engine=None, memory_system=None):
        self.db = db
        self.ai_engine = ai_engine
        self.memory = memory_system
    
    def process_message(self, channel: str, content: str, language: str = "auto") -> Dict[str, Any]:
        if not self.ai_engine or not self.memory:
            return {'node_id': 'error', 'ai_result': self.ai_engine._create_error_response("Engine Missing"), 'learnings_extracted': 0}

        print(f"\n[{channel.upper()}] 수신: {content[:50]}...")

        # 1. AI 호출
        try:
            # 🛡️ 수정 포인트: 메모리 빌드 시 에러 방지
            try:
                memory_context = self.memory.build_context_prompt()
            except Exception as mem_err:
                print(f"[Memory] ⚠️ 컨텍스트 빌드 실패 (무시): {mem_err}")
                memory_context = "당신은 유능한 비서 자비스입니다."

            full_prompt = f"{memory_context}\n\nUSER MESSAGE:\n{content}\n\nRESPOND NOW!"
            ai_result = self.ai_engine.ask(full_prompt, temperature=0.7)
            
        except Exception as e:
            # 🚨 여기서 'role' 에러가 찍혔던 겁니다!
            print(f"[Gateway] ⚠️ AI 호출 중 치명적 오류: {e}")
            ai_result = self.ai_engine._create_error_response(str(e))



        # 2. ai_result가 이상하게 왔을 때를 대비한 '강제 규격화' (핵심 방어선)
        if not isinstance(ai_result, dict):
            ai_result = self.ai_engine._create_error_response("Invalid Format")
        
        ai_result.setdefault('success', False)
        ai_result.setdefault('raw', "죄송합니다. 엔진 점검 중입니다.")
        ai_result['language'] = language



        # 3. 학습 추출 (이 부분도 더 방탄으로!)
        learnings = []
        if ai_result.get('success') is True and ai_result.get('raw'):
            try:
                # 🛡️ 14B 과장님이 제대로 일했을 때만 학습 진행
                # 만약 여기서 'role' 에러가 난다면 processor_memory.py 내부를 손봐야 합니다.
                learnings = self.memory.extract_learnings(
                    content, 
                    ai_result['raw'], 
                    self.ai_engine.lm_studio_url
                )
                if learnings and isinstance(learnings, list):
                    self.memory.update_learning(learnings)
            except Exception as e:
                print(f"[Learning] ⚠️ 학습 엔진 충돌(무시): {e}") # 여기서 'role' 에러가 나도 이제 무시하고 통과!


        ai_result['learnings_extracted'] = len(learnings)

        # 🔥 [추가] AI의 답변(raw)에서 명령어가 있는지 확인하고 실행!
        if ai_result.get('success') and ai_result.get('raw'):
            action_status = self._execute_action(ai_result['raw'])
            if action_status:
                # 실행 결과가 있으면 로그에 남깁니다.
                print(f"🛠️ [EXECUTE] {action_status}")



        # 4. DB 저장 및 세션 업데이트
        try:
            node_id = self.db.save_node(channel, content, ai_result)
            self.memory.update_session()
        except Exception as e:
            print(f"[Gateway] ⚠️ 저장/세션 업데이트 실패: {e}")
            node_id = "save_error"

        # 최종 리턴 (규격 딱딱 맞춰서!)
        return {
            'node_id': node_id,
            'ai_result': ai_result,
            'learnings_extracted': len(learnings)
        }
    

    def _execute_action(self, ai_raw_text: str):
        """AI 응답에서 명령어를 찾아 실행하는 '손발' 함수"""
        
        # 1. 유튜브 실행 명령 확인 [CMD: YT_SEARCH|검색어]
        yt_match = re.search(r"\[CMD: YT_SEARCH\|(.*?)\]", ai_raw_text)
        if yt_match:
            search_query = yt_match.group(1)
            url = f"https://www.youtube.com/results?search_query={search_query}"
            print(f"🚀 [ACTION] 유튜브 검색 실행: {search_query}")
            webbrowser.open(url)
            return "YouTube 검색을 실행했습니다."

        # 2. 구글 지도 실행 명령 확인 [CMD: MAP|장소]
        map_match = re.search(r"\[CMD: MAP\|(.*?)\]", ai_raw_text)
        if map_match:
            location = map_match.group(1)
            url = f"https://www.google.com/maps/search/{location}"
            print(f"🚀 [ACTION] 지도 검색 실행: {location}")
            webbrowser.open(url)
            return "지도를 열었습니다."

        return None