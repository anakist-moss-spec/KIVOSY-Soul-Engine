"""
KIVOSY v4.0 - Personal AI Infrastructure (PAI)
Chief Engineer: Claude (Anthropic)
Version: 4.0.0 - Memory System Enabled

Evolution: Simple Logger → Personal AI Infrastructure

Features:
✅ Multi-channel unified endpoints
✅ PAI Memory System (preferences + learning)
✅ Context-aware AI responses
✅ Automatic learning from conversations
✅ LM Studio 14B integration
"""

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from datetime import datetime
import json
import os
import uuid
import requests
import re
from pathlib import Path
from typing import Optional, Dict, List, Any

# ═══════════════════════════════════════════════════════════
# 경로 자동 최적화
# ═══════════════════════════════════════════════════════════
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FRONTEND_DIR = os.path.join(BASE_DIR, 'frontend')
MEMORY_DIR = os.path.join(BASE_DIR, 'memory')  # 🆕 Memory Directory

app = Flask(__name__, static_folder=FRONTEND_DIR, static_url_path='')
CORS(app)

# ═══════════════════════════════════════════════════════════
# LM STUDIO 14B 설정
# ═══════════════════════════════════════════════════════════
LM_STUDIO_URL = "http://localhost:1234/v1/chat/completions"

print(f"""
╔═══════════════════════════════════════════════════════════╗
║  🧠 KIVOSY v4.0 - PERSONAL AI INFRASTRUCTURE (PAI)        ║
╚═══════════════════════════════════════════════════════════╝
Evolution: Simple Logger → Jarvis-level AI
Memory System: ENABLED
LM Studio: {LM_STUDIO_URL}
""")

# ═══════════════════════════════════════════════════════════
# 채널 설정
# ═══════════════════════════════════════════════════════════
CHANNELS = {
    'kakao': {'name': 'KakaoTalk', 'icon': '💬', 'color': '#FAE100'},
    'whatsapp': {'name': 'WhatsApp', 'icon': '🟢', 'color': '#25D366'},
    'line': {'name': 'LINE', 'icon': '💚', 'color': '#00B900'}
}

# ═══════════════════════════════════════════════════════════
# 🆕 PAI MEMORY SYSTEM
# ═══════════════════════════════════════════════════════════

class MemorySystem:
    """
    PAI-inspired Memory System
    
    Maintains:
    - preferences.json: User tastes, communication style, preferences
    - learning.json: Long-term facts, patterns, insights
    - session.json: Current session context
    """
    
    def __init__(self, memory_dir: str = MEMORY_DIR):
        self.memory_dir = Path(memory_dir)
        self.preferences_file = self.memory_dir / 'preferences.json'
        self.learning_file = self.memory_dir / 'learning.json'
        self.session_file = self.memory_dir / 'session.json'
        
        self._ensure_memory_structure()
    
    def _ensure_memory_structure(self):
        """Initialize memory directory and files"""
        # Create memory directory
        self.memory_dir.mkdir(exist_ok=True)
        
        # Initialize preferences.json
        if not self.preferences_file.exists():
            default_preferences = {
                'version': '4.0',
                'created_at': datetime.now().isoformat(),
                'user': {
                    'name': '공장장',  # Factory Owner
                    'timezone': 'Asia/Seoul',
                    'language': 'ko',
                    'communication_style': 'professional'
                },
                'ai': {
                    'response_style': 'concise',
                    'thinking_display': True,
                    'tone': 'friendly-professional'
                },
                'preferences': {
                    'summary_length': 'medium',
                    'technical_depth': 'moderate',
                    'emoji_usage': True
                }
            }
            self._save_json(self.preferences_file, default_preferences)
            print(f"✅ Created preferences.json")
        
        # Initialize learning.json
        if not self.learning_file.exists():
            default_learning = {
                'version': '4.0',
                'created_at': datetime.now().isoformat(),
                'facts': [],
                'patterns': [],
                'insights': []
            }
            self._save_json(self.learning_file, default_learning)
            print(f"✅ Created learning.json")
        
        # Initialize session.json
        if not self.session_file.exists():
            default_session = {
                'session_id': str(uuid.uuid4()),
                'started_at': datetime.now().isoformat(),
                'message_count': 0,
                'context': []
            }
            self._save_json(self.session_file, default_session)
            print(f"✅ Created session.json")
    
    def get_preferences(self) -> Dict:
        """Load user preferences"""
        return self._load_json(self.preferences_file)
    
    def get_learning(self) -> Dict:
        """Load accumulated learning"""
        return self._load_json(self.learning_file)
    
    def get_session_context(self) -> Dict:
        """Load current session context"""
        return self._load_json(self.session_file)
    
    def build_context_prompt(self) -> str:
        """
        Build context prompt from memory for AI
        This is injected BEFORE each AI request
        """
        prefs = self.get_preferences()
        learning = self.get_learning()
        session = self.get_session_context()
        
        context = f"""[KIVOSY MEMORY SYSTEM]

👤 Factory Owner (공장장):
- Name: {prefs['user']['name']}
- Language: {prefs['user']['language']}
- Timezone: {prefs['user']['timezone']}
- Style: {prefs['user']['communication_style']}

🤖 AI Personality:
- Response Style: {prefs['ai']['response_style']}
- Thinking Display: {prefs['ai']['thinking_display']}
- Tone: {prefs['ai']['tone']}

📚 Long-term Learning ({len(learning['facts'])} facts):
"""
        
        # Add recent facts
        recent_facts = learning['facts'][-5:]  # Last 5 facts
        for i, fact in enumerate(recent_facts, 1):
            context += f"{i}. {fact.get('content', 'N/A')} (learned: {fact.get('learned_at', 'unknown')[:10]})\n"
        
        context += f"""
📊 Current Session:
- Session ID: {session['session_id']}
- Message Count: {session['message_count']}

🎯 Response Instructions:
- Use <think>...</think> for reasoning
- Use <final>...</final> for summary
- Consider Factory Owner's preferences
- Build on previous learnings
"""
        
        return context
    
    def extract_learnings(self, user_message: str, ai_response: str) -> List[Dict]:
        """
        Extract potential learnings from conversation
        Uses simple heuristics - can be enhanced with AI
        """
        learnings = []
        
        # Pattern 1: User states preferences
        preference_patterns = [
            r'(?:나는|저는)\s+(.+?)(?:을|를)\s+좋아(?:해|함)',  # "I like X"
            r'(?:나는|저는)\s+(.+?)(?:을|를)\s+선호(?:해|함)',  # "I prefer X"
            r'(?:나의|내)\s+(.+?)(?:은|는)\s+(.+)',           # "My X is Y"
        ]
        
        for pattern in preference_patterns:
            matches = re.findall(pattern, user_message)
            if matches:
                for match in matches:
                    if isinstance(match, tuple):
                        content = ' '.join(match)
                    else:
                        content = match
                    
                    learnings.append({
                        'type': 'preference',
                        'content': f"공장장 선호: {content}",
                        'learned_at': datetime.now().isoformat(),
                        'source': 'user_message',
                        'confidence': 0.8
                    })
        
        # Pattern 2: Factual statements
        fact_patterns = [
            r'(?:사실은|실제로)\s+(.+)',                      # "Actually X"
            r'(.+?)(?:이다|입니다|예요|임)',                   # "X is Y"
        ]
        
        for pattern in fact_patterns:
            matches = re.findall(pattern, user_message)
            if matches:
                for match in matches:
                    if len(match) > 10:  # Meaningful fact
                        learnings.append({
                            'type': 'fact',
                            'content': match,
                            'learned_at': datetime.now().isoformat(),
                            'source': 'user_message',
                            'confidence': 0.6
                        })
        
        return learnings
    
    def update_learning(self, new_learnings: List[Dict]):
        """Add new learnings to learning.json"""
        if not new_learnings:
            return
        
        learning_data = self.get_learning()
        
        for learning in new_learnings:
            # Avoid duplicates (simple check)
            content = learning['content']
            if not any(f.get('content') == content for f in learning_data['facts']):
                learning_data['facts'].append(learning)
                print(f"[Learning] 🧠 New: {content[:50]}...")
        
        self._save_json(self.learning_file, learning_data)
    
    def update_session(self, message_type: str = 'user'):
        """Update session context"""
        session = self.get_session_context()
        session['message_count'] += 1
        session['last_activity'] = datetime.now().isoformat()
        self._save_json(self.session_file, session)
    
    def reset_session(self):
        """Start new session"""
        new_session = {
            'session_id': str(uuid.uuid4()),
            'started_at': datetime.now().isoformat(),
            'message_count': 0,
            'context': []
        }
        self._save_json(self.session_file, new_session)
        print(f"[Session] 🔄 New session: {new_session['session_id'][:8]}")
    
    def _load_json(self, filepath: Path) -> Dict:
        """Load JSON file"""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"[Memory] ⚠️ Error loading {filepath.name}: {e}")
            return {}
    
    def _save_json(self, filepath: Path, data: Dict):
        """Save JSON file"""
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"[Memory] ⚠️ Error saving {filepath.name}: {e}")

# Initialize Memory System
memory = MemorySystem()

# ═══════════════════════════════════════════════════════════
# 강화된 사고 과정 추출기
# ═══════════════════════════════════════════════════════════
class ThinkingParser:
    """다국어 지원 + 강화된 정규식 기반 사고 과정 추출"""
    
    @staticmethod
    def extract(raw_text):
        if not raw_text or not raw_text.strip():
            return {'thinking': '', 'summary': '', 'has_thinking': False}
        
        patterns = [
            (r'<think[^>]*>(.*?)</think[^>]*>', r'<final[^>]*>(.*?)</final[^>]*>'),
            (r'<생각>(.*?)</생각>', r'<결론>(.*?)</결론>'),
        ]
        
        thinking = ''
        summary = ''
        
        for think_pattern, final_pattern in patterns:
            if not thinking:
                match = re.search(think_pattern, raw_text, re.DOTALL | re.IGNORECASE)
                if match:
                    thinking = match.group(1).strip()
            
            if not summary:
                match = re.search(final_pattern, raw_text, re.DOTALL | re.IGNORECASE)
                if match:
                    summary = match.group(1).strip()
        
        if not thinking and not summary:
            if re.search(r'<think', raw_text, re.IGNORECASE):
                thinking = raw_text
                summary = '분석 완료'
            else:
                summary = raw_text
        
        thinking = re.sub(r'<[^>]+>', '', thinking).strip()
        summary = re.sub(r'<[^>]+>', '', summary).strip()
        
        return {
            'thinking': thinking,
            'summary': summary,
            'has_thinking': bool(thinking)
        }
    
    @staticmethod
    def detect_language(text):
        if re.search(r'[가-힣]', text):
            return 'ko'
        if re.search(r'[àáảãạăằắẳẵặâầấẩẫậèéẻẽẹêềếểễệìíỉĩịòóỏõọôồốổỗộơờớởỡợùúủũụưừứửữự]', text, re.IGNORECASE):
            return 'vi'
        return 'en'

# ═══════════════════════════════════════════════════════════
# 다국어 프롬프트 (Memory Context 포함)
# ═══════════════════════════════════════════════════════════
PROMPTS = {
    'ko': """다음 메시지를 분석해주세요.

메시지: {text}

반드시 <think>사고과정</think>과 <final>요약</final> 형식으로 답변하세요.""",
    
    'en': """Analyze this message.

Message: {text}

Respond in <think>reasoning</think> and <final>summary</final> format.""",
    
    'vi': """Phân tích tin nhắn này.

Tin nhắn: {text}

Trả lời theo định dạng <think>suy luận</think> và <final>tóm tắt</final>."""
}

# ═══════════════════════════════════════════════════════════
# 통합 채널 게이트웨이 (Memory-Aware)
# ═══════════════════════════════════════════════════════════
class UnifiedChannelGateway:
    """전역 다채널 AI 인프라 + Memory System"""
    
    def __init__(self):
        self.nodes_path = Path(os.path.join(BASE_DIR, "nodes.json"))
        self._ensure_file()
    
    def _ensure_file(self):
        if not self.nodes_path.exists():
            with open(self.nodes_path, "w", encoding="utf-8") as f:
                json.dump([], f)
    
    def ask_ai(self, text: str, language: Optional[str] = None) -> Dict[str, Any]:
        """
        14B LLM 호출 (Memory Context 포함)
        🆕 MEMORY SYSTEM: AI가 공장장을 기억합니다!
        """
        if not language:
            language = ThinkingParser.detect_language(text)
        
        # 🆕 STEP 1: Build memory context
        memory_context = memory.build_context_prompt()
        
        # STEP 2: Build user prompt
        user_prompt = PROMPTS.get(language, PROMPTS['en']).format(text=text)
        
        # STEP 3: Combine context + prompt
        full_prompt = f"{memory_context}\n\n---\n\n{user_prompt}"
        
        try:
            print(f"[14B AI] 언어: {language.upper()} | 메모리 컨텍스트: {len(memory_context)}자")
            
            response = requests.post(LM_STUDIO_URL, json={
                "messages": [{"role": "user", "content": full_prompt}],
                "temperature": 0.7
            }, timeout=60)
            
            raw = response.json()['choices'][0]['message']['content']
            print(f"[14B AI] 응답 완료: {len(raw)}자")
            
            # 🆕 STEP 4: Extract learnings
            learnings = memory.extract_learnings(text, raw)
            if learnings:
                memory.update_learning(learnings)
            
            parsed = ThinkingParser.extract(raw)
            
            return {
                'raw': raw,
                'thinking': parsed['thinking'],
                'summary': parsed['summary'],
                'has_thinking': parsed['has_thinking'],
                'language': language,
                'learnings_extracted': len(learnings)
            }
            
        except Exception as e:
            print(f"[14B AI] 오류: {e}")
            return {
                'raw': f"<think>오류: {e}</think>AI 응답 실패",
                'thinking': f"오류: {e}",
                'summary': "AI 응답 실패",
                'has_thinking': True,
                'language': language,
                'learnings_extracted': 0
            }
    
    def save_node(self, channel, content, ai_result):
        """노드 저장 (channel 필드 포함)"""
        if channel not in CHANNELS:
            raise ValueError(f"지원하지 않는 채널: {channel}")
        
        nodes = self._load()
        
        new_node = {
            "id": str(uuid.uuid4()),
            "timestamp": datetime.now().isoformat(),
            "channel": channel,
            "content": content,
            "ai_response": ai_result['raw'],
            "ai": {
                "thinking": ai_result['thinking'],
                "summary": ai_result['summary'],
                "has_thinking": ai_result['has_thinking'],
                "language": ai_result['language'],
                "learnings_extracted": ai_result.get('learnings_extracted', 0)
            }
        }
        
        nodes.append(new_node)
        self._save(nodes)
        
        # 🆕 Update session
        memory.update_session()
        
        print(f"[저장] {CHANNELS[channel]['icon']} {channel} | ID: {new_node['id'][:8]}")
        
        return new_node['id']
    
    def get_nodes(self, channel_filter=None):
        nodes = self._load()
        
        if channel_filter and channel_filter in CHANNELS:
            nodes = [n for n in nodes if n.get('channel') == channel_filter]
        
        return nodes
    
    def _load(self):
        if self.nodes_path.exists():
            with open(self.nodes_path, "r", encoding="utf-8") as f:
                return json.load(f)
        return []
    
    def _save(self, nodes):
        with open(self.nodes_path, "w", encoding="utf-8") as f:
            json.dump(nodes, f, ensure_ascii=False, indent=2)

gateway = UnifiedChannelGateway()

# ═══════════════════════════════════════════════════════════
# API 엔드포인트
# ═══════════════════════════════════════════════════════════

@app.route('/')
def index():
    return send_from_directory(FRONTEND_DIR, 'index.html')

@app.route('/whatsapp.html')
def whatsapp_page():
    return send_from_directory(FRONTEND_DIR, 'whatsapp.html')

# ─────────────────────────────────────────────────────────────
# 통합 다채널 엔드포인트
# ─────────────────────────────────────────────────────────────

@app.route('/api/nodes/kakao', methods=['POST'])
def kakao():
    return _handle_channel('kakao')

@app.route('/api/nodes/whatsapp', methods=['POST'])
def whatsapp():
    return _handle_channel('whatsapp')

@app.route('/api/nodes/line', methods=['POST'])
def line():
    return _handle_channel('line')

@app.route('/api/kakao', methods=['POST'])
def legacy_kakao():
    return _handle_channel('kakao')

@app.route('/api/whatsapp', methods=['POST'])
def legacy_whatsapp():
    return _handle_channel('whatsapp')

def _handle_channel(channel):
    try:
        data = request.json
        content = data.get('content', '')
        
        if not content:
            return jsonify({"status": "empty"}), 400
        
        print(f"\n[{channel.upper()}] 수신: {content[:50]}...")
        
        # AI 분석 (Memory Context 포함!)
        ai_result = gateway.ask_ai(content)
        
        # 노드 저장
        node_id = gateway.save_node(channel, content, ai_result)
        
        res = jsonify({
            "status": "success",
            "node_id": node_id,
            "reply": ai_result['raw'],
            "learnings_extracted": ai_result.get('learnings_extracted', 0)
        })
        res.headers.add('Content-Type', 'application/json; charset=utf-8')
        return res, 200
        
    except Exception as e:
        print(f"[{channel.upper()}] 오류: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

# ─────────────────────────────────────────────────────────────
# 🆕 MEMORY API ENDPOINTS
# ─────────────────────────────────────────────────────────────

@app.route('/api/memory/preferences', methods=['GET'])
def get_preferences():
    """Get user preferences"""
    return jsonify(memory.get_preferences())

@app.route('/api/memory/learning', methods=['GET'])
def get_learning():
    """Get accumulated learning"""
    return jsonify(memory.get_learning())

@app.route('/api/memory/session', methods=['GET'])
def get_session():
    """Get current session"""
    return jsonify(memory.get_session_context())

@app.route('/api/memory/reset-session', methods=['POST'])
def reset_session():
    """Reset current session"""
    memory.reset_session()
    return jsonify({"status": "success", "message": "Session reset"})

# ─────────────────────────────────────────────────────────────
# 노드 조회
# ─────────────────────────────────────────────────────────────

@app.route('/api/nodes', methods=['GET'])
def get_nodes():
    channel_filter = request.args.get('channel')
    nodes = gateway.get_nodes(channel_filter=channel_filter)
    return jsonify(nodes)

@app.route('/api/health', methods=['GET'])
def health():
    return jsonify({
        'status': 'online',
        'version': '4.0.0',
        'memory_system': 'enabled',
        'lm_studio': LM_STUDIO_URL,
        'channels': list(CHANNELS.keys()),
        'total_nodes': len(gateway.get_nodes()),
        'learnings': len(memory.get_learning()['facts'])
    })

# ═══════════════════════════════════════════════════════════
# 서버 시작
# ═══════════════════════════════════════════════════════════

if __name__ == '__main__':
    print(f"""
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║   🧠 KIVOSY v4.0 - PERSONAL AI INFRASTRUCTURE (PAI)       ║
║                                                           ║
║         Evolution: SimSimi → Jarvis                       ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝

🧠 Memory System: ENABLED
   📁 Preferences: {memory.preferences_file}
   📚 Learning: {memory.learning_file}
   📊 Session: {memory.session_file}

📡 Channels:
   💬 POST /api/nodes/kakao
   🟢 POST /api/nodes/whatsapp
   💚 POST /api/nodes/line

🆕 Memory API:
   GET /api/memory/preferences   → User preferences
   GET /api/memory/learning       → Accumulated facts
   GET /api/memory/session        → Current session
   POST /api/memory/reset-session → Start new session

🚀 Dashboard: http://localhost:5000

Ready! The AI now remembers you! 🎯
""")
    
    app.run(host='0.0.0.0', port=5000, debug=False)
