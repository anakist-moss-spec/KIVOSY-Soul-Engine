"""
KIVOSY v4.1 - Personal AI Infrastructure (PAI)
Chief Engineer: Claude (Anthropic)
Version: 4.1.0 - Proactive Intelligence

Evolution: Simple Logger → Jarvis → Proactive Secretary

NEW in v4.1:
✅ 3-Step Professional Response (Summary/Insight/Suggestion)
✅ Aggressive Learning Engine (Zero-miss secretary mode)  
✅ LLM-powered fact extraction
✅ Proactive recommendations based on memory

Features:
✅ Multi-channel unified endpoints
✅ PAI Memory System (preferences + learning)
✅ Context-aware AI responses
✅ Automatic learning from conversations
✅ LM Studio 14B integration
"""

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from datetime import datetime
import json
import os
import uuid
import requests
import re
from pathlib import Path
from typing import Optional, Dict, List, Any

# ═══════════════════════════════════════════════════════════
# 경로 자동 최적화
# ═══════════════════════════════════════════════════════════
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FRONTEND_DIR = os.path.join(BASE_DIR, 'frontend')
MEMORY_DIR = os.path.join(BASE_DIR, 'memory')

app = Flask(__name__, static_folder=FRONTEND_DIR, static_url_path='')
CORS(app)

# ═══════════════════════════════════════════════════════════
# LM STUDIO 14B 설정
# ═══════════════════════════════════════════════════════════
LM_STUDIO_URL = "http://localhost:1234/v1/chat/completions"

print(f"""
╔═══════════════════════════════════════════════════════════╗
║  🧠 KIVOSY v4.1 - PROACTIVE AI INFRASTRUCTURE             ║
╚═══════════════════════════════════════════════════════════╝
Evolution: SimSimi → Jarvis → Proactive Secretary
Response Format: 3-Step Professional
Learning Engine: Aggressive Zero-Miss Mode
LM Studio: {LM_STUDIO_URL}
""")

# ═══════════════════════════════════════════════════════════
# 채널 설정
# ═══════════════════════════════════════════════════════════
CHANNELS = {
    'kakao': {'name': 'KakaoTalk', 'icon': '💬', 'color': '#FAE100'},
    'whatsapp': {'name': 'WhatsApp', 'icon': '🟢', 'color': '#25D366'},
    'line': {'name': 'LINE', 'icon': '💚', 'color': '#00B900'}
}

# ═══════════════════════════════════════════════════════════
# 🆕 v4.1 ENHANCED MEMORY SYSTEM
# ═══════════════════════════════════════════════════════════

class MemorySystem:
    """
    v4.1 Enhanced PAI Memory System
    
    NEW Features:
    - Aggressive learning extraction (multi-pass)
    - LLM-powered fact detection
    - 3-step response format support
    - Proactive insight generation
    """
    
    def __init__(self, memory_dir: str = MEMORY_DIR):
        self.memory_dir = Path(memory_dir)
        self.preferences_file = self.memory_dir / 'preferences.json'
        self.learning_file = self.memory_dir / 'learning.json'
        self.session_file = self.memory_dir / 'session.json'
        
        self._ensure_memory_structure()
    
    def _ensure_memory_structure(self):
        """Initialize memory directory and files"""
        self.memory_dir.mkdir(exist_ok=True)
        
        # preferences.json (v4.1 enhanced)
        if not self.preferences_file.exists():
            default_preferences = {
                'version': '4.1',
                'created_at': datetime.now().isoformat(),
                'user': {
                    'name': '공장장',
                    'role': 'Factory Owner',
                    'timezone': 'Asia/Seoul',
                    'language': 'ko',
                    'communication_style': 'professional'
                },
                'ai': {
                    'response_style': 'proactive',  # 🆕 proactive mode
                    'thinking_display': True,
                    'tone': 'friendly-professional',
                    'secretary_mode': True  # 🆕 observant secretary
                },
                'preferences': {
                    'summary_length': 'medium',
                    'technical_depth': 'moderate',
                    'emoji_usage': True,
                    'proactive_suggestions': True  # 🆕
                }
            }
            self._save_json(self.preferences_file, default_preferences)
            print(f"✅ Created preferences.json (v4.1)")
        
        # learning.json (v4.1 enhanced)
        if not self.learning_file.exists():
            default_learning = {
                'version': '4.1',
                'created_at': datetime.now().isoformat(),
                'facts': [],
                'patterns': [],
                'insights': [],
                'habits': []  # 🆕 user habits tracking
            }
            self._save_json(self.learning_file, default_learning)
            print(f"✅ Created learning.json (v4.1)")
        
        # session.json (v4.1 enhanced)
        if not self.session_file.exists():
            default_session = {
                'session_id': str(uuid.uuid4()),
                'started_at': datetime.now().isoformat(),
                'message_count': 0,
                'context': [],
                'learning_count': 0  # 🆕 track learnings per session
            }
            self._save_json(self.session_file, default_session)
            print(f"✅ Created session.json (v4.1)")
    
    def get_preferences(self) -> Dict:
        return self._load_json(self.preferences_file)
    
    def get_learning(self) -> Dict:
        return self._load_json(self.learning_file)
    
    def get_session_context(self) -> Dict:
        return self._load_json(self.session_file)
    
    def build_context_prompt(self) -> str:
        """
        🆕 v4.1: Enhanced context with 3-step response instructions
        """
        prefs = self.get_preferences()
        learning = self.get_learning()
        session = self.get_session_context()
        
        # Get recent learnings with confidence levels
        recent_facts = learning['facts'][-10:] if learning['facts'] else []
        recent_patterns = learning.get('patterns', [])[-5:]
        
        context = f"""[KIVOSY v4.1 MEMORY SYSTEM - PROACTIVE SECRETARY MODE]

👤 FACTORY OWNER PROFILE:
Name: {prefs['user']['name']} ({prefs['user']['role']})
Language: {prefs['user']['language']}
Timezone: {prefs['user']['timezone']}
Communication: {prefs['user']['communication_style']}

🤖 YOUR ROLE (Observant Secretary):
You are a PROACTIVE AI SECRETARY who:
- NEVER misses personal details, preferences, or facts
- ALWAYS references memory when relevant
- ALWAYS provides actionable suggestions
- Uses 3-step response format MANDATORY

📚 ACCUMULATED KNOWLEDGE ({len(learning['facts'])} facts):
"""
        
        # Add facts with confidence indicators
        if recent_facts:
            for i, fact in enumerate(recent_facts, 1):
                confidence = fact.get('confidence', 0.5)
                emoji = "🟢" if confidence > 0.7 else "🟡" if confidence > 0.5 else "🔴"
                content = fact.get('content', 'N/A')[:80]
                learned_date = fact.get('learned_at', '')[:10]
                context += f"{i}. {emoji} {content} (learned: {learned_date})\n"
        else:
            context += "(No facts yet - be observant and start learning!)\n"
        
        # Add patterns if any
        if recent_patterns:
            context += f"\n🔍 OBSERVED PATTERNS:\n"
            for pattern in recent_patterns:
                context += f"- {pattern.get('content', 'N/A')}\n"
        
        context += f"""
📊 CURRENT SESSION:
Session: {session['session_id'][:8]}
Messages: {session['message_count']}
Learnings This Session: {session.get('learning_count', 0)}

🎯 MANDATORY 3-STEP RESPONSE FORMAT:

You MUST respond using this exact structure:

<think>
[Your detailed reasoning process]
[Consider: What does memory tell me about Factory Owner?]
[Consider: What patterns or preferences are relevant?]
[Consider: What would be most helpful right now?]
</think>

<summary>
[ONE sentence: What the user said or what happened]
</summary>

<insight>
[What you REALIZED from memory context]
[MUST reference specific facts/patterns when relevant]
[Examples:
 - "Based on your preference for X (learned 3 days ago)..."
 - "This aligns with your usual pattern of Y..."
 - "I notice this is the 3rd time you mentioned Z..."]
[If no memory relevant: "This is new information - I'll remember this."]
</insight>

<suggestion>
[PROACTIVE next step or recommendation]
[MUST be actionable and specific]
[Examples:
 - "Should I remind you about X tomorrow at 9am?"
 - "Based on your schedule, would you like me to prepare Y?"
 - "I noticed you usually do Z at this time. Need help with that?"
 - "Would you like me to track this as a new pattern?"]
</suggestion>

⚠️ CRITICAL RULES:
1. ALL 4 sections REQUIRED: <think>, <summary>, <insight>, <suggestion>
2. Reference specific memories in <insight> when relevant
3. Make <suggestion> actionable and personalized
4. Learn EVERYTHING - no detail is too small
5. Secretary mindset: anticipate needs, be helpful

🔥 LEARNING MISSION:
Extract and remember EVERY:
- Personal preference ("I like/prefer/hate...")
- Fact about user ("My company...", "I work at...", "My name is...")
- Habit/Pattern ("I usually...", "Every morning I...")
- Goal/Plan ("I want to...", "Next week I...")
- Schedule/Time ("I meet at 3pm", "Morning routine...")

공장장님을 완벽하게 이해하고 도와주는 것이 당신의 임무입니다!
"""
        
        return context
    
    def extract_learnings(self, user_message: str, ai_response: str) -> List[Dict]:
        """
        🆕 v4.1: AGGRESSIVE multi-pass learning extraction
        
        Pass 1: Regex patterns (fast)
        Pass 2: LLM-powered extraction (thorough)
        """
        learnings = []
        
        # Pass 1: Regex-based (immediate patterns)
        learnings.extend(self._extract_regex_patterns(user_message))
        
        # Pass 2: LLM-powered (deep analysis)
        if len(user_message) >= 10:  # Only for meaningful messages
            learnings.extend(self._extract_llm_powered(user_message))
        
        return learnings
    
    def _extract_regex_patterns(self, text: str) -> List[Dict]:
        """
        Fast regex-based extraction - catches obvious patterns
        """
        learnings = []
        
        # HIGH CONFIDENCE PATTERNS (0.8-0.9)
        high_confidence_patterns = [
            # Preferences
            (r'(?:나는|저는)\s+(.+?)(?:을|를)\s+(?:좋아|선호)(?:해|함|합니다)', 'preference', 0.9),
            (r'(?:나는|저는)\s+(.+?)(?:을|를)\s+싫어(?:해|함|합니다)', 'preference', 0.85),
            # Facts
            (r'(?:나의|내)\s+이름(?:은|는)\s+(.+?)(?:이다|입니다|예요)', 'fact', 0.95),
            (r'(?:나의|내)\s+회사(?:는|는)\s+(.+?)(?:이다|입니다|예요)', 'fact', 0.9),
            (r'(?:우리|저희)\s+회사(?:는|는)\s+(.+?)(?:에|에서)', 'fact', 0.85),
        ]
        
        # MEDIUM CONFIDENCE PATTERNS (0.6-0.8)
        medium_confidence_patterns = [
            # Habits
            (r'(?:보통|항상|매일)\s+(.+?)(?:해|함|합니다)', 'habit', 0.7),
            (r'(?:오전|오후|저녁|아침)\s+(\d+시)(?:에|쯤)\s+(.+)', 'habit', 0.7),
            # Goals
            (r'(?:하고\s+싶|계획|예정)(?:어|은|이에요)\s+(.+)', 'goal', 0.7),
            # General facts
            (r'(?:사실은|실제로)\s+(.+)', 'fact', 0.6),
        ]
        
        all_patterns = high_confidence_patterns + medium_confidence_patterns
        
        for pattern, learn_type, confidence in all_patterns:
            matches = re.findall(pattern, text)
            for match in matches:
                # Clean up match
                if isinstance(match, tuple):
                    content = ' '.join(str(m) for m in match if m)
                else:
                    content = str(match)
                
                content = content.strip()
                
                # Only keep meaningful content
                if len(content) >= 3 and not content.isspace():
                    learnings.append({
                        'type': learn_type,
                        'content': f"공장장: {content}",
                        'learned_at': datetime.now().isoformat(),
                        'source': 'regex',
                        'confidence': confidence
                    })
        
        return learnings
    
    def _extract_llm_powered(self, user_message: str) -> List[Dict]:
        """
        🆕 v4.1: LLM-powered extraction - catches subtle learnings
        Uses 14B model to detect information regex might miss
        """
        extraction_prompt = f"""당신은 매우 관찰력이 뛰어난 비서입니다. 사용자의 메시지에서 학습할 만한 모든 정보를 빠짐없이 추출하세요.

사용자 메시지: "{user_message}"

다음을 찾아서 JSON 배열로 반환하세요:
1. 개인 선호사항 (좋아하는 것, 싫어하는 것, 선호하는 것)
2. 사실 정보 (이름, 직업, 위치, 회사, 소속 등)
3. 습관/패턴 (시간, 루틴, 반복적인 행동)
4. 목표/계획 (하고 싶은 것, 계획, 일정)
5. 기타 개인 정보 (취미, 관심사, 중요한 사람/장소 등)

반환 형식 (JSON만):
[
  {{"type": "preference", "content": "공장장은 커피를 좋아함", "confidence": 0.9}},
  {{"type": "fact", "content": "회사는 서울 강남에 위치", "confidence": 0.8}},
  {{"type": "habit", "content": "매일 아침 9시에 출근", "confidence": 0.7}}
]

학습할 정보가 없으면: []

중요: 
- 반드시 JSON 배열만 반환 (다른 텍스트 없이)
- 사소한 정보도 놓치지 마세요
- confidence는 0.5~1.0 사이
- content는 "공장장" 주어로 시작
"""
        
        try:
            response = requests.post(
                LM_STUDIO_URL,
                json={
                    "messages": [{"role": "user", "content": extraction_prompt}],
                    "temperature": 0.3,  # Low temp for structured output
                    "max_tokens": 800
                },
                timeout=15  # Fast extraction
            )
            
            if response.ok:
                raw = response.json()['choices'][0]['message']['content']
                
                # Extract JSON from response
                json_match = re.search(r'\[[\s\S]*\]', raw)
                if json_match:
                    try:
                        extracted = json.loads(json_match.group(0))
                        
                        learnings = []
                        for item in extracted:
                            if isinstance(item, dict) and 'content' in item:
                                learnings.append({
                                    'type': item.get('type', 'fact'),
                                    'content': item['content'],
                                    'learned_at': datetime.now().isoformat(),
                                    'source': 'llm',
                                    'confidence': float(item.get('confidence', 0.7))
                                })
                        
                        if learnings:
                            print(f"[Learning LLM] 🧠 Extracted {len(learnings)} items via AI")
                        
                        return learnings
                    except json.JSONDecodeError as e:
                        print(f"[Learning LLM] ⚠️ JSON parse error: {e}")
        
        except requests.Timeout:
            print(f"[Learning LLM] ⏱️ Timeout (skipping LLM extraction)")
        except Exception as e:
            print(f"[Learning LLM] ⚠️ Error: {e}")
        
        return []
    
    def update_learning(self, new_learnings: List[Dict]):
        """Update learning.json with deduplication and reinforcement"""
        if not new_learnings:
            return
        
        learning_data = self.get_learning()
        added_count = 0
        reinforced_count = 0
        
        for learning in new_learnings:
            content = learning['content']
            
            # Check for similar existing facts (fuzzy match)
            is_duplicate = False
            for existing in learning_data['facts']:
                similarity = self._similarity(content, existing.get('content', ''))
                if similarity > 0.75:  # 75% similarity threshold
                    is_duplicate = True
                    # Reinforce if new confidence is higher
                    old_conf = existing.get('confidence', 0.5)
                    new_conf = learning.get('confidence', 0.5)
                    if new_conf > old_conf:
                        existing['confidence'] = new_conf
                        existing['last_reinforced'] = datetime.now().isoformat()
                        existing['reinforcement_count'] = existing.get('reinforcement_count', 0) + 1
                        reinforced_count += 1
                        print(f"[Learning] 🔄 Reinforced: {content[:50]}... (conf: {old_conf:.2f}→{new_conf:.2f})")
                    break
            
            if not is_duplicate:
                learning_data['facts'].append(learning)
                added_count += 1
                conf_emoji = "🟢" if learning.get('confidence', 0) > 0.7 else "🟡"
                print(f"[Learning] {conf_emoji} NEW: {content[:60]}...")
        
        if added_count > 0 or reinforced_count > 0:
            self._save_json(self.learning_file, learning_data)
            
            # Update session stats
            session = self.get_session_context()
            session['learning_count'] = session.get('learning_count', 0) + added_count
            self._save_json(self.session_file, session)
            
            print(f"[Learning] 📊 Session total: {session['learning_count']} new + {reinforced_count} reinforced")
    
    def _similarity(self, a: str, b: str) -> float:
        """Calculate word-based similarity between two strings"""
        a_words = set(a.lower().split())
        b_words = set(b.lower().split())
        if not a_words or not b_words:
            return 0.0
        intersection = len(a_words & b_words)
        union = len(a_words | b_words)
        return intersection / union if union > 0 else 0.0
    
    def update_session(self, message_type: str = 'user'):
        """Update session context"""
        session = self.get_session_context()
        session['message_count'] += 1
        session['last_activity'] = datetime.now().isoformat()
        self._save_json(self.session_file, session)
    
    def reset_session(self):
        """Start new session"""
        new_session = {
            'session_id': str(uuid.uuid4()),
            'started_at': datetime.now().isoformat(),
            'message_count': 0,
            'context': [],
            'learning_count': 0
        }
        self._save_json(self.session_file, new_session)
        print(f"[Session] 🔄 New session: {new_session['session_id'][:8]}")
    
    def _load_json(self, filepath: Path) -> Dict:
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"[Memory] ⚠️ Error loading {filepath.name}: {e}")
            return {}
    
    def _save_json(self, filepath: Path, data: Dict):
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"[Memory] ⚠️ Error saving {filepath.name}: {e}")

# Initialize Memory System
memory = MemorySystem()

# ═══════════════════════════════════════════════════════════
# 🆕 v4.1 ENHANCED THINKING PARSER (3-step format)
# ═══════════════════════════════════════════════════════════

class ThinkingParser:
    """
    v4.1: Parse 3-step professional response format
    <think>, <summary>, <insight>, <suggestion>
    """
    
    @staticmethod
    def extract(raw_text: str) -> Dict[str, str]:
        if not raw_text or not raw_text.strip():
            return {
                'thinking': '',
                'summary': '',
                'insight': '',
                'suggestion': '',
                'has_thinking': False
            }
        
        # Extract each section
        result = {
            'thinking': ThinkingParser._extract_tag(raw_text, 'think', '생각'),
            'summary': ThinkingParser._extract_tag(raw_text, 'summary', '요약'),
            'insight': ThinkingParser._extract_tag(raw_text, 'insight', '인사이트'),
            'suggestion': ThinkingParser._extract_tag(raw_text, 'suggestion', '제안'),
        }
        
        # Fallback for summary (try 'final' tag)
        if not result['summary']:
            result['summary'] = ThinkingParser._extract_tag(raw_text, 'final', '결론')
        
        # Ultimate fallback
        if not result['summary'] and not result['thinking']:
            result['summary'] = raw_text.strip()
        
        result['has_thinking'] = bool(result['thinking'])
        
        return result
    
    @staticmethod
    def _extract_tag(text: str, *tag_names) -> str:
        """Extract content from XML-style tags"""
        for tag in tag_names:
            pattern = f'<{tag}[^>]*>(.*?)</{tag}[^>]*>'
            match = re.search(pattern, text, re.DOTALL | re.IGNORECASE)
            if match:
                content = match.group(1).strip()
                # Remove nested HTML tags
                content = re.sub(r'<[^>]+>', '', content).strip()
                return content
        return ''
    
    @staticmethod
    def detect_language(text: str) -> str:
        if re.search(r'[가-힣]', text):
            return 'ko'
        if re.search(r'[àáảãạăằắẳẵặâầấẩẫậèéẻẽẹêềếểễệìíỉĩịòóỏõọôồốổỗộơờớởỡợùúủũụưừứửữự]', text, re.IGNORECASE):
            return 'vi'
        return 'en'

# ═══════════════════════════════════════════════════════════
# UNIFIED CHANNEL GATEWAY (v4.1)
# ═══════════════════════════════════════════════════════════

class UnifiedChannelGateway:
    """v4.1: Gateway with proactive 3-step responses"""
    
    def __init__(self):
        self.nodes_path = Path(os.path.join(BASE_DIR, "nodes.json"))
        self._ensure_file()
    
    def _ensure_file(self):
        if not self.nodes_path.exists():
            with open(self.nodes_path, "w", encoding="utf-8") as f:
                json.dump([], f)
    
    def ask_ai(self, text: str, language: Optional[str] = None) -> Dict[str, Any]:
        """
        v4.1: AI with mandatory 3-step response format
        """
        if not language:
            language = ThinkingParser.detect_language(text)
        
        # Build enhanced memory context
        memory_context = memory.build_context_prompt()
        
        # User message (already includes format instructions in context)
        user_prompt = f"\n사용자 메시지: {text}\n"
        
        # Combine
        full_prompt = memory_context + user_prompt
        
        try:
            print(f"[14B AI] 언어: {language.upper()} | 메모리: {len(memory_context)}자 | 모드: PROACTIVE")
            
            response = requests.post(LM_STUDIO_URL, json={
                "messages": [{"role": "user", "content": full_prompt}],
                "temperature": 0.7
            }, timeout=60)
            
            raw = response.json()['choices'][0]['message']['content']
            print(f"[14B AI] 응답 완료: {len(raw)}자")
            
            # 🆕 v4.1: Aggressive learning extraction
            learnings = memory.extract_learnings(text, raw)
            if learnings:
                memory.update_learning(learnings)
            
            # Parse 3-step format
            parsed = ThinkingParser.extract(raw)
            
            return {
                'raw': raw,
                'thinking': parsed['thinking'],
                'summary': parsed['summary'],
                'insight': parsed['insight'],  # 🆕
                'suggestion': parsed['suggestion'],  # 🆕
                'has_thinking': parsed['has_thinking'],
                'language': language,
                'learnings_extracted': len(learnings)
            }
            
        except Exception as e:
            print(f"[14B AI] 오류: {e}")
            return {
                'raw': f"<think>오류: {e}</think><summary>AI 응답 실패</summary>",
                'thinking': f"오류: {e}",
                'summary': "AI 응답 실패",
                'insight': '',
                'suggestion': '',
                'has_thinking': True,
                'language': language,
                'learnings_extracted': 0
            }
    
    def save_node(self, channel, content, ai_result):
        """Save node with v4.1 enhanced structure"""
        if channel not in CHANNELS:
            raise ValueError(f"지원하지 않는 채널: {channel}")
        
        nodes = self._load()
        
        new_node = {
            "id": str(uuid.uuid4()),
            "timestamp": datetime.now().isoformat(),
            "channel": channel,
            "content": content,
            "ai_response": ai_result['raw'],
            "ai": {
                "thinking": ai_result['thinking'],
                "summary": ai_result['summary'],
                "insight": ai_result.get('insight', ''),  # 🆕
                "suggestion": ai_result.get('suggestion', ''),  # 🆕
                "has_thinking": ai_result['has_thinking'],
                "language": ai_result['language'],
                "learnings_extracted": ai_result.get('learnings_extracted', 0)
            }
        }
        
        nodes.append(new_node)
        self._save(nodes)
        memory.update_session()
        
        print(f"[저장] {CHANNELS[channel]['icon']} {channel} | ID: {new_node['id'][:8]} | 학습: {ai_result.get('learnings_extracted', 0)}개")
        
        return new_node['id']
    
    def get_nodes(self, channel_filter=None):
        nodes = self._load()
        if channel_filter and channel_filter in CHANNELS:
            nodes = [n for n in nodes if n.get('channel') == channel_filter]
        return nodes
    
    def _load(self):
        if self.nodes_path.exists():
            with open(self.nodes_path, "r", encoding="utf-8") as f:
                return json.load(f)
        return []
    
    def _save(self, nodes):
        with open(self.nodes_path, "w", encoding="utf-8") as f:
            json.dump(nodes, f, ensure_ascii=False, indent=2)

gateway = UnifiedChannelGateway()

# ═══════════════════════════════════════════════════════════
# API ENDPOINTS
# ═══════════════════════════════════════════════════════════

@app.route('/')
def index():
    return send_from_directory(FRONTEND_DIR, 'index.html')

@app.route('/whatsapp.html')
def whatsapp_page():
    return send_from_directory(FRONTEND_DIR, 'whatsapp.html')

@app.route('/api/nodes/kakao', methods=['POST'])
def kakao():
    return _handle_channel('kakao')

@app.route('/api/nodes/whatsapp', methods=['POST'])
def whatsapp():
    return _handle_channel('whatsapp')

@app.route('/api/nodes/line', methods=['POST'])
def line():
    return _handle_channel('line')

@app.route('/api/kakao', methods=['POST'])
def legacy_kakao():
    return _handle_channel('kakao')

@app.route('/api/whatsapp', methods=['POST'])
def legacy_whatsapp():
    return _handle_channel('whatsapp')

def _handle_channel(channel):
    try:
        data = request.json
        content = data.get('content', '')
        
        if not content:
            return jsonify({"status": "empty"}), 400
        
        print(f"\n[{channel.upper()}] 수신: {content[:50]}...")
        
        # AI 분석 (Proactive 3-Step + Aggressive Learning)
        ai_result = gateway.ask_ai(content)
        
        # 노드 저장
        node_id = gateway.save_node(channel, content, ai_result)
        
        res = jsonify({
            "status": "success",
            "node_id": node_id,
            "reply": ai_result['raw'],
            "learnings_extracted": ai_result.get('learnings_extracted', 0),
            "has_insight": bool(ai_result.get('insight')),
            "has_suggestion": bool(ai_result.get('suggestion'))
        })
        res.headers.add('Content-Type', 'application/json; charset=utf-8')
        return res, 200
        
    except Exception as e:
        print(f"[{channel.upper()}] 오류: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/memory/preferences', methods=['GET'])
def get_preferences():
    return jsonify(memory.get_preferences())

@app.route('/api/memory/learning', methods=['GET'])
def get_learning():
    return jsonify(memory.get_learning())

@app.route('/api/memory/session', methods=['GET'])
def get_session():
    return jsonify(memory.get_session_context())

@app.route('/api/memory/reset-session', methods=['POST'])
def reset_session():
    memory.reset_session()
    return jsonify({"status": "success", "message": "Session reset"})

@app.route('/api/nodes', methods=['GET'])
def get_nodes():
    channel_filter = request.args.get('channel')
    nodes = gateway.get_nodes(channel_filter=channel_filter)
    return jsonify(nodes)

@app.route('/api/health', methods=['GET'])
def health():
    learning_data = memory.get_learning()
    session_data = memory.get_session_context()
    
    return jsonify({
        'status': 'online',
        'version': '4.1.0',
        'mode': 'proactive',
        'response_format': '3-step',
        'learning_engine': 'aggressive',
        'memory_system': 'enabled',
        'total_nodes': len(gateway.get_nodes()),
        'total_learnings': len(learning_data.get('facts', [])),
        'session_learnings': session_data.get('learning_count', 0)
    })

# ═══════════════════════════════════════════════════════════
# SERVER STARTUP
# ═══════════════════════════════════════════════════════════

if __name__ == '__main__':
    print(f"""
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║   🧠 KIVOSY v4.1 - PROACTIVE AI INFRASTRUCTURE            ║
║                                                           ║
║         Evolution: SimSimi → Jarvis → Secretary           ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝

🎯 NEW in v4.1:
   ✅ 3-Step Response (Summary/Insight/Suggestion)
   ✅ Aggressive Learning (Regex + LLM)
   ✅ Zero-Miss Secretary Mode
   ✅ Proactive Recommendations

🧠 Memory System:
   📁 {memory.preferences_file}
   📚 {memory.learning_file}
   📊 {memory.session_file}

📡 Channels: 💬 Kakao | 🟢 WhatsApp | 💚 LINE

🚀 Dashboard: http://localhost:5000

공장장님, 이제 저는 당신의 완벽한 비서입니다! 🎯✨
""")
    
    app.run(host='0.0.0.0', port=5000, debug=False)
