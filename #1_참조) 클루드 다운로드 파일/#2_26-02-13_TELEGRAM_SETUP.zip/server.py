"""
Log-Network Backend Server - Phase 2: Messenger Gateway
KIVOSY Global Empire - Production Ready

Features:
- Complete Telegram Bot Integration (OpenClaw channel.ts pattern)
- Smart Link/Text Capture from mobile
- AI-powered summarization with thinking visualization
- Private webhook for personal use
- Multi-format content handling (text, links, voice notes)
"""

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from datetime import datetime
import json
import os
import uuid
from pathlib import Path
import requests
import re
from typing import Optional, Dict, List, Any
from dataclasses import dataclass, asdict
from urllib.parse import urlparse

app = Flask(__name__, static_folder='../frontend', static_url_path='')
CORS(app)

# ═══════════════════════════════════════════════════════════
# TELEGRAM CONFIGURATION
# ═══════════════════════════════════════════════════════════

TELEGRAM_BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')
TELEGRAM_WEBHOOK_SECRET = os.getenv('TELEGRAM_WEBHOOK_SECRET', 'your-secret-key-change-this')

# If you want to restrict to your chat ID only (recommended)
ALLOWED_CHAT_IDS = os.getenv('ALLOWED_CHAT_IDS', '').split(',') if os.getenv('ALLOWED_CHAT_IDS') else []

print(f"""
╔═══════════════════════════════════════════════════════════╗
║  TELEGRAM CONFIGURATION CHECK                             ║
╚═══════════════════════════════════════════════════════════╝

Bot Token: {'✅ Set' if TELEGRAM_BOT_TOKEN else '❌ Not set (export TELEGRAM_BOT_TOKEN)'}
Webhook Secret: {'✅ Set' if TELEGRAM_WEBHOOK_SECRET != 'your-secret-key-change-this' else '⚠️  Using default (change TELEGRAM_WEBHOOK_SECRET)'}
Allowed Chats: {ALLOWED_CHAT_IDS if ALLOWED_CHAT_IDS else '⚠️  None (accepting all chats)'}
""")

# ═══════════════════════════════════════════════════════════
# OPENCLAW-INSPIRED ARCHITECTURE
# ═══════════════════════════════════════════════════════════

@dataclass
class ThinkingSegment:
    """OpenClaw-style thinking/response segmentation"""
    kind: str  # 'thinking' or 'response'
    text: str

# ═══════════════════════════════════════════════════════════
# ASSISTANT TEXT PARSER (AssistantTextParser.swift)
# ═══════════════════════════════════════════════════════════

class AssistantTextParser:
    """
    Parse assistant responses to extract thinking vs final response
    Based on OpenClaw's AssistantTextParser.swift
    
    Supports:
    - <think>...</think> tags for reasoning
    - <final>...</final> tags for final answer
    - Mixed content with multiple segments
    """
    
    @staticmethod
    def parse_segments(raw_text: str) -> List[ThinkingSegment]:
        """Parse text into thinking and response segments"""
        trimmed = raw_text.strip()
        
        if not trimmed:
            return []
            
        if '<' not in raw_text:
            return [ThinkingSegment(kind='response', text=trimmed)]
        
        segments = []
        
        # Regex patterns for think and final tags
        think_pattern = r'<think[^>]*>(.*?)</think>'
        final_pattern = r'<final[^>]*>(.*?)</final>'
        
        # Find all matches with their positions
        think_matches = [(m.start(), m.end(), 'thinking', m.group(1).strip()) 
                         for m in re.finditer(think_pattern, raw_text, re.DOTALL | re.IGNORECASE)]
        final_matches = [(m.start(), m.end(), 'response', m.group(1).strip()) 
                         for m in re.finditer(final_pattern, raw_text, re.DOTALL | re.IGNORECASE)]
        
        # Combine and sort by position
        all_matches = sorted(think_matches + final_matches, key=lambda x: x[0])
        
        # Extract segments
        last_end = 0
        for start, end, kind, text in all_matches:
            # Add text before this tag (if any)
            if start > last_end:
                between_text = raw_text[last_end:start].strip()
                if between_text:
                    segments.append(ThinkingSegment(kind='response', text=between_text))
            
            # Add the tag content
            if text:
                segments.append(ThinkingSegment(kind=kind, text=text))
            
            last_end = end
        
        # Add remaining text after last tag
        if last_end < len(raw_text):
            remaining = raw_text[last_end:].strip()
            if remaining:
                segments.append(ThinkingSegment(kind='response', text=remaining))
        
        return segments if segments else [ThinkingSegment(kind='response', text=trimmed)]
    
    @staticmethod
    def has_visible_content(raw_text: str) -> bool:
        """Check if text has any visible content"""
        return bool(AssistantTextParser.parse_segments(raw_text))

# ═══════════════════════════════════════════════════════════
# TELEGRAM CHANNEL (OpenClaw channel.ts pattern)
# ═══════════════════════════════════════════════════════════

class TelegramChannel:
    """
    Telegram Channel Plugin (OpenClaw-inspired)
    Handles message receiving, processing, and responding
    """
    
    def __init__(self, bot_token: Optional[str] = None):
        self.bot_token = bot_token or TELEGRAM_BOT_TOKEN
        self.base_url = f"https://api.telegram.org/bot{self.bot_token}" if self.bot_token else None
        self.active = bool(self.bot_token)
        
    def send_message(self, chat_id: str, text: str, parse_mode: str = "Markdown") -> bool:
        """Send message to Telegram chat"""
        if not self.active:
            print("[Telegram] ❌ Bot not configured")
            return False
            
        try:
            response = requests.post(
                f"{self.base_url}/sendMessage",
                json={
                    "chat_id": chat_id,
                    "text": text,
                    "parse_mode": parse_mode
                },
                timeout=10
            )
            
            if response.ok:
                print(f"[Telegram] ✅ Message sent to chat {chat_id}")
                return True
            else:
                print(f"[Telegram] ❌ Send failed: {response.text}")
                return False
                
        except Exception as e:
            print(f"[Telegram] ❌ Error sending message: {e}")
            return False
    
    def send_thinking_response(self, chat_id: str, thinking: str, response: str) -> bool:
        """Send response with thinking process (formatted for Telegram)"""
        formatted = f"""💭 *Thinking Process:*
```
{thinking[:500]}...
```

📝 *Summary:*
{response}

✅ Saved to Log-Network!
"""
        return self.send_message(chat_id, formatted)
    
    def extract_links(self, text: str) -> List[str]:
        """Extract URLs from text"""
        url_pattern = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
        return re.findall(url_pattern, text)
    
    def is_youtube_link(self, url: str) -> bool:
        """Check if URL is YouTube"""
        return 'youtube.com' in url or 'youtu.be' in url
    
    def extract_youtube_id(self, url: str) -> Optional[str]:
        """Extract YouTube video ID from URL"""
        patterns = [
            r'(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&\n?#]+)',
            r'youtube\.com\/embed\/([^&\n?#]+)'
        ]
        
        for pattern in patterns:
            match = re.search(pattern, url)
            if match:
                return match.group(1)
        return None
    
    def process_telegram_update(self, update: Dict) -> Optional[Dict]:
        """
        Process Telegram update into Log-Network capture format
        Handles: text, links, voice notes, photos
        """
        message = update.get('message', {})
        
        if not message:
            return None
        
        chat_id = str(message.get('chat', {}).get('id'))
        
        # Check if chat is allowed (if restrictions enabled)
        if ALLOWED_CHAT_IDS and chat_id not in ALLOWED_CHAT_IDS:
            print(f"[Telegram] ❌ Unauthorized chat ID: {chat_id}")
            return None
        
        # Extract message content
        text = message.get('text', message.get('caption', ''))
        from_user = message.get('from', {}).get('username', message.get('from', {}).get('first_name', 'Unknown'))
        
        # Detect content type
        content_type = 'text'
        links = self.extract_links(text) if text else []
        
        if links:
            content_type = 'link'
            # Check if YouTube link
            if any(self.is_youtube_link(link) for link in links):
                content_type = 'youtube_link'
        
        if 'voice' in message:
            content_type = 'voice'
        elif 'photo' in message:
            content_type = 'photo'
        
        # Build capture data
        capture_data = {
            'source': {
                'type': 'telegram',
                'chat_id': chat_id,
                'message_id': message.get('message_id'),
                'from_user': from_user,
                'chat_type': message.get('chat', {}).get('type'),
                'content_type': content_type
            },
            'content': {
                'text': text,
                'links': links,
                'summary': text[:500] if text else 'Media content',
                'tags': ['telegram', content_type, 'mobile-capture']
            },
            'metadata': {
                'captured_at': datetime.fromtimestamp(message.get('date', 0)).isoformat(),
                'platform': 'telegram',
                'needs_ai_summary': True  # Flag for AI processing
            }
        }
        
        return capture_data

# Initialize Telegram channel
telegram_channel = TelegramChannel()

# ═══════════════════════════════════════════════════════════
# LLM CONFIGURATION WITH THINKING SUPPORT
# ═══════════════════════════════════════════════════════════

LLM_CONFIG = {
    'local': {
        'enabled': True,
        'endpoint': 'http://localhost:1234/v1/chat/completions',
        'model': 'local-model',
        'api_key': 'not-needed',
        'supports_thinking': True
    },
    'cloud': {
        'enabled': False,
        'endpoint': 'https://api.openai.com/v1/chat/completions',
        'model': 'gpt-3.5-turbo',
        'api_key': os.getenv('OPENAI_API_KEY', 'your-api-key-here'),
        'supports_thinking': False
    },
    'active': 'local'
}

if LLM_CONFIG['local']['enabled']:
    LLM_CONFIG['active'] = 'local'
elif LLM_CONFIG['cloud']['enabled']:
    LLM_CONFIG['active'] = 'cloud'

SUPPORTED_LANGUAGES = ['en', 'ko', 'ja', 'es', 'fr', 'de', 'it', 'pt', 'zh']

# ═══════════════════════════════════════════════════════════
# DATA MANAGEMENT
# ═══════════════════════════════════════════════════════════

DATA_DIR = Path(__file__).parent / 'data'
NODES_FILE = DATA_DIR / 'nodes.json'

DATA_DIR.mkdir(exist_ok=True)

if not NODES_FILE.exists():
    with open(NODES_FILE, 'w', encoding='utf-8') as f:
        json.dump({
            'nodes': [],
            'metadata': {
                'version': '2.0',
                'created_at': datetime.utcnow().isoformat(),
                'supported_languages': SUPPORTED_LANGUAGES,
                'llm_config': LLM_CONFIG['active'],
                'channels': ['youtube', 'telegram']
            }
        }, f, indent=2, ensure_ascii=False)

def load_nodes():
    with open(NODES_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_nodes(data):
    with open(NODES_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def calculate_dust_level(timestamp):
    try:
        created = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
        age_hours = (datetime.utcnow() - created.replace(tzinfo=None)).total_seconds() / 3600
        
        if age_hours < 1: return 0.0
        elif age_hours < 24: return 0.2
        elif age_hours < 72: return 0.4
        elif age_hours < 168: return 0.6
        else: return 0.8
    except:
        return 0.0

# ═══════════════════════════════════════════════════════════
# SMART AI SUMMARIZATION WITH THINKING
# ═══════════════════════════════════════════════════════════

def call_llm(prompt: str, system_message: str = "You are a helpful assistant.", 
             enable_thinking: bool = True) -> Dict[str, Any]:
    """
    Call LLM with thinking support
    Always enables thinking for Telegram captures
    """
    config = LLM_CONFIG[LLM_CONFIG['active']]
    
    try:
        headers = {'Content-Type': 'application/json'}
        
        if LLM_CONFIG['active'] == 'cloud':
            headers['Authorization'] = f"Bearer {config['api_key']}"
        
        # Enhanced prompt for thinking
        if enable_thinking and config.get('supports_thinking'):
            system_message += """

You MUST use this format:
<think>
[Your step-by-step reasoning process here]
</think>

<final>
[Your concise final answer here]
</final>

This is mandatory - always include both thinking and final sections.
"""
        
        payload = {
            'model': config['model'],
            'messages': [
                {'role': 'system', 'content': system_message},
                {'role': 'user', 'content': prompt}
            ],
            'temperature': 0.7,
            'max_tokens': 1500
        }
        
        response = requests.post(
            config['endpoint'],
            headers=headers,
            json=payload,
            timeout=30
        )
        
        if response.ok:
            result = response.json()
            raw_text = result['choices'][0]['message']['content']
            
            # Parse with AssistantTextParser
            segments = AssistantTextParser.parse_segments(raw_text)
            
            # Extract thinking and response
            thinking_parts = [s.text for s in segments if s.kind == 'thinking']
            response_parts = [s.text for s in segments if s.kind == 'response']
            
            return {
                'success': True,
                'text': '\n\n'.join(response_parts) if response_parts else raw_text,
                'thinking': '\n\n'.join(thinking_parts) if thinking_parts else None,
                'segments': [{'kind': s.kind, 'text': s.text} for s in segments],
                'raw': raw_text
            }
        else:
            print(f"[LLM] ❌ Error: {response.status_code}")
            return {'success': False, 'text': None, 'thinking': None}
            
    except Exception as e:
        print(f"[LLM] ❌ Exception: {str(e)}")
        return {'success': False, 'text': None, 'thinking': None}

def smart_summarize_telegram_content(capture_data: Dict) -> Dict:
    """
    Smart summarization for Telegram content
    Handles: text, links, YouTube links
    ALWAYS includes thinking process
    """
    content_type = capture_data.get('source', {}).get('content_type', 'text')
    text = capture_data.get('content', {}).get('text', '')
    links = capture_data.get('content', {}).get('links', [])
    
    # Build context-aware prompt
    if content_type == 'youtube_link':
        prompt = f"""I received a YouTube link via Telegram: {links[0]}

Analyze what this content might be about based on the URL and any accompanying text: "{text}"

Provide a brief summary of what this YouTube video likely covers."""

    elif content_type == 'link':
        prompt = f"""I received a link via Telegram: {links[0]}

Text context: "{text}"

Analyze this and provide a brief summary of what this content is likely about."""

    else:  # text
        prompt = f"""I sent myself this note via Telegram: "{text}"

Summarize the key point or create a useful title for this note."""
    
    system_prompt = """You are a personal knowledge assistant analyzing content I've sent myself via Telegram.
Be concise but insightful. Help me organize my thoughts."""
    
    # ALWAYS enable thinking for Telegram
    result = call_llm(prompt, system_prompt, enable_thinking=True)
    
    if not result.get('success'):
        # Fallback
        return {
            'summary': text[:200] if text else 'Telegram capture',
            'thinking': 'AI summarization unavailable',
            'segments': []
        }
    
    return {
        'summary': result.get('text', text[:200]),
        'thinking': result.get('thinking'),
        'segments': result.get('segments', [])
    }

# ═══════════════════════════════════════════════════════════
# API ENDPOINTS
# ═══════════════════════════════════════════════════════════

@app.route('/')
def index():
    return send_from_directory('../frontend', 'index.html')

@app.route('/api/health', methods=['GET'])
def health():
    """Health check"""
    data = load_nodes()
    
    languages_in_use = set()
    for node in data.get('nodes', []):
        lang = node.get('source_metadata', {}).get('language', 'en')
        languages_in_use.add(lang)
    
    return jsonify({
        'ok': True,
        'status': 'online',
        'nodes': len(data['nodes']),
        'version': '2.0.0',
        'timestamp': datetime.utcnow().isoformat(),
        'llm_mode': LLM_CONFIG['active'],
        'thinking_enabled': LLM_CONFIG[LLM_CONFIG['active']].get('supports_thinking', False),
        'channels': {
            'youtube': True,
            'telegram': telegram_channel.active
        },
        'telegram_config': {
            'active': telegram_channel.active,
            'restricted': bool(ALLOWED_CHAT_IDS),
            'allowed_chats': len(ALLOWED_CHAT_IDS) if ALLOWED_CHAT_IDS else 'all'
        }
    })

# ═══════════════════════════════════════════════════════════
# TELEGRAM WEBHOOK - THE CORE FEATURE
# ═══════════════════════════════════════════════════════════

@app.route('/api/telegram/webhook', methods=['POST'])
def telegram_webhook():
    """
    Telegram Webhook Endpoint (OpenClaw channel pattern)
    
    This is your private gateway!
    Receives messages from your phone → Smart AI summary → Dashboard
    """
    if not telegram_channel.active:
        return jsonify({'error': 'Telegram not configured'}), 503
    
    try:
        update = request.json
        
        print(f"\n[Telegram Webhook] 📨 Received update: {update.get('update_id')}")
        
        # Process update
        capture_data = telegram_channel.process_telegram_update(update)
        
        if not capture_data:
            print("[Telegram Webhook] ⚠️  Update ignored (no message or unauthorized)")
            return jsonify({'ok': True, 'processed': False})
        
        print(f"[Telegram Webhook] 📝 Processing: {capture_data['source']['content_type']}")
        
        # Smart AI summarization with thinking
        ai_result = smart_summarize_telegram_content(capture_data)
        
        print(f"[Telegram Webhook] 🤖 AI Summary generated")
        print(f"[Telegram Webhook] 💭 Thinking: {'Yes' if ai_result.get('thinking') else 'No'}")
        
        # Build node
        node_id = str(uuid.uuid4())
        detected_language = 'en'  # Could be enhanced with language detection
        
        node = {
            'node_id': node_id,
            'parent_id': None,
            'timestamp': capture_data.get('metadata', {}).get('captured_at', datetime.utcnow().isoformat()),
            'source_metadata': capture_data.get('source', {}),
            'content_summary': ai_result['summary'],
            'tags': capture_data.get('content', {}).get('tags', []),
            'context_snapshot': {
                'last_interaction': ai_result['summary'],
                'brain_state': 'Telegram mobile capture',
                'thinking_process': ai_result.get('thinking'),  # 💭 THINKING STORED
                'segments': ai_result.get('segments', []),
                'original_text': capture_data.get('content', {}).get('text', ''),
                'links': capture_data.get('content', {}).get('links', []),
                'llm_mode': LLM_CONFIG['active']
            },
            'visual_state': {
                'dust_level': 0.0,
                'opacity': 1.0,
                'color': '#667eea'
            },
            'i18n': {
                'detected_language': detected_language,
                'content_language': detected_language
            }
        }
        
        # Save node
        data = load_nodes()
        data['nodes'].append(node)
        data['metadata']['last_updated'] = datetime.utcnow().isoformat()
        save_nodes(data)
        
        print(f"[Telegram Webhook] ✅ Node saved: {node_id}")
        
        # Send confirmation back to Telegram
        chat_id = capture_data['source']['chat_id']
        
        if ai_result.get('thinking'):
            telegram_channel.send_thinking_response(
                chat_id,
                ai_result['thinking'][:500],  # Truncate for Telegram
                ai_result['summary']
            )
        else:
            telegram_channel.send_message(
                chat_id,
                f"✅ *Captured!*\n\n{ai_result['summary']}\n\n_Saved to Log-Network_"
            )
        
        return jsonify({
            'ok': True,
            'processed': True,
            'node_id': node_id,
            'thinking_captured': bool(ai_result.get('thinking'))
        })
        
    except Exception as e:
        print(f"[Telegram Webhook] ❌ Error: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'ok': False, 'error': str(e)}), 500

@app.route('/api/telegram/send', methods=['POST'])
def telegram_send():
    """Send message via Telegram (for testing)"""
    if not telegram_channel.active:
        return jsonify({'error': 'Telegram not configured'}), 400
    
    data = request.json
    chat_id = data.get('chat_id')
    text = data.get('text')
    
    if not chat_id or not text:
        return jsonify({'error': 'Missing chat_id or text'}), 400
    
    success = telegram_channel.send_message(chat_id, text)
    
    return jsonify({'success': success})

@app.route('/api/telegram/get-me', methods=['GET'])
def telegram_get_me():
    """Get bot information (for setup verification)"""
    if not telegram_channel.active:
        return jsonify({'error': 'Telegram not configured'}), 400
    
    try:
        response = requests.get(f"{telegram_channel.base_url}/getMe", timeout=10)
        if response.ok:
            return jsonify(response.json())
        return jsonify({'error': response.text}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ═══════════════════════════════════════════════════════════
# STANDARD ENDPOINTS (from previous version)
# ═══════════════════════════════════════════════════════════

@app.route('/api/capture', methods=['POST'])
def capture():
    """Multi-channel capture endpoint"""
    try:
        capture_data = request.json
        node_id = str(uuid.uuid4())
        
        detected_language = capture_data.get('source', {}).get('language', 'en')
        channel_type = capture_data.get('source', {}).get('type', 'unknown')
        
        node = {
            'node_id': node_id,
            'parent_id': None,
            'timestamp': capture_data.get('metadata', {}).get('captured_at', datetime.utcnow().isoformat()),
            'source_metadata': capture_data.get('source', {}),
            'content_summary': capture_data.get('content', {}).get('summary', ''),
            'tags': capture_data.get('content', {}).get('tags', []),
            'context_snapshot': {
                'last_interaction': capture_data.get('content', {}).get('summary', ''),
                'brain_state': 'Initial capture',
                'metadata': capture_data.get('metadata', {}),
                'llm_mode': LLM_CONFIG['active']
            },
            'visual_state': {
                'dust_level': 0.0,
                'opacity': 1.0,
                'color': '#667eea'
            },
            'i18n': {
                'detected_language': detected_language,
                'content_language': detected_language
            }
        }
        
        data = load_nodes()
        data['nodes'].append(node)
        data['metadata']['last_updated'] = datetime.utcnow().isoformat()
        save_nodes(data)
        
        return jsonify({
            'success': True,
            'node_id': node_id,
            'channel': channel_type
        }), 201
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/nodes', methods=['GET'])
def get_nodes():
    data = load_nodes()
    for node in data['nodes']:
        node['visual_state']['dust_level'] = calculate_dust_level(node['timestamp'])
        node['visual_state']['opacity'] = 1.0 - (node['visual_state']['dust_level'] * 0.5)
    return jsonify(data)

@app.route('/api/nodes/<node_id>/context', methods=['GET'])
def get_context(node_id):
    data = load_nodes()
    node = next((n for n in data['nodes'] if n['node_id'] == node_id), None)
    
    if not node:
        return jsonify({'error': 'Node not found'}), 404
    
    language = node.get('i18n', {}).get('detected_language', 'en')
    thinking = node.get('context_snapshot', {}).get('thinking_process', '')
    
    context_prompt = f"""[CONTEXT INJECTION - Previous Session]

Language: {language.upper()}
Source: {node['source_metadata'].get('type', 'unknown').upper()}
Title: {node['source_metadata'].get('title', 'Untitled')}

Summary: {node['content_summary']}
"""
    
    if thinking:
        context_prompt += f"""
AI Reasoning Process:
{thinking}
"""
    
    context_prompt += """
---
Continue from this context.
"""
    
    return jsonify({
        'node_id': node_id,
        'context_prompt': context_prompt,
        'has_thinking': bool(thinking)
    })

@app.route('/api/stats', methods=['GET'])
def get_stats():
    data = load_nodes()
    nodes = data['nodes']
    
    telegram_nodes = len([n for n in nodes if n['source_metadata'].get('type') == 'telegram'])
    thinking_nodes = len([n for n in nodes if n.get('context_snapshot', {}).get('thinking_process')])
    
    return jsonify({
        'total_nodes': len(nodes),
        'telegram_captures': telegram_nodes,
        'thinking_enhanced': thinking_nodes,
        'dusty_nodes': len([n for n in nodes if calculate_dust_level(n['timestamp']) > 0.5]),
        'channels': {
            'telegram': telegram_nodes
        }
    })

# ═══════════════════════════════════════════════════════════
# SERVER STARTUP
# ═══════════════════════════════════════════════════════════

if __name__ == '__main__':
    telegram_status = "✅ Active" if telegram_channel.active else "❌ Disabled"
    
    print(f"""
    ╔═══════════════════════════════════════════════════════════╗
    ║                                                           ║
    ║      🏭 LOG-NETWORK PHASE 2: MESSENGER GATEWAY            ║
    ║                                                           ║
    ║         KIVOSY Global Empire - Production Ready           ║
    ║                                                           ║
    ╚═══════════════════════════════════════════════════════════╝
    
    Server: http://localhost:5000
    
    🔧 Configuration:
       • LLM: {LLM_CONFIG['active'].upper()}
       • Thinking: ✅ Always enabled for Telegram
       • Telegram Bot: {telegram_status}
       • Private Mode: {'✅ Enabled' if ALLOWED_CHAT_IDS else '⚠️  Disabled (all chats accepted)'}
    
    📡 Telegram Endpoints:
       • POST /api/telegram/webhook    - 📨 Main webhook (set this in Telegram)
       • POST /api/telegram/send        - 📤 Send test message
       • GET  /api/telegram/get-me      - ℹ️  Bot info
    
    📊 Dashboard: http://localhost:5000
    
    🚀 Ready to capture from your phone!
    """)
    
    app.run(host='0.0.0.0', port=5000, debug=True)
