# 🏭 Telegram Bot Setup Guide - Phase 2: Messenger Gateway

**Complete step-by-step guide to set up your private Telegram capture bot**

---

## 📋 Quick Setup (5 Minutes)

### Step 1: Create Telegram Bot

1. **Open Telegram** on your phone or desktop
2. **Search for** `@BotFather`
3. **Start chat** with BotFather
4. **Send:** `/newbot`
5. **Follow prompts:**
   ```
   BotFather: Alright, a new bot. How are we going to call it?
   You: Log-Network Bot
   
   BotFather: Good. Now choose a username for your bot.
   You: kivosy_lognetwork_bot
   
   BotFather: Done! Your token is: 123456789:ABCdefGHIjklMNOpqrsTUVwxyz
   ```

6. **SAVE THE TOKEN!** You'll need it in Step 2

### Step 2: Configure Server

**On Mac/Linux:**
```bash
export TELEGRAM_BOT_TOKEN="123456789:ABCdefGHIjklMNOpqrsTUVwxyz"
export TELEGRAM_WEBHOOK_SECRET="your-super-secret-key-change-this"
```

**On Windows (PowerShell):**
```powershell
$env:TELEGRAM_BOT_TOKEN="123456789:ABCdefGHIjklMNOpqrsTUVwxyz"
$env:TELEGRAM_WEBHOOK_SECRET="your-super-secret-key-change-this"
```

**Permanent (add to ~/.bashrc or ~/.zshrc):**
```bash
echo 'export TELEGRAM_BOT_TOKEN="123456789:ABCdefGHIjklMNOpqrsTUVwxyz"' >> ~/.bashrc
source ~/.bashrc
```

### Step 3: (Optional) Enable Private Mode

**Get your Chat ID:**
1. Message your bot on Telegram: `/start`
2. Visit: `https://api.telegram.org/bot<YOUR_TOKEN>/getUpdates`
3. Look for `"chat":{"id":123456789}`

**Configure:**
```bash
export ALLOWED_CHAT_IDS="123456789,987654321"  # Comma-separated if multiple
```

### Step 4: Start Server

```bash
cd backend
pip install -r requirements.txt
python server.py
```

**Look for:**
```
╔═══════════════════════════════════════════════════════════╗
║  TELEGRAM CONFIGURATION CHECK                             ║
╚═══════════════════════════════════════════════════════════╝

Bot Token: ✅ Set
Webhook Secret: ✅ Set
Allowed Chats: ['123456789']
```

### Step 5: Set Webhook (For Production)

**Development (localhost - skip this for now):**
Just use polling or manual testing

**Production (when deployed):**
```bash
curl -X POST "https://api.telegram.org/bot<YOUR_TOKEN>/setWebhook" \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://yourdomain.com/api/telegram/webhook",
    "secret_token": "your-super-secret-key-change-this"
  }'
```

---

## 🧪 Testing Your Bot

### Test 1: Verify Bot is Alive

```bash
curl http://localhost:5000/api/telegram/get-me
```

**Expected Response:**
```json
{
  "ok": true,
  "result": {
    "id": 123456789,
    "is_bot": true,
    "first_name": "Log-Network Bot",
    "username": "kivosy_lognetwork_bot"
  }
}
```

### Test 2: Send Test Message

**Get your chat ID first:**
1. Message your bot: `/start`
2. Check server logs for chat ID

**Send via API:**
```bash
curl -X POST http://localhost:5000/api/telegram/send \
  -H "Content-Type: application/json" \
  -d '{
    "chat_id": "123456789",
    "text": "Hello from Log-Network! 🧠"
  }'
```

### Test 3: Capture from Phone

**Simple text:**
```
Send to bot: "Remember to buy groceries tomorrow"
```

**Expected:**
- ✅ Server logs show webhook received
- ✅ AI generates summary with thinking
- ✅ Bot replies with confirmation
- ✅ Dashboard shows new node with 💭 badge

**Link capture:**
```
Send to bot: "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
```

**Expected:**
- ✅ Bot detects YouTube link
- ✅ AI analyzes what the video is about
- ✅ Stores with thinking process

---

## 🔧 Configuration Options

### Option 1: Open Mode (Anyone Can Use)

**Default behavior** - Any Telegram user can message your bot

```bash
# Don't set ALLOWED_CHAT_IDS
# Bot accepts all chats
```

**Use case:** Public knowledge capture bot

### Option 2: Private Mode (Recommended)

**Only you (and approved users) can use the bot**

```bash
export ALLOWED_CHAT_IDS="123456789"  # Your chat ID only
```

**Use case:** Personal knowledge management

### Option 3: Team Mode

**Multiple authorized users**

```bash
export ALLOWED_CHAT_IDS="123456789,987654321,555555555"
```

**Use case:** Team knowledge sharing

---

## 📱 How to Use from Your Phone

### Scenario 1: Quick Text Note

**You:** `Meeting with client tomorrow at 3pm - need to prepare proposal deck`

**Bot Response:**
```
💭 Thinking Process:
This is a reminder about an upcoming meeting that requires preparation...

📝 Summary:
Meeting reminder: Prepare proposal deck for 3pm client meeting tomorrow

✅ Saved to Log-Network!
```

### Scenario 2: Link Sharing

**You:** `https://www.youtube.com/watch?v=interesting-video`

**Bot Response:**
```
💭 Thinking Process:
Analyzing YouTube link... Based on the video ID, this appears to be...

📝 Summary:
YouTube video about [topic] - likely covers [aspects]

✅ Saved to Log-Network!
```

### Scenario 3: Article Link

**You:** `https://techcrunch.com/article-about-ai`

**Bot Response:**
```
💭 Thinking Process:
This is a TechCrunch article, likely about AI technology...

📝 Summary:
Tech article: AI developments and industry analysis

✅ Saved to Log-Network!
```

### Scenario 4: Context from Previous

**You:** `Also remember to include Q3 results in the deck`

**Bot Response:**
```
📝 Summary:
Additional meeting preparation: Include Q3 results in proposal deck

✅ Saved to Log-Network!
```

---

## 🏗️ Architecture Deep Dive

### Message Flow

```
┌─────────────────┐
│  Your Phone     │
│  (Telegram App) │
└────────┬────────┘
         │
         │ 1. Send message/link
         ▼
┌─────────────────┐
│  Telegram API   │
│  (Cloud)        │
└────────┬────────┘
         │
         │ 2. Webhook POST
         ▼
┌─────────────────────────────┐
│  /api/telegram/webhook      │
│  (Your Server)              │
└────────┬────────────────────┘
         │
         │ 3. Extract content
         ▼
┌─────────────────────────────┐
│  TelegramChannel            │
│  .process_telegram_update() │
└────────┬────────────────────┘
         │
         │ 4. Detect type (text/link/youtube)
         ▼
┌─────────────────────────────┐
│  smart_summarize_...()      │
│  (AI + Thinking)            │
└────────┬────────────────────┘
         │
         │ 5. Call LLM with thinking enabled
         ▼
┌─────────────────────────────┐
│  AssistantTextParser        │
│  .parse_segments()          │
└────────┬────────────────────┘
         │
         │ 6. Extract <think> and <final>
         ▼
┌─────────────────────────────┐
│  Save to nodes.json         │
│  + thinking_process         │
│  + segments                 │
└────────┬────────────────────┘
         │
         │ 7. Send confirmation
         ▼
┌─────────────────┐
│  Your Phone     │
│  ✅ Saved!      │
└─────────────────┘
```

### Data Captured

Every Telegram message creates a node with:

```json
{
  "node_id": "uuid",
  "source_metadata": {
    "type": "telegram",
    "chat_id": "123456789",
    "message_id": 42,
    "from_user": "YourUsername",
    "content_type": "link"  // or "text", "youtube_link"
  },
  "content_summary": "AI-generated summary",
  "context_snapshot": {
    "thinking_process": "Step 1: Analyze the link...",  // 💭
    "segments": [
      {"kind": "thinking", "text": "..."},
      {"kind": "response", "text": "..."}
    ],
    "original_text": "Original message text",
    "links": ["https://..."]
  }
}
```

---

## 🔒 Security Best Practices

### 1. Secret Token

**Why:** Prevents unauthorized webhook calls

**How:**
```bash
export TELEGRAM_WEBHOOK_SECRET="use-a-long-random-string-here"
```

**Generate secure secret:**
```bash
openssl rand -hex 32
# Output: a1b2c3d4e5f6...
```

### 2. HTTPS Only (Production)

**Why:** Telegram requires HTTPS for webhooks

**Options:**
- Deploy to Heroku/Railway (free HTTPS)
- Use ngrok for local development
- Cloudflare Tunnel

### 3. Rate Limiting

**Why:** Prevent abuse

**How:** (Future enhancement)
```python
from flask_limiter import Limiter

limiter = Limiter(app, default_limits=["100 per hour"])

@app.route('/api/telegram/webhook')
@limiter.limit("10 per minute")
def telegram_webhook():
    ...
```

### 4. Chat ID Whitelist

**Why:** Only you can use the bot

**How:**
```bash
export ALLOWED_CHAT_IDS="123456789"  # Your ID only
```

---

## 🐛 Troubleshooting

### Problem: "Bot Token: ❌ Not set"

**Solution:**
```bash
# Check environment variable
echo $TELEGRAM_BOT_TOKEN

# If empty, set it:
export TELEGRAM_BOT_TOKEN="your-token-here"

# Make permanent:
echo 'export TELEGRAM_BOT_TOKEN="..."' >> ~/.bashrc
```

### Problem: Bot doesn't respond to messages

**Debug steps:**
1. Check server logs for webhook received
2. Verify bot token: `curl http://localhost:5000/api/telegram/get-me`
3. Check `ALLOWED_CHAT_IDS` if private mode enabled
4. Verify LLM is running (if using local)

### Problem: "Unauthorized chat ID"

**Solution:**
Get your chat ID:
```bash
# Message your bot
# Then check:
curl "https://api.telegram.org/bot<YOUR_TOKEN>/getUpdates"

# Look for: "chat":{"id":123456789}
# Add to environment:
export ALLOWED_CHAT_IDS="123456789"
```

### Problem: Thinking not showing

**Solution:**
1. Check `supports_thinking: True` in server.py line 46
2. Verify LLM is using thinking tags
3. Check server logs for "💭 Thinking: Yes"

### Problem: Webhook not receiving messages

**For Production:**
1. Verify webhook is set:
   ```bash
   curl "https://api.telegram.org/bot<TOKEN>/getWebhookInfo"
   ```
2. Check URL is HTTPS
3. Verify secret token matches

**For Development:**
Use polling instead (future feature) or test manually

---

## 🚀 Advanced Features

### Feature 1: Voice Notes (Future)

```python
# In process_telegram_update():
if 'voice' in message:
    # Download voice file
    # Transcribe with Whisper
    # Summarize transcription
```

### Feature 2: Photo Capture (Future)

```python
if 'photo' in message:
    # Download photo
    # OCR text extraction
    # Image analysis with GPT-4V
```

### Feature 3: Forwarded Messages

**Scenario:** Forward interesting message from another chat

**Implementation:**
```python
if 'forward_from' in message:
    # Extract original sender info
    # Preserve context
```

---

## 📊 Usage Patterns

### Daily Knowledge Capture

**Morning:**
```
"Goals for today: Finish report, call supplier, review contracts"
```

**Throughout day:**
```
[Forward interesting Telegram messages]
[Share article links]
[Voice notes with ideas]
```

**Evening:**
```
"Meeting notes: Client wants revised timeline"
```

### Research Mode

```
[YouTube video about topic]
[Article link]
[PDF document]
"Summary: Key points are X, Y, Z"
```

### Team Collaboration

**Team member sends:**
```
"New competitor launched similar product - analyze this"
[competitor website link]
```

**Bot captures with thinking:**
```
💭 Competitive analysis needed...
📝 Summary: Monitor competitor X for market positioning
```

---

## ✅ Success Checklist

After setup, verify:

- [ ] Bot token configured (`echo $TELEGRAM_BOT_TOKEN`)
- [ ] Server starts without errors
- [ ] "Telegram Bot: ✅ Active" in startup message
- [ ] `/api/telegram/get-me` returns bot info
- [ ] Send message to bot → Receive confirmation
- [ ] Check dashboard → See new node with ✈️ badge
- [ ] Node has 💭 thinking badge
- [ ] Click node → See thinking process
- [ ] "View Context" shows complete capture

---

## 🎯 Quick Reference

### Environment Variables

```bash
TELEGRAM_BOT_TOKEN="123456:ABC..."           # Required
TELEGRAM_WEBHOOK_SECRET="random-secret"      # Recommended
ALLOWED_CHAT_IDS="123,456,789"               # Optional (private mode)
OPENAI_API_KEY="sk-..."                      # If using cloud LLM
```

### Common Commands

```bash
# Start server
python server.py

# Test bot
curl http://localhost:5000/api/telegram/get-me

# Send test message
curl -X POST http://localhost:5000/api/telegram/send \
  -H "Content-Type: application/json" \
  -d '{"chat_id":"YOUR_ID","text":"Test"}'

# Check webhook (production)
curl "https://api.telegram.org/bot<TOKEN>/getWebhookInfo"
```

---

**🎉 Your Telegram Bot is Ready!**

**Start capturing knowledge from your phone! 📱🧠**
