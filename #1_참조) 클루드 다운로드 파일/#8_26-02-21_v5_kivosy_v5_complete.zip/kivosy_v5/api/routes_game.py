"""KIVOSY v5.0 - Soul Engine / Game API Routes"""

from flask import Blueprint, jsonify

game_bp = Blueprint("game", __name__, url_prefix="/api/v1/game")

_soul_engine = None

def set_soul_engine(soul_engine):
    global _soul_engine
    _soul_engine = soul_engine


@game_bp.route("/vibe", methods=["GET"])
def game_vibe():
    """Anonymized mood/vibe data for external game servers."""
    try:
        data = _soul_engine.get_anonymized_export()
        return jsonify({"status": "success", "data": data}), 200
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500
