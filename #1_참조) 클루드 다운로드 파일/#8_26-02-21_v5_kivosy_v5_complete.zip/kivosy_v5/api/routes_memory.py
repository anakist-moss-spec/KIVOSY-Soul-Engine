"""KIVOSY v5.0 - Memory API Routes"""

from flask import Blueprint, jsonify

memory_bp = Blueprint("memory", __name__, url_prefix="/api/memory")

_memory = None

def set_memory(memory):
    global _memory
    _memory = memory


@memory_bp.route("/preferences", methods=["GET"])
def get_preferences():
    return jsonify(_memory.get_preferences())

@memory_bp.route("/learning", methods=["GET"])
def get_learning():
    return jsonify(_memory.get_learning())

@memory_bp.route("/session", methods=["GET"])
def get_session():
    return jsonify(_memory.get_session_context())

@memory_bp.route("/reset-session", methods=["POST"])
def reset_session():
    _memory.reset_session()
    return jsonify({"status": "success", "message": "Session reset"})
