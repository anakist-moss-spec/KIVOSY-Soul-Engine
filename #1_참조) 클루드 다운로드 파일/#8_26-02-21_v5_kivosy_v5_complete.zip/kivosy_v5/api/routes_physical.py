"""
KIVOSY v5.0 - Physical Action API Routes
Responsibility: HTTP endpoints for /api/physical/*
All actions require human-in-the-loop approval.
"""

from flask import Blueprint, jsonify, request

# PhysicalExecutor is instantiated lazily to avoid import errors
# when pyautogui is not installed.
_executor = None

def get_executor():
    global _executor
    if _executor is None:
        from physical import PhysicalExecutor
        _executor = PhysicalExecutor(auto_approve=False)
    return _executor


physical_bp = Blueprint("physical", __name__, url_prefix="/api/physical")


@physical_bp.route("/status", methods=["GET"])
def physical_status():
    """물리적 액션 모듈 상태 확인."""
    try:
        status = get_executor().status()
        return jsonify({"status": "ok", "executor": status})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


@physical_bp.route("/screenshot", methods=["GET"])
def take_screenshot():
    """화면 캡처 (승인 불필요)."""
    try:
        import io, base64
        executor = get_executor()
        img = executor.screenshot()
        if img is None:
            return jsonify({"status": "error", "message": "캡처 실패"}), 500

        buf = io.BytesIO()
        img.save(buf, format="PNG")
        encoded = base64.b64encode(buf.getvalue()).decode("utf-8")
        return jsonify({"status": "success", "image_base64": encoded})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


@physical_bp.route("/emergency-stop", methods=["POST"])
def emergency_stop():
    """즉시 모든 물리적 액션 중단."""
    get_executor().emergency_stop()
    return jsonify({"status": "stopped"})


@physical_bp.route("/click", methods=["POST"])
def click():
    """
    좌표 클릭 (사람 승인 필요).
    Body: {"x": int, "y": int, "description": str}
    """
    data = request.json or {}
    x    = data.get("x")
    y    = data.get("y")
    desc = data.get("description", "")

    if x is None or y is None:
        return jsonify({"status": "error", "message": "x, y 필드 필요"}), 400

    try:
        success = get_executor().click(int(x), int(y), description=desc)
        return jsonify({"status": "success" if success else "denied"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500
