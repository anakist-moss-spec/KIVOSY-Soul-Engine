"""KIVOSY v5.0 - Channel API Routes"""

from flask import Blueprint, jsonify, request

channels_bp = Blueprint("channels", __name__)

# Gateway injected at app startup
_gateway = None

def set_gateway(gateway):
    global _gateway
    _gateway = gateway


def _handle_channel(channel: str):
    data    = request.json or {}
    content = data.get("content", "")
    if not content:
        return jsonify({"status": "empty"}), 400

    try:
        result     = _gateway.process_message(channel, content)
        ai_result  = result["ai_result"]
        return jsonify({
            "status":             "success",
            "node_id":            result["node_id"],
            "reply":              ai_result["raw"],
            "learnings_extracted": result["learnings_extracted"],
        }), 200
    except Exception as e:
        print(f"[{channel.upper()}] 오류: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500


@channels_bp.route("/api/nodes/kakao",    methods=["POST"])
@channels_bp.route("/api/kakao",          methods=["POST"])
def kakao():
    return _handle_channel("kakao")

@channels_bp.route("/api/nodes/whatsapp", methods=["POST"])
@channels_bp.route("/api/whatsapp",       methods=["POST"])
def whatsapp():
    return _handle_channel("whatsapp")

@channels_bp.route("/api/nodes/line",     methods=["POST"])
def line():
    return _handle_channel("line")
