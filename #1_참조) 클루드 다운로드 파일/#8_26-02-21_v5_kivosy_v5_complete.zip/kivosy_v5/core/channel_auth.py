"""
KIVOSY v5.0 - Channel Authentication Module
Responsibility: Channel trust management and pairing only.
"""

import hmac
import json
import secrets
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List


class ChannelTrust(Enum):
    """
    채널별 신뢰도 등급.

    OWNER   : 공장장이 직접 페어링 확인한 채널. 보안 심사 완화.
    TRUSTED : 알려진 채널이지만 공장장 페어링 미확인.
    EXTERNAL: 외부/미확인 채널. 최대 보안.

    ※ OWNER 등급도 보안을 "끄는" 것이 아닙니다.
       MasterTruthTable과 크리티컬 패턴은 항상 작동합니다.
    """
    OWNER    = "owner"
    TRUSTED  = "trusted"
    EXTERNAL = "external"


class ChannelAuthenticator:
    """
    채널 인증 및 신뢰도 관리.

    사용 방법:
        auth = ChannelAuthenticator()
        token = auth.generate_pairing_token('kakao')
        auth.confirm_pairing('kakao', token)
        trust = auth.get_trust('kakao')  # ChannelTrust.OWNER
    """

    KNOWN_CHANNELS = ("kakao", "whatsapp", "line")

    def __init__(self, pairing_file: str = "memory/channel_pairings.json"):
        self._file = Path(pairing_file)
        self._file.parent.mkdir(parents=True, exist_ok=True)
        self._data: Dict[str, Any] = self._load()

    # ── Pairing ──────────────────────────────────────────

    def generate_pairing_token(self, channel: str) -> str:
        """공장장이 채널을 인증할 때 사용할 일회용 토큰 발급."""
        token = secrets.token_urlsafe(32)
        expires_at = (datetime.now() + timedelta(minutes=10)).isoformat()

        self._data.setdefault("pending_tokens", {})[channel] = {
            "token":      token,
            "expires_at": expires_at,
            "created_at": datetime.now().isoformat(),
        }
        self._save()
        print(f"[Auth] 🔑 Pairing token for '{channel}': {token[:8]}... (10분 유효)")
        return token

    def confirm_pairing(self, channel: str, token: str) -> bool:
        """토큰 검증 후 채널을 OWNER 등급으로 승격."""
        pending = self._data.get("pending_tokens", {}).get(channel)
        if not pending:
            print(f"[Auth] ❌ No pending token for '{channel}'")
            return False

        if datetime.now() > datetime.fromisoformat(pending["expires_at"]):
            print(f"[Auth] ❌ Token expired for '{channel}'")
            return False

        if not hmac.compare_digest(pending["token"], token):
            print(f"[Auth] ❌ Invalid token for '{channel}'")
            return False

        self._data.setdefault("owner_channels", {})[channel] = {
            "paired_at": datetime.now().isoformat(),
            "channel":   channel,
        }
        del self._data["pending_tokens"][channel]
        self._save()
        print(f"[Auth] ✅ '{channel}' → OWNER 등급 승격 완료")
        return True

    def revoke_pairing(self, channel: str):
        """채널 인증 취소 (보안 사고 시)."""
        if channel in self._data.get("owner_channels", {}):
            del self._data["owner_channels"][channel]
            self._save()
            print(f"[Auth] 🚫 '{channel}' 페어링 취소됨")

    # ── Trust Query ──────────────────────────────────────

    def get_trust(self, channel: str) -> ChannelTrust:
        if channel in self._data.get("owner_channels", {}):
            return ChannelTrust.OWNER
        if channel in self.KNOWN_CHANNELS:
            return ChannelTrust.TRUSTED
        return ChannelTrust.EXTERNAL

    def is_owner_channel(self, channel: str) -> bool:
        return self.get_trust(channel) == ChannelTrust.OWNER

    def list_owner_channels(self) -> List[str]:
        return list(self._data.get("owner_channels", {}).keys())

    # ── Internal ─────────────────────────────────────────

    def _load(self) -> Dict:
        try:
            if self._file.exists():
                return json.loads(self._file.read_text(encoding="utf-8"))
        except Exception as e:
            print(f"[Auth] ⚠️ Load failed: {e}")
        return {"owner_channels": {}, "pending_tokens": {}}

    def _save(self):
        try:
            self._file.write_text(
                json.dumps(self._data, ensure_ascii=False, indent=2),
                encoding="utf-8"
            )
        except Exception as e:
            print(f"[Auth] ⚠️ Save failed: {e}")
