"""
KIVOSY v5.0 - Command Audit Log Module
Responsibility: Persistent logging of all command executions and blocks.
"""

import json
from datetime import datetime
from pathlib import Path
from typing import Dict, List


class CommandAuditLog:
    """모든 명령어 실행/차단 이력을 파일에 영속 저장합니다."""

    STATUS_EMOJI = {
        "executed":         "✅",
        "blocked":          "🚫",
        "pending_approval": "⏳",
    }

    def __init__(self, audit_file: Path):
        self._file = audit_file
        self._ensure_file()

    def log_command(
        self,
        command_type: str,
        command_data: str,
        status: str,
        reason: str = "",
    ):
        data = self._load()
        data["entries"].append({
            "timestamp":    datetime.now().isoformat(),
            "command_type": command_type,
            "command_data": command_data,
            "status":       status,
            "reason":       reason,
        })
        data["entries"] = data["entries"][-1000:]   # keep last 1000
        self._save(data)

        emoji = self.STATUS_EMOJI.get(status, "❓")
        print(f"{emoji} [AUDIT] {command_type}: {status} | {command_data[:40]}")

    def get_recent_entries(self, limit: int = 10) -> List[Dict]:
        return self._load().get("entries", [])[-limit:]

    # ── Internal ─────────────────────────────────────────

    def _ensure_file(self):
        if not self._file.exists():
            self._save({
                "version":    "5.0.0",
                "created_at": datetime.now().isoformat(),
                "entries":    [],
            })

    def _load(self) -> Dict:
        try:
            if self._file.exists():
                return json.loads(self._file.read_text(encoding="utf-8"))
        except Exception:
            pass
        return {"entries": []}

    def _save(self, data: Dict):
        self._file.write_text(
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
