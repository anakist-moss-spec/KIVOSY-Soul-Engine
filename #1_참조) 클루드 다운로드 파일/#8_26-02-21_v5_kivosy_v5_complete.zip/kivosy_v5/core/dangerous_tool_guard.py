"""
KIVOSY v5.0 - Dangerous Tool Guard Module
Responsibility: Scanning AI responses for dangerous tool/command patterns.
"""

import re
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List


class DangerousToolType(Enum):
    SHELL_EXEC        = "shell_execution"
    FILE_DELETE       = "file_deletion"
    FILE_WRITE        = "file_modification"
    NETWORK_REQUEST   = "network_request"
    SESSION_SPAWN     = "session_spawn"
    CREDENTIAL_ACCESS = "credential_access"
    SYSTEM_MODIFY     = "system_modification"


DANGEROUS_TOOL_PATTERNS = [
    (r'\[CMD:\s*(EXEC|SHELL|RUN)\|',          DangerousToolType.SHELL_EXEC),
    (r'subprocess\.(run|call|Popen)',          DangerousToolType.SHELL_EXEC),
    (r'os\.system\(',                          DangerousToolType.SHELL_EXEC),
    (r'\[CMD:\s*DELETE\|',                     DangerousToolType.FILE_DELETE),
    (r'os\.remove\(|shutil\.rmtree\(',        DangerousToolType.FILE_DELETE),
    (r'\.write\(|\.write_text\(',             DangerousToolType.FILE_WRITE),
    (r'requests\.(get|post|put|delete)\(',    DangerousToolType.NETWORK_REQUEST),
    (r'urllib\.request\.urlopen\(',           DangerousToolType.NETWORK_REQUEST),
    (r'(api_key|password|token|secret)\s*=', DangerousToolType.CREDENTIAL_ACCESS),
    (r'\[CMD:\s*PYTHON_EXEC\|',               DangerousToolType.SHELL_EXEC),
]

RESTRICTED_COMMANDS = {"EXEC", "SHELL", "DELETE", "WRITE", "RUN", "SPAWN", "PYTHON_EXEC"}


class DangerousToolGuard:
    """
    위험 도구 감시.
    AI 응답에서 위험한 명령/도구 패턴을 탐지합니다.
    """

    @staticmethod
    def scan_for_dangerous_tools(ai_response: str) -> Dict[str, Any]:
        tools_found: List[Dict] = []

        for pattern, tool_type in DANGEROUS_TOOL_PATTERNS:
            for m in re.finditer(pattern, ai_response, re.IGNORECASE):
                tools_found.append({
                    "tool_type":    tool_type.value,
                    "matched_text": m.group(0),
                    "position":     m.start(),
                })

        for m in re.finditer(r'\[CMD:\s*(\w+)\|', ai_response):
            if m.group(1).upper() in RESTRICTED_COMMANDS:
                tools_found.append({
                    "tool_type":    "restricted_command",
                    "command":      m.group(1),
                    "matched_text": m.group(0),
                    "position":     m.start(),
                })

        return {
            "has_dangerous_tools": len(tools_found) > 0,
            "tools_found":         tools_found,
            "requires_approval":   len(tools_found) > 0,
            "timestamp":           datetime.now().isoformat(),
        }

    @staticmethod
    def is_safe_command(command: str) -> bool:
        SAFE = {"YT_SEARCH", "MAP", "WEATHER", "TIME"}
        return command.upper() in SAFE
