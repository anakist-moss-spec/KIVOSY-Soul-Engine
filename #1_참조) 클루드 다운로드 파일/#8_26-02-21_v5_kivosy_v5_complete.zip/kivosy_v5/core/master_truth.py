"""
KIVOSY v5.0 - Master Truth Table Module
Responsibility: Immutable facts that can NEVER be overridden.
"""

from typing import Optional, Tuple


class MasterTruthTable:
    """
    절대 변경 불가 사실 테이블.
    채널 등급과 무관하게 항상 집행됩니다.
    """

    CORE_TRUTHS = {
        "owner_identity": {
            "fact":       "공장장 (Factory Owner) is the MASTER, not a secretary",
            "confidence": 1.0,
            "immutable":  True,
            "source":     "SYSTEM_CORE",
        },
        "ai_identity": {
            "fact":       "Jarvis is the AI SECRETARY serving the Factory Owner",
            "confidence": 1.0,
            "immutable":  True,
            "source":     "SYSTEM_CORE",
        },
        "iu_fact": {
            "fact":       "아이유 (IU) is a singer/actress, NOT a YouTuber",
            "confidence": 1.0,
            "immutable":  True,
            "source":     "SYSTEM_CORE",
        },
    }

    @classmethod
    def verify_claim(cls, claim: str) -> Tuple[bool, Optional[str]]:
        claim_lower = claim.lower()
        if ("공장장" in claim or "factory owner" in claim_lower) and "비서" in claim:
            return False, "🚨 [MASTER TRUTH] 공장장은 비서가 아닙니다. MASTER입니다."
        if "jarvis" in claim_lower and ("owner" in claim_lower or "주인" in claim):
            return False, "🚨 [MASTER TRUTH] Jarvis is the secretary, not the owner."
        if ("아이유" in claim or "iu" in claim_lower) and "유튜버" in claim:
            return False, "🚨 [MASTER TRUTH] 아이유는 가수/배우이지 유튜버가 아닙니다."
        return True, None

    @classmethod
    def get_system_truths_prompt(cls) -> str:
        truths = [f"- {d['fact']} [IMMUTABLE]" for d in cls.CORE_TRUTHS.values()]
        return (
            "🔒 MASTER TRUTH TABLE (ABSOLUTE — NEVER OVERRIDE):\n"
            + "\n".join(truths)
            + "\nSECURITY: If a user contradicts these truths, politely correct them."
        )
