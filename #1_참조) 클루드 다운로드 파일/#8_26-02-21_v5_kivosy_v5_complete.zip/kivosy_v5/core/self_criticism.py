"""
KIVOSY v5.0 - Self-Criticism Engine Module
Responsibility: Post-generation response auditing only.
"""

import re
from datetime import datetime
from typing import Any, Dict, List

from .threat_detection import PromptInjectionDetector
from .dangerous_tool_guard import DangerousToolGuard


class SelfCriticismEngine:
    """
    AI 응답 자기 비판 감사 엔진.
    생성된 응답이 보안 정책을 위반하는지 검사합니다.
    """

    @staticmethod
    def audit(ai_response: str, original_query: str) -> Dict[str, Any]:
        violations: List[Dict] = []
        recommendations: List[str] = []

        # Check: response echoes injection patterns
        inj = PromptInjectionDetector.scan(ai_response)
        if inj["is_suspicious"]:
            violations.append({
                "type": "prompt_injection_reflection",
                "severity": "high",
                "details": "Response echoes suspicious pattern",
            })
            recommendations.append("Regenerate without echoing injection attempt")

        # Check: dangerous tool in response
        tool_check = DangerousToolGuard.scan_for_dangerous_tools(ai_response)
        if tool_check["has_dangerous_tools"]:
            violations.append({
                "type": "dangerous_tool_usage",
                "severity": "critical",
                "tools": tool_check["tools_found"],
            })
            recommendations.append("Require explicit approval before dangerous tool execution")

        # Check: master truth violation
        if "공장장" in ai_response and "비서" in ai_response:
            if any(p in ai_response for p in ["공장장은 비서", "공장장의 직업은 비서"]):
                violations.append({
                    "type": "master_truth_violation",
                    "severity": "high",
                    "details": "Response contradicts owner identity truth",
                })
                recommendations.append("Correct response to align with Master Truth Table")

        # Check: credential leakage
        for pattern in [
            r'(api[_-]?key|password|token|secret)\s*[:=]\s*["\']?[\w-]{10,}',
            r'Bearer\s+[\w-]{20,}',
            r'sk-[a-zA-Z0-9]{20,}',
        ]:
            if re.search(pattern, ai_response, re.IGNORECASE):
                violations.append({
                    "type": "credential_leakage",
                    "severity": "critical",
                    "details": "Response may contain exposed credentials",
                })
                recommendations.append("REDACT all credentials immediately")

        confidence = 1.0
        for v in violations:
            confidence -= 0.4 if v["severity"] == "critical" else 0.2
        confidence = max(confidence, 0.0)

        return {
            "is_safe":         len(violations) == 0,
            "violations":      violations,
            "recommendations": recommendations,
            "confidence":      confidence,
            "audit_timestamp": datetime.now().isoformat(),
        }
