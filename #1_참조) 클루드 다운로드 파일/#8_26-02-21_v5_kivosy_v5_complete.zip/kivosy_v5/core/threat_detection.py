"""
KIVOSY v5.0 - Threat Detection Module
Responsibility: Prompt injection scanning only.
"""

import re
from datetime import datetime
from enum import Enum
from typing import Any, Dict

from .channel_auth import ChannelTrust


class ThreatLevel(Enum):
    SAFE     = "safe"
    LOW      = "low"
    MEDIUM   = "medium"
    HIGH     = "high"
    CRITICAL = "critical"


SUSPICIOUS_PATTERNS = [
    (r'ignore\s+(all\s+)?(previous|prior|above)\s+(instructions?|prompts?)', ThreatLevel.HIGH),
    (r'disregard\s+(all\s+)?(previous|prior|above)',                          ThreatLevel.HIGH),
    (r'forget\s+(everything|all|your)\s+(instructions?|rules?|guidelines?)',  ThreatLevel.HIGH),
    (r'you\s+are\s+now\s+(a|an)\s+',                                          ThreatLevel.CRITICAL),
    (r'new\s+instructions?:',                                                  ThreatLevel.HIGH),
    (r'system\s*:?\s*(prompt|override|command)',                               ThreatLevel.CRITICAL),
    (r'act\s+as\s+(if\s+)?you\s+(are|were)',                                  ThreatLevel.MEDIUM),
    (r'(you|your)\s+(real|actual|true)\s+(name|identity|role)\s+is',         ThreatLevel.HIGH),
    (r'(IU|아이유).*(유튜버|youtuber)',                                         ThreatLevel.MEDIUM),
    (r'공장장.*(비서|secretary)',                                               ThreatLevel.MEDIUM),
    (r'\bexec\b.*command\s*=',                                                 ThreatLevel.CRITICAL),
    (r'rm\s+-rf',                                                              ThreatLevel.CRITICAL),
    (r'delete\s+all\s+(emails?|files?|data)',                                  ThreatLevel.CRITICAL),
    (r'elevated\s*=\s*true',                                                   ThreatLevel.HIGH),
    (r'<\/?system>',                                                           ThreatLevel.HIGH),
    (r'\]\s*\n\s*\[?(system|assistant|user)\]?:',                             ThreatLevel.HIGH),
    (r'<<<EXTERNAL_UNTRUSTED_CONTENT>>>',                                      ThreatLevel.LOW),
    (r'(show|reveal|tell)\s+(me\s+)?(your\s+)?(api[\s_-]?key|password|token|secret)', ThreatLevel.CRITICAL),
    (r'what\s+is\s+your\s+(system|internal)\s+prompt',                        ThreatLevel.HIGH),
]


class PromptInjectionDetector:
    """
    프롬프트 인젝션 탐지기.

    OWNER 채널은 MEDIUM 이하 위협을 경고만 하고 차단하지 않습니다.
    CRITICAL 위협은 채널 등급과 무관하게 항상 플래깅됩니다.
    """

    @staticmethod
    def scan(text: str, channel_trust: ChannelTrust = ChannelTrust.EXTERNAL) -> Dict[str, Any]:
        matches = []
        max_threat = ThreatLevel.SAFE

        for pattern, threat_level in SUSPICIOUS_PATTERNS:
            for m in re.finditer(pattern, text, re.IGNORECASE):
                matches.append({
                    "pattern":      pattern,
                    "matched_text": m.group(0),
                    "position":     m.start(),
                    "threat_level": threat_level.value,
                })
                if list(ThreatLevel).index(threat_level) > list(ThreatLevel).index(max_threat):
                    max_threat = threat_level

        confidence = 0.0
        if matches:
            confidence = min(len(matches) * 0.3, 1.0)
            if max_threat == ThreatLevel.CRITICAL:
                confidence = max(confidence, 0.9)
            elif max_threat == ThreatLevel.HIGH:
                confidence = max(confidence, 0.7)

        effective_suspicious = len(matches) > 0
        if channel_trust == ChannelTrust.OWNER:
            if max_threat not in (ThreatLevel.CRITICAL, ThreatLevel.HIGH):
                effective_suspicious = False
                print(f"[Security] ℹ️ OWNER 채널 — {max_threat.value} 위협 패스 (로그 기록됨)")

        return {
            "is_suspicious":  effective_suspicious,
            "raw_suspicious": len(matches) > 0,
            "threat_level":   max_threat.value,
            "matches":        matches,
            "confidence":     confidence,
            "channel_trust":  channel_trust.value,
            "timestamp":      datetime.now().isoformat(),
        }
