"""
KIVOSY v5.0 - Physical Action Package
⚠️  ALL physical actions require human-in-the-loop approval by default.
"""

from .executor import PhysicalExecutor
from .failsafe import FailsafeMonitor
from .two_factor import TwoFactorApproval
from .sandbox import SandboxEnvironment
from .vision import ComputerVision
from .window_manager import WindowManager

__all__ = [
    "PhysicalExecutor",
    "FailsafeMonitor",
    "TwoFactorApproval",
    "SandboxEnvironment",
    "ComputerVision",
    "WindowManager",
]
