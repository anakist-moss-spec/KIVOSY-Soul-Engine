"""
KIVOSY v5.0 - Physical Executor
Responsibility: Orchestrating safe physical actions (mouse, keyboard, screen).

Safety pipeline for every action:
    1. Failsafe check  (abort if emergency stop is active)
    2. Vision verify   (confirm target exists on screen)
    3. 2FA approval    (human must approve)
    4. Sandbox isolate (run in isolated context with timeout)
    5. Execute         (pyautogui action)
    6. Audit log       (record result)
"""

import time
from datetime import datetime
from typing import Optional

from .failsafe import FailsafeMonitor
from .two_factor import TwoFactorApproval, ApprovalStatus
from .vision import ComputerVision, VisualTarget
from .sandbox import SandboxEnvironment
from .window_manager import WindowManager


class PhysicalExecutor:
    """
    물리적 액션 오케스트레이터.

    모든 메서드는 기본적으로 사람 승인을 요구합니다.
    auto_approve=True는 테스트 환경 전용입니다.
    """

    def __init__(self, auto_approve: bool = False):
        """
        Args:
            auto_approve: True면 사람 승인 스킵 (⚠️ 테스트 전용!)
        """
        self.failsafe      = FailsafeMonitor()
        self.two_factor    = TwoFactorApproval(timeout=30)
        self.vision        = ComputerVision()
        self.sandbox       = SandboxEnvironment(timeout=10)
        self.window_manager = WindowManager()
        self._auto_approve = auto_approve
        self._pyautogui    = None
        self._init_pyautogui()

        if auto_approve:
            print("[PhysicalExecutor] ⚠️  AUTO-APPROVE 모드 — 운영 환경에서 절대 사용 금지!")

    def _init_pyautogui(self):
        try:
            import pyautogui
            self._pyautogui = pyautogui
            print("[PhysicalExecutor] ✅ pyautogui 로드됨")
        except ImportError:
            print("[PhysicalExecutor] ⚠️ pyautogui 미설치 — 물리적 액션 비활성화")

    # ── Public Actions ───────────────────────────────────

    def click(
        self,
        x: int,
        y: int,
        description: str = "",
        template_path: Optional[str] = None,
    ) -> bool:
        """
        화면 좌표 클릭.

        Args:
            x, y:          클릭 좌표
            description:   승인 화면에 표시될 설명
            template_path: 비전 검증용 템플릿 이미지 경로 (선택)

        Returns:
            True if clicked successfully
        """
        if not self._check_pyautogui():
            return False

        if self.failsafe.is_aborted():
            print("[PhysicalExecutor] 🚫 비상 정지 중 — 클릭 불가")
            return False

        # Vision verify (선택적)
        if template_path:
            target = self.vision.verify_target(template_path)
            if not target:
                print(f"[PhysicalExecutor] ❌ 비전 검증 실패 — 클릭 취소: {template_path}")
                return False
            x, y = target.x, target.y
            print(f"[PhysicalExecutor] 🎯 비전 검증 성공: ({x}, {y}), 신뢰도={target.confidence:.2f}")

        # 2FA approval
        if not self._approve("CLICK", f"({x}, {y})", description):
            return False

        # Sandbox + Execute
        def _do_click():
            self._pyautogui.moveTo(x, y, duration=0.3)
            self._pyautogui.click(x, y)

        with self.failsafe.monitor():
            with self.sandbox.isolated(f"click({x},{y})"):
                self.sandbox.run_with_timeout(_do_click)

        print(f"[PhysicalExecutor] ✅ 클릭 완료: ({x}, {y})")
        return True

    def type_text(self, text: str, description: str = "") -> bool:
        """
        키보드 텍스트 입력.

        ⚠️ 입력 내용이 승인 화면에 미리보기로 표시됩니다.
        """
        if not self._check_pyautogui():
            return False

        preview = text[:30] + ("..." if len(text) > 30 else "")
        if not self._approve("TYPE", f"텍스트: '{preview}'", description):
            return False

        def _do_type():
            self._pyautogui.typewrite(text, interval=0.05)

        with self.failsafe.monitor():
            with self.sandbox.isolated("type_text"):
                self.sandbox.run_with_timeout(_do_type)

        print(f"[PhysicalExecutor] ✅ 텍스트 입력 완료: {preview}")
        return True

    def screenshot(self, save_path: Optional[str] = None):
        """
        화면 캡처 (승인 불필요 — 읽기 전용 작업).

        Returns:
            PIL Image or None
        """
        if not self._check_pyautogui():
            return None

        try:
            img = self._pyautogui.screenshot()
            if save_path:
                img.save(save_path)
                print(f"[PhysicalExecutor] 📸 스크린샷 저장: {save_path}")
            return img
        except Exception as e:
            print(f"[PhysicalExecutor] ❌ 스크린샷 실패: {e}")
            return None

    def move_mouse(self, x: int, y: int, duration: float = 0.5) -> bool:
        """마우스 이동 (클릭 없음)."""
        if not self._check_pyautogui():
            return False

        if not self._approve("MOVE_MOUSE", f"({x}, {y})", ""):
            return False

        with self.failsafe.monitor():
            with self.sandbox.isolated(f"move({x},{y})"):
                self.sandbox.run_with_timeout(
                    self._pyautogui.moveTo, None, x, y, duration=duration
                )

        return True

    def press_key(self, key: str, description: str = "") -> bool:
        """단일 키 입력."""
        if not self._check_pyautogui():
            return False

        if not self._approve("KEY_PRESS", key, description):
            return False

        with self.failsafe.monitor():
            with self.sandbox.isolated(f"key({key})"):
                self.sandbox.run_with_timeout(self._pyautogui.press, None, key)

        print(f"[PhysicalExecutor] ✅ 키 입력: {key}")
        return True

    def emergency_stop(self):
        """즉시 모든 물리적 액션 중단."""
        self.failsafe.emergency_stop("사용자 요청")

    # ── Internal ─────────────────────────────────────────

    def _approve(self, action_type: str, target: str, description: str) -> bool:
        """승인 게이트. auto_approve 모드면 스킵."""
        if self._auto_approve:
            print(f"[PhysicalExecutor] ⚡ AUTO-APPROVE: {action_type} → {target}")
            return True

        status = self.two_factor.request_approval(
            action_type=action_type,
            target=target,
            description=description,
            via_console=True,
        )
        return status == ApprovalStatus.APPROVED

    def _check_pyautogui(self) -> bool:
        if self._pyautogui is None:
            print("[PhysicalExecutor] ❌ pyautogui 미설치 — pip install pyautogui")
            return False
        return True

    # ── Status ───────────────────────────────────────────

    def status(self) -> dict:
        return {
            "pyautogui_available": self._pyautogui is not None,
            "vision_available":    self.vision.is_available(),
            "window_mgr_available": self.window_manager.is_available(),
            "failsafe_active":     not self.failsafe.is_aborted(),
            "auto_approve":        self._auto_approve,
            "sandbox_active_count": self.sandbox.active_count,
        }
