"""
KIVOSY v5.0 - Computer Vision Module
Responsibility: Screen analysis and target verification before any click.
"""

from dataclasses import dataclass
from typing import Optional, Tuple


@dataclass
class VisualTarget:
    label: str
    x: int
    y: int
    confidence: float
    bounding_box: Optional[Tuple[int, int, int, int]] = None   # (x1, y1, x2, y2)


class ComputerVision:
    """
    클릭 전 화면 분석 및 대상 검증.

    설치 필요: pip install opencv-python pyautogui Pillow
    """

    MIN_CONFIDENCE = 0.80   # 80% 미만이면 클릭 차단

    def __init__(self):
        self._cv2 = None
        self._pyscreenshot = None
        self._available = False
        self._init_libs()

    def _init_libs(self):
        try:
            import cv2
            import numpy as np
            self._cv2 = cv2
            self._np  = np
            self._available = True
            print("[Vision] ✅ OpenCV 로드됨")
        except ImportError:
            print("[Vision] ⚠️ opencv-python 미설치 — 비전 검증 비활성화")

    # ── Main API ────────────────────────────────────────

    def verify_target(self, template_path: str, screenshot=None) -> Optional[VisualTarget]:
        """
        화면에서 템플릿 이미지와 일치하는 대상을 찾습니다.

        Args:
            template_path: 클릭할 버튼/UI 요소의 템플릿 이미지 경로
            screenshot:    기존 스크린샷 (None이면 새로 캡처)

        Returns:
            VisualTarget if found with confidence >= MIN_CONFIDENCE, else None
        """
        if not self._available:
            print("[Vision] ⚠️ 비전 불가 — 승인 없이 클릭 금지")
            return None

        try:
            import pyautogui
            import numpy as np

            if screenshot is None:
                screenshot = pyautogui.screenshot()

            screen_np   = np.array(screenshot)
            screen_gray = self._cv2.cvtColor(screen_np, self._cv2.COLOR_RGB2GRAY)

            template     = self._cv2.imread(template_path, self._cv2.IMREAD_GRAYSCALE)
            if template is None:
                print(f"[Vision] ❌ 템플릿 로드 실패: {template_path}")
                return None

            result = self._cv2.matchTemplate(screen_gray, template, self._cv2.TM_CCOEFF_NORMED)
            _, max_val, _, max_loc = self._cv2.minMaxLoc(result)

            if max_val < self.MIN_CONFIDENCE:
                print(f"[Vision] ⚠️ 대상 신뢰도 부족: {max_val:.2f} < {self.MIN_CONFIDENCE}")
                return None

            h, w = template.shape
            cx = max_loc[0] + w // 2
            cy = max_loc[1] + h // 2

            target = VisualTarget(
                label       = template_path,
                x           = cx,
                y           = cy,
                confidence  = float(max_val),
                bounding_box= (max_loc[0], max_loc[1], max_loc[0] + w, max_loc[1] + h),
            )
            print(f"[Vision] ✅ 대상 발견: ({cx}, {cy}), 신뢰도: {max_val:.2f}")
            return target

        except Exception as e:
            print(f"[Vision] ❌ 비전 검증 실패: {e}")
            return None

    def take_screenshot(self):
        """현재 화면 캡처."""
        try:
            import pyautogui
            return pyautogui.screenshot()
        except ImportError:
            print("[Vision] ⚠️ pyautogui 미설치")
            return None

    def is_available(self) -> bool:
        return self._available
