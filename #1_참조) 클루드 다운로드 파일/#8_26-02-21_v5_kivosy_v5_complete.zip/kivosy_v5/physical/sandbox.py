"""
KIVOSY v5.0 - Sandbox Environment Module
Responsibility: Isolated execution environment for physical actions.
Physical actions run in a sandboxed context with resource limits.
"""

import os
import threading
import time
from contextlib import contextmanager
from typing import Any, Callable, Optional


class SandboxEnvironment:
    """
    물리적 액션 격리 실행 환경.

    - 타임아웃 강제
    - 스레드 격리
    - 리소스 제한 (향후 확장: cgroups/seccomp)
    """

    DEFAULT_TIMEOUT = 10   # 초
    MAX_CONCURRENT  = 1    # 동시 실행 허용 물리적 액션 수

    def __init__(self, timeout: int = DEFAULT_TIMEOUT):
        self._timeout  = timeout
        self._semaphore = threading.Semaphore(self.MAX_CONCURRENT)
        self._active_actions = 0
        self._lock = threading.Lock()

    @contextmanager
    def isolated(self, action_label: str = "physical_action"):
        """
        격리된 실행 컨텍스트.

        사용법:
            with sandbox.isolated("click_confirm"):
                pyautogui.click(x, y)
        """
        acquired = self._semaphore.acquire(timeout=5)
        if not acquired:
            raise RuntimeError(
                f"[Sandbox] ❌ 동시 실행 한도 초과 ({self.MAX_CONCURRENT}) — "
                f"'{action_label}' 실행 불가"
            )

        with self._lock:
            self._active_actions += 1

        print(f"[Sandbox] 🔒 격리 시작: {action_label} (timeout={self._timeout}s)")
        result_container = [None]
        exception_container = [None]

        def _run():
            try:
                result_container[0] = "ready"
            except Exception as e:
                exception_container[0] = e

        try:
            yield result_container
        except Exception as e:
            print(f"[Sandbox] ⚠️ 액션 오류: {action_label} — {e}")
            raise
        finally:
            with self._lock:
                self._active_actions -= 1
            self._semaphore.release()
            print(f"[Sandbox] 🔓 격리 종료: {action_label}")

    def run_with_timeout(
        self,
        func: Callable,
        timeout: Optional[int] = None,
        *args,
        **kwargs,
    ) -> Any:
        """
        타임아웃이 있는 함수 실행.

        Returns:
            함수 결과값 또는 None (타임아웃/오류 시)
        """
        t = timeout or self._timeout
        result_container: list = [None]
        error_container: list  = [None]

        def _worker():
            try:
                result_container[0] = func(*args, **kwargs)
            except Exception as e:
                error_container[0] = e

        thread = threading.Thread(target=_worker, daemon=True)
        thread.start()
        thread.join(timeout=t)

        if thread.is_alive():
            print(f"[Sandbox] ⏰ 타임아웃 ({t}초) — {func.__name__}")
            return None

        if error_container[0]:
            print(f"[Sandbox] ❌ 실행 오류: {error_container[0]}")
            return None

        return result_container[0]

    @property
    def active_count(self) -> int:
        return self._active_actions
