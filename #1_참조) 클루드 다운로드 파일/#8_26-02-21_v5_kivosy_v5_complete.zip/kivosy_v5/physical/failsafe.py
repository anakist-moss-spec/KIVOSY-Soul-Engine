"""
KIVOSY v5.0 - Failsafe Monitor
Responsibility: Emergency stop for all physical actions.
This module is INDEPENDENT — it never blocks on main thread failures.
"""

import threading
import time
from contextlib import contextmanager
from datetime import datetime
from typing import Callable, Optional


class FailsafeMonitor:
    """
    모든 물리적 액션에 대한 비상 정지 시스템.

    pyautogui의 기본 failsafe(마우스를 화면 모서리로 이동)를
    보강하는 독립 모니터입니다.
    """

    def __init__(self):
        self._active = False
        self._abort_event = threading.Event()
        self._on_emergency: Optional[Callable] = None
        self._action_count = 0
        self._max_actions_per_session = 50   # 세션당 최대 액션 수

        # pyautogui failsafe 활성화
        try:
            import pyautogui
            pyautogui.FAILSAFE = True
            pyautogui.PAUSE = 0.5           # 모든 액션 사이 0.5초 강제 대기
            print("[Failsafe] ✅ pyautogui failsafe 활성화 (마우스 좌상단 → 즉시 중단)")
        except ImportError:
            print("[Failsafe] ⚠️ pyautogui 미설치 — 물리적 액션 비활성화")

    def register_emergency_callback(self, callback: Callable):
        """비상 정지 시 호출될 콜백 등록."""
        self._on_emergency = callback

    def emergency_stop(self, reason: str = "Manual abort"):
        """즉시 모든 물리적 액션 중단."""
        self._abort_event.set()
        self._active = False
        timestamp = datetime.now().isoformat()
        print(f"[Failsafe] 🚨 EMERGENCY STOP at {timestamp}: {reason}")
        if self._on_emergency:
            self._on_emergency(reason)

    def reset(self):
        """비상 정지 해제 (신중하게 사용)."""
        self._abort_event.clear()

    def is_aborted(self) -> bool:
        return self._abort_event.is_set()

    def increment_action(self) -> bool:
        """
        액션 카운터 증가. 세션 한도 초과 시 False 반환.
        """
        self._action_count += 1
        if self._action_count > self._max_actions_per_session:
            self.emergency_stop(f"세션 최대 액션 수 초과 ({self._max_actions_per_session})")
            return False
        return True

    @contextmanager
    def monitor(self):
        """
        물리적 액션 실행을 감시하는 컨텍스트 매니저.

        사용법:
            with failsafe.monitor():
                pyautogui.click(x, y)
        """
        if self.is_aborted():
            raise RuntimeError("[Failsafe] 비상 정지 상태 — 액션 불가")

        if not self.increment_action():
            raise RuntimeError("[Failsafe] 세션 액션 한도 초과")

        self._active = True
        try:
            yield self
        except Exception as e:
            self.emergency_stop(f"액션 실행 오류: {e}")
            raise
        finally:
            self._active = False
