"""
KIVOSY v5.0 - Two-Factor Human Approval
Responsibility: Human-in-the-loop confirmation for all physical actions.
No physical action executes without explicit approval.
"""

import threading
import time
from datetime import datetime
from enum import Enum
from typing import Any, Dict, Optional


class ApprovalStatus(Enum):
    PENDING  = "pending"
    APPROVED = "approved"
    DENIED   = "denied"
    TIMEOUT  = "timeout"


class TwoFactorApproval:
    """
    모든 물리적 액션에 대한 사람 승인 게이트.

    ※ 승인 없이는 어떤 물리적 액션도 실행되지 않습니다.

    두 가지 승인 방식:
    1. Console 입력 (로컬 테스트용)
    2. HTTP 콜백 (웹 대시보드 연동용)
    """

    DEFAULT_TIMEOUT_SECONDS = 30

    def __init__(self, timeout: int = DEFAULT_TIMEOUT_SECONDS):
        self._timeout = timeout
        self._pending: Dict[str, Dict[str, Any]] = {}
        self._lock = threading.Lock()

    def request_approval(
        self,
        action_type: str,
        target: str,
        description: str = "",
        via_console: bool = True,
    ) -> ApprovalStatus:
        """
        물리적 액션 승인 요청.

        Args:
            action_type: 액션 종류 (e.g., "CLICK", "TYPE", "SCREENSHOT")
            target:      대상 설명 (e.g., "확인 버튼 (x=500, y=300)")
            description: 추가 컨텍스트
            via_console: True면 콘솔에서 즉시 입력 대기

        Returns:
            ApprovalStatus
        """
        request_id = f"{action_type}_{int(time.time())}"

        with self._lock:
            self._pending[request_id] = {
                "action_type": action_type,
                "target":      target,
                "description": description,
                "requested_at": datetime.now().isoformat(),
                "status":      ApprovalStatus.PENDING,
            }

        print(f"\n[2FA] ⚠️  물리적 액션 승인 요청")
        print(f"      액션: {action_type}")
        print(f"      대상: {target}")
        if description:
            print(f"      설명: {description}")
        print(f"      제한시간: {self._timeout}초\n")

        if via_console:
            return self._console_approval(request_id)

        # HTTP 승인 대기 (대시보드 연동 시)
        return self._wait_for_approval(request_id)

    def approve(self, request_id: str):
        """외부에서 승인 처리 (HTTP 엔드포인트 연동용)."""
        with self._lock:
            if request_id in self._pending:
                self._pending[request_id]["status"] = ApprovalStatus.APPROVED

    def deny(self, request_id: str):
        """외부에서 거부 처리."""
        with self._lock:
            if request_id in self._pending:
                self._pending[request_id]["status"] = ApprovalStatus.DENIED

    # ── Internal ─────────────────────────────────────────

    def _console_approval(self, request_id: str) -> ApprovalStatus:
        """콘솔 입력으로 승인/거부."""
        try:
            import signal

            def _timeout_handler(signum, frame):
                raise TimeoutError

            # POSIX only — Windows에서는 fallback
            try:
                signal.signal(signal.SIGALRM, _timeout_handler)
                signal.alarm(self._timeout)
            except AttributeError:
                pass   # Windows: no SIGALRM

            answer = input("[2FA] 승인? (y/N): ").strip().lower()

            try:
                signal.alarm(0)
            except AttributeError:
                pass

            if answer == "y":
                with self._lock:
                    self._pending[request_id]["status"] = ApprovalStatus.APPROVED
                print("[2FA] ✅ 승인됨")
                return ApprovalStatus.APPROVED
            else:
                with self._lock:
                    self._pending[request_id]["status"] = ApprovalStatus.DENIED
                print("[2FA] 🚫 거부됨")
                return ApprovalStatus.DENIED

        except (TimeoutError, EOFError):
            with self._lock:
                self._pending[request_id]["status"] = ApprovalStatus.TIMEOUT
            print(f"[2FA] ⏰ {self._timeout}초 초과 — 자동 거부")
            return ApprovalStatus.TIMEOUT

    def _wait_for_approval(self, request_id: str) -> ApprovalStatus:
        """HTTP 엔드포인트 승인 대기 (폴링)."""
        deadline = time.time() + self._timeout
        while time.time() < deadline:
            with self._lock:
                status = self._pending.get(request_id, {}).get("status")
            if status in (ApprovalStatus.APPROVED, ApprovalStatus.DENIED):
                return status
            time.sleep(0.5)
        return ApprovalStatus.TIMEOUT
