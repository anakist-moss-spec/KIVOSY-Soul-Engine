"""
KIVOSY v5.0 - Window Manager Module
Responsibility: Window listing, focusing, and management.
"""

from typing import Any, List, Optional


class WindowInfo:
    def __init__(self, title: str, handle: Any = None, is_active: bool = False):
        self.title     = title
        self.handle    = handle
        self.is_active = is_active

    def __repr__(self):
        active = " [ACTIVE]" if self.is_active else ""
        return f"WindowInfo('{self.title}'{active})"


class WindowManager:
    """
    창 관리 모듈. pygetwindow 래퍼.

    설치 필요: pip install pygetwindow
    """

    def __init__(self):
        self._gw = None
        self._available = False
        self._init()

    def _init(self):
        try:
            import pygetwindow as gw
            self._gw = gw
            self._available = True
            print("[WindowMgr] ✅ pygetwindow 로드됨")
        except ImportError:
            print("[WindowMgr] ⚠️ pygetwindow 미설치 — 창 관리 비활성화")

    # ── Public API ───────────────────────────────────────

    def list_windows(self) -> List[WindowInfo]:
        """현재 열린 모든 창 목록 반환."""
        if not self._available:
            return []
        try:
            return [
                WindowInfo(title=w.title, handle=w)
                for w in self._gw.getAllWindows()
                if w.title.strip()
            ]
        except Exception as e:
            print(f"[WindowMgr] ⚠️ 창 목록 조회 실패: {e}")
            return []

    def get_active_window(self) -> Optional[WindowInfo]:
        """현재 활성 창 반환."""
        if not self._available:
            return None
        try:
            w = self._gw.getActiveWindow()
            if w:
                return WindowInfo(title=w.title, handle=w, is_active=True)
        except Exception as e:
            print(f"[WindowMgr] ⚠️ 활성 창 조회 실패: {e}")
        return None

    def focus_window(self, title_fragment: str) -> bool:
        """
        제목에 키워드가 포함된 창을 포커스.

        Returns:
            True if successfully focused
        """
        if not self._available:
            return False
        try:
            windows = self._gw.getWindowsWithTitle(title_fragment)
            if not windows:
                print(f"[WindowMgr] ❌ 창 없음: '{title_fragment}'")
                return False
            windows[0].activate()
            print(f"[WindowMgr] ✅ 창 포커스: '{windows[0].title}'")
            return True
        except Exception as e:
            print(f"[WindowMgr] ⚠️ 창 포커스 실패: {e}")
            return False

    def is_available(self) -> bool:
        return self._available
