"""
KIVOSY v5.0 - Channel Gateway (Clean Version)
Responsibility: Message routing, AI call orchestration, command dispatch.
All security concerns are delegated to core/ modules.
"""

import re
import webbrowser
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from core import (
    ChannelAuthenticator,
    ChannelTrust,
    PromptInjectionDetector,
    DangerousToolGuard,
)
from core.audit_log import CommandAuditLog
from .skill_library import SkillLibrary


# ── Channel configs ──────────────────────────────────────

CHANNELS = {
    "kakao":    {"name": "KakaoTalk", "icon": "💬", "color": "#FAE100"},
    "whatsapp": {"name": "WhatsApp",  "icon": "🟢", "color": "#25D366"},
    "line":     {"name": "LINE",      "icon": "💚", "color": "#00B900"},
}


class ChannelGateway:
    """
    v5.0: 책임이 명확히 분리된 채널 게이트웨이.

    명령어 처리 우선순위:
    1. [SKILL:...] → SkillLibrary (최우선, 가장 안전)
    2. [CMD:YT_SEARCH|...] 등 → 화이트리스트 CMD
    3. [CMD:EXEC|...] 등 → 블랙리스트, 항상 차단
    4. 미지 CMD → OWNER 채널이면 경고+로그, 아니면 차단
    """

    SAFE_COMMANDS = {"YT_SEARCH", "MAP", "WEATHER", "TIME"}

    DANGEROUS_COMMANDS = {
        "EXEC":        "Shell RCE 위험",
        "SHELL":       "Shell RCE 위험",
        "DELETE":      "데이터 손실 위험",
        "WRITE":       "파일 변조 위험",
        "SPAWN":       "프로세스 남용 위험",
        "EVAL":        "임의 코드 실행",
        "PYTHON_EXEC": "임의 코드 실행 (Skill 라이브러리로 대체하세요)",
    }

    def __init__(self, db, ai_engine=None, memory_system=None):
        self.db             = db
        self.ai_engine      = ai_engine
        self.memory         = memory_system
        self.channel_auth   = ChannelAuthenticator()
        self.skill_library  = SkillLibrary(memory_system)
        audit_path          = Path(db.base_dir) / "audit.json"
        self.audit_log      = CommandAuditLog(audit_path)
        print("[Gateway] 🛡️ v5.0 초기화 완료")

    # ── Main Message Handler ─────────────────────────────

    def process_message(
        self, channel: str, content: str, language: str = "auto"
    ) -> Dict[str, Any]:

        print(f"\n[{channel.upper()}] 수신: {content[:50]}...")

        trust          = self.channel_auth.get_trust(channel)
        injection_scan = PromptInjectionDetector.scan(content, channel_trust=trust)

        if injection_scan["raw_suspicious"]:
            print(
                f"⚠️ [Security] 의심 입력 감지 — "
                f"위협: {injection_scan['threat_level']} | "
                f"차단: {injection_scan['is_suspicious']}"
            )

        proactive_action = self.memory.process_mood_and_trigger(content) if self.memory else None

        ai_result = self._call_ai(content, injection_scan, proactive_action)
        learnings  = self._extract_learnings(content, ai_result)

        if ai_result.get("success") and ai_result.get("raw"):
            exec_result = self._execute_commands_safely(ai_result["raw"], trust)
            if exec_result:
                print(f"🛠️ [Execute] {exec_result}")

        node_id = self._save(channel, content, ai_result)

        return {
            "node_id":             node_id,
            "ai_result":           ai_result,
            "learnings_extracted": len(learnings),
            "proactive_action":    proactive_action,
        }

    # ── AI Call ──────────────────────────────────────────

    def _call_ai(self, content: str, injection_scan: Dict, proactive_action: Optional[Dict]) -> Dict:
        if not self.ai_engine or not self.memory:
            return {"raw": "엔진 오류", "success": False}

        try:
            memory_context = self.memory.build_context_prompt()
        except Exception as e:
            print(f"[Memory] ⚠️ 컨텍스트 빌드 실패: {e}")
            memory_context = "You are Jarvis, the Factory Owner's secretary."

        skill_hint = (
            f"\n\n{self.skill_library.list_skills()}\n"
            "중요: 파일 저장, 음악 재생, 리마인더는 반드시 [SKILL:...] 형식을 사용하세요.\n"
        )

        proactive_hint = ""
        if proactive_action:
            comfort = proactive_action.get("comfort_msg", "")
            music   = proactive_action.get("music_queued", "")
            proactive_hint = (
                f"\n\n🔔 [프로액티브] '{music}' 음악 큐. "
                f"자연스럽게 포함: \"{comfort}\"\n"
            )

        full_prompt = (
            f"{memory_context}{skill_hint}{proactive_hint}\n"
            f"USER MESSAGE:\n{content}\n\nRESPOND NOW!"
        )

        try:
            result = self.ai_engine.ask(
                full_prompt,
                temperature=0.7,
                untrusted=(injection_scan["threat_level"] in ["high", "critical"]),
            )
        except Exception as e:
            print(f"[Gateway] ⚠️ AI 호출 실패: {e}")
            result = self.ai_engine._create_error_response(str(e))

        if not isinstance(result, dict):
            result = self.ai_engine._create_error_response("잘못된 응답 형식")

        result.setdefault("success", False)
        result.setdefault("raw", "죄송합니다. 엔진 점검 중입니다.")
        return result

    # ── Learning ─────────────────────────────────────────

    def _extract_learnings(self, content: str, ai_result: Dict) -> List:
        if not (ai_result.get("success") and ai_result.get("raw") and self.memory):
            return []
        try:
            learnings = self.memory.extract_learnings(
                content, ai_result["raw"], self.ai_engine.lm_studio_url
            )
            if learnings:
                self.memory.update_learning(learnings)
            ai_result["learnings_extracted"] = len(learnings)
            return learnings
        except Exception as e:
            print(f"[Learning] ⚠️ 학습 추출 실패: {e}")
            return []

    # ── Command Execution ─────────────────────────────────

    def _execute_commands_safely(
        self, ai_raw_text: str, trust: ChannelTrust
    ) -> Optional[str]:
        results = []

        # 1. SKILL tags
        for m in re.finditer(r'\[SKILL:(\w+)\|(.*?)\]', ai_raw_text, re.DOTALL):
            skill_name, params = m.group(1), m.group(2).strip()
            result = self.skill_library.execute(skill_name, params)
            self.audit_log.log_command(f"SKILL:{skill_name}", params[:40], "executed", "skill_library")
            results.append(result)

        # 2. CMD tags
        for m in re.finditer(r'\[CMD:\s*(\w+)\|(.*?)\]', ai_raw_text):
            cmd_type = m.group(1).upper()
            cmd_data = m.group(2).strip()

            if cmd_type in self.DANGEROUS_COMMANDS:
                reason = self.DANGEROUS_COMMANDS[cmd_type]
                self.audit_log.log_command(cmd_type, cmd_data[:40], "blocked", reason)
                print(f"🚫 [Security] 차단: {cmd_type} — {reason}")
                hint = " (대신 [SKILL:...] 사용)" if cmd_type == "PYTHON_EXEC" else ""
                results.append(f"🚫 차단: {cmd_type}{hint}")
                continue

            if cmd_type in self.SAFE_COMMANDS:
                result = self._execute_safe_cmd(cmd_type, cmd_data)
                self.audit_log.log_command(cmd_type, cmd_data[:40], "executed", "whitelisted")
                results.append(result)
                continue

            # Unknown command
            if trust == ChannelTrust.OWNER:
                self.audit_log.log_command(cmd_type, cmd_data[:40], "pending_approval", "unknown_cmd_owner")
                print(f"⚠️ [Security] OWNER 미지 명령 기록: {cmd_type}")
                results.append(f"⚠️ 미지 명령 기록됨: {cmd_type}")
            else:
                self.audit_log.log_command(cmd_type, cmd_data[:40], "blocked", "unknown_command")
                results.append(f"🚫 미지 명령 차단: {cmd_type}")

        return " | ".join(results) if results else None

    def _execute_safe_cmd(self, cmd_type: str, cmd_data: str) -> str:
        if cmd_type == "YT_SEARCH":
            webbrowser.open(f"https://www.youtube.com/results?search_query={cmd_data}")
            return "✅ YouTube 검색 실행"
        if cmd_type == "MAP":
            webbrowser.open(f"https://www.google.com/maps/search/{cmd_data}")
            return "✅ 지도 검색 실행"
        if cmd_type == "WEATHER":
            return f"✅ {cmd_data} 날씨 조회"
        if cmd_type == "TIME":
            return f"✅ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        return f"✅ {cmd_type} 실행됨"

    # ── Save ─────────────────────────────────────────────

    def _save(self, channel: str, content: str, ai_result: Dict) -> str:
        try:
            node_id = self.db.save_node(channel, content, ai_result)
            if self.memory:
                self.memory.update_session()
            return node_id
        except Exception as e:
            print(f"[Gateway] ⚠️ 저장 실패: {e}")
            return "save_error"
