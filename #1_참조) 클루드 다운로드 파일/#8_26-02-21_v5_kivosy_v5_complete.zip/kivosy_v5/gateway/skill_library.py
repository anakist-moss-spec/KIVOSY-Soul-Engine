"""
KIVOSY v5.0 - Skill Library
Responsibility: Pre-defined, safe high-level skills (replaces raw PYTHON_EXEC).
"""

import json
import uuid
import webbrowser
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, Optional


class SkillLibrary:
    """
    사전 정의된 고수준 Skill 집합.

    왜 PYTHON_EXEC를 제거했나?
    ─────────────────────────────────────────────────────────
    기존: 14B가 임의 파이썬 코드를 문자열로 생성 → 실행
    문제: RCE(원격 코드 실행) 취약점과 동일한 위험

    Skill 방식: 14B가 "[SKILL:save_meeting_notes|제목|내용]" 출력
    → SkillLibrary가 파라미터 파싱 → 검증된 함수 실행
    ─────────────────────────────────────────────────────────

    새 Skill 추가:
        1. execute_SKILL_NAME(params) 메서드 추가
        2. SKILL_MAP에 등록
        3. JARVIS_SYSTEM_PROMPT에 예시 추가
    """

    def __init__(self, memory_system=None):
        self.memory = memory_system
        self.SKILL_MAP: Dict[str, Callable] = {
            "save_meeting_notes":  self.execute_save_meeting_notes,
            "summarize_and_store": self.execute_summarize_and_store,
            "play_mood_music":     self.execute_play_mood_music,
            "set_reminder":        self.execute_set_reminder,
            "search_my_notes":     self.execute_search_my_notes,
        }

    # ── Skills ───────────────────────────────────────────

    def execute_save_meeting_notes(self, params: str) -> str:
        """파라미터 형식: "제목|내용" """
        parts   = params.split("|", 1)
        title   = parts[0].strip() if len(parts) > 0 else "미팅 노트"
        content = parts[1].strip() if len(parts) > 1 else params

        if self.memory:
            self.memory.proactive.save_meeting_notes(content, title)
            notes_dir = self.memory.memory_dir / "notes"
            notes_dir.mkdir(exist_ok=True)
            note_file = notes_dir / f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{title[:20]}.md"
            try:
                note_file.write_text(
                    f"# {title}\n\n{datetime.now().strftime('%Y-%m-%d %H:%M')}\n\n{content}",
                    encoding="utf-8",
                )
            except Exception as e:
                print(f"[Skill] ⚠️ 노트 파일 저장 실패: {e}")

        print(f"[Skill] 📝 미팅 노트 저장 완료: {title}")
        return f"✅ '{title}' 저장 완료"

    def execute_summarize_and_store(self, params: str) -> str:
        """파라미터 형식: "카테고리|내용" """
        parts    = params.split("|", 1)
        category = parts[0].strip() if len(parts) > 0 else "general"
        content  = parts[1].strip() if len(parts) > 1 else params
        if self.memory:
            self.memory.proactive.summarize_and_store(content, category)
        print(f"[Skill] 💾 요약 저장: {category}")
        return f"✅ [{category}] 요약 저장 완료"

    def execute_play_mood_music(self, params: str) -> str:
        """파라미터 형식: "mood_type" (relaxing|energetic|focused|calming)"""
        mood = params.strip().lower()
        playlists = {
            "relaxing":  ("로파이 힙합",     "https://www.youtube.com/results?search_query=lofi+hip+hop"),
            "energetic": ("에너지 업 믹스",   "https://www.youtube.com/results?search_query=energetic+workout+music"),
            "focused":   ("집중력 향상 음악", "https://www.youtube.com/results?search_query=focus+study+music"),
            "calming":   ("마음 진정 음악",   "https://www.youtube.com/results?search_query=calming+peaceful+music"),
        }
        name, url = playlists.get(mood, ("기본 플레이리스트", "https://www.youtube.com/results?search_query=relaxing+music"))
        webbrowser.open(url)
        print(f"[Skill] 🎵 음악 재생: {name}")
        return f"✅ '{name}' 재생 시작"

    def execute_set_reminder(self, params: str) -> str:
        """파라미터 형식: "HH:MM|내용" """
        parts    = params.split("|", 1)
        time_str = parts[0].strip() if len(parts) > 0 else "미정"
        content  = parts[1].strip() if len(parts) > 1 else params

        if self.memory:
            reminders_file = self.memory.memory_dir / "reminders.json"
            try:
                import json as _json
                data = _json.loads(reminders_file.read_text(encoding="utf-8")) \
                    if reminders_file.exists() else {"reminders": []}
                data["reminders"].append({
                    "id":         str(uuid.uuid4())[:8],
                    "time":       time_str,
                    "content":    content,
                    "created_at": datetime.now().isoformat(),
                    "notified":   False,
                })
                reminders_file.write_text(_json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            except Exception as e:
                print(f"[Skill] ⚠️ 리마인더 저장 실패: {e}")

        print(f"[Skill] ⏰ 리마인더 설정: {time_str} — {content}")
        return f"✅ {time_str}에 '{content}' 리마인더 설정됨"

    def execute_search_my_notes(self, params: str) -> str:
        """파라미터 형식: "검색어" """
        query = params.strip()
        if not self.memory:
            return "❌ 메모리 시스템 오프라인"

        notes_dir = self.memory.memory_dir / "notes"
        if not notes_dir.exists():
            return "📂 저장된 노트 없음"

        results = []
        for note_file in notes_dir.glob("*.md"):
            try:
                if query.lower() in note_file.read_text(encoding="utf-8").lower():
                    results.append(note_file.stem[:30])
            except Exception:
                pass

        if results:
            found = ", ".join(results[:3])
            print(f"[Skill] 🔍 노트 검색 결과: {found}")
            return f"✅ 검색 결과: {found}"
        return f"🔍 '{query}' 관련 노트 없음"

    # ── Dispatch ─────────────────────────────────────────

    def execute(self, skill_name: str, params: str) -> str:
        handler = self.SKILL_MAP.get(skill_name)
        if not handler:
            available = ", ".join(self.SKILL_MAP.keys())
            return f"❌ 알 수 없는 Skill: {skill_name}. 사용 가능: {available}"
        try:
            return handler(params)
        except Exception as e:
            print(f"[Skill] ⚠️ {skill_name} 실행 오류: {e}")
            return f"⚠️ {skill_name} 실행 중 오류 발생"

    def list_skills(self) -> str:
        descriptions = {
            "save_meeting_notes":  "미팅/대화 내용 저장. 형식: [SKILL:save_meeting_notes|제목|내용]",
            "summarize_and_store": "내용 요약 후 카테고리별 저장. 형식: [SKILL:summarize_and_store|카테고리|내용]",
            "play_mood_music":     "무드 음악 재생. 형식: [SKILL:play_mood_music|relaxing/energetic/focused/calming]",
            "set_reminder":        "리마인더 설정. 형식: [SKILL:set_reminder|HH:MM|내용]",
            "search_my_notes":     "저장된 노트 검색. 형식: [SKILL:search_my_notes|검색어]",
        }
        lines = ["📚 사용 가능한 Skill:"]
        for name, desc in descriptions.items():
            lines.append(f"  - {name}: {desc}")
        return "\n".join(lines)
