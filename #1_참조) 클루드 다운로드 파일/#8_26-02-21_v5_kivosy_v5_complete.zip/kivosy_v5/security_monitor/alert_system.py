"""
KIVOSY v5.0 - Alert System
Responsibility: Critical threat notifications (screen, audio, SMS).
Runs in a SEPARATE thread — never blocks the main process.
"""

import threading
import time
from datetime import datetime
from enum import Enum
from typing import Callable, List, Optional


class AlertLevel(Enum):
    INFO     = "info"
    WARNING  = "warning"
    CRITICAL = "critical"


class AlertSystem:
    """
    실시간 보안 알림 시스템.

    독립 스레드에서 실행 — 메인 프로세스를 절대 차단하지 않습니다.
    """

    def __init__(self, owner_phone: Optional[str] = None):
        self._owner_phone = owner_phone
        self._alert_log: List[dict] = []
        self._lock = threading.Lock()
        self._callbacks: List[Callable] = []

    def register_callback(self, callback: Callable):
        """외부 알림 콜백 등록 (e.g., 웹소켓 푸시)."""
        self._callbacks.append(callback)

    # ── Public Alert Methods ─────────────────────────────

    def info(self, message: str, source: str = "system"):
        self._dispatch(AlertLevel.INFO, message, source)

    def warning(self, message: str, source: str = "system"):
        self._dispatch(AlertLevel.WARNING, message, source)

    def critical(self, threat: str, source: str = "system"):
        """
        크리티컬 위협 알림.
        - 빨간 화면 오버레이 (비동기)
        - 경고음 (비동기)
        - SMS 알림 (설정 시)
        """
        self._dispatch(AlertLevel.CRITICAL, threat, source)
        threading.Thread(target=self._red_screen_alert, args=(threat,), daemon=True).start()
        threading.Thread(target=self._play_alert_sound,  daemon=True).start()
        if self._owner_phone:
            threading.Thread(target=self._send_sms, args=(threat,), daemon=True).start()

    def get_recent_alerts(self, limit: int = 20) -> List[dict]:
        with self._lock:
            return list(self._alert_log[-limit:])

    # ── Internal ─────────────────────────────────────────

    def _dispatch(self, level: AlertLevel, message: str, source: str):
        entry = {
            "level":     level.value,
            "message":   message,
            "source":    source,
            "timestamp": datetime.now().isoformat(),
        }
        with self._lock:
            self._alert_log.append(entry)
            self._alert_log = self._alert_log[-500:]

        emoji = {"info": "ℹ️", "warning": "⚠️", "critical": "🚨"}.get(level.value, "❓")
        print(f"[AlertSystem] {emoji} [{level.value.upper()}] {source}: {message}")

        for cb in self._callbacks:
            try:
                cb(entry)
            except Exception as e:
                print(f"[AlertSystem] ⚠️ 콜백 오류: {e}")

    def _red_screen_alert(self, threat: str):
        """tkinter 빨간 화면 오버레이 (스레드에서 실행)."""
        try:
            import tkinter as tk
            root = tk.Tk()
            root.attributes("-fullscreen", True)
            root.attributes("-topmost", True)
            root.configure(bg="red")

            label = tk.Label(
                root,
                text=f"🚨 SECURITY ALERT 🚨\n\n{threat}\n\n클릭하여 닫기",
                bg="red",
                fg="white",
                font=("Arial", 24, "bold"),
                justify="center",
            )
            label.pack(expand=True)
            root.bind("<Button-1>", lambda e: root.destroy())
            root.after(5000, root.destroy)   # 5초 후 자동 닫기
            root.mainloop()
        except Exception as e:
            print(f"[AlertSystem] ⚠️ 빨간 화면 표시 실패: {e}")

    def _play_alert_sound(self):
        """경고음 재생."""
        try:
            import winsound
            for _ in range(3):
                winsound.Beep(1000, 500)
                time.sleep(0.2)
        except ImportError:
            try:
                import os
                os.system("paplay /usr/share/sounds/alsa/Front_Left.wav 2>/dev/null || "
                           "afplay /System/Library/Sounds/Funk.aiff 2>/dev/null || "
                           "echo -e '\\a\\a\\a'")
            except Exception:
                print("[AlertSystem] ⚠️ 경고음 재생 불가")

    def _send_sms(self, threat: str):
        """
        SMS 알림 (Twilio 연동 예시).
        실제 사용 시 twilio 설정 필요.
        """
        try:
            from twilio.rest import Client
            # 환경변수에서 자격증명 로드 (절대 하드코딩 금지)
            import os
            account_sid = os.environ.get("TWILIO_ACCOUNT_SID")
            auth_token  = os.environ.get("TWILIO_AUTH_TOKEN")
            from_number = os.environ.get("TWILIO_FROM_NUMBER")

            if not all([account_sid, auth_token, from_number, self._owner_phone]):
                print("[AlertSystem] ℹ️ Twilio 미설정 — SMS 건너뜀")
                return

            client = Client(account_sid, auth_token)
            client.messages.create(
                body=f"🚨 KIVOSY SECURITY ALERT: {threat[:100]}",
                from_=from_number,
                to=self._owner_phone,
            )
            print(f"[AlertSystem] 📱 SMS 발송됨: {self._owner_phone}")
        except Exception as e:
            print(f"[AlertSystem] ⚠️ SMS 발송 실패: {e}")
