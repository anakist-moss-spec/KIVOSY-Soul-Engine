"""
KIVOSY v5.0 - File Guardian
Responsibility: File integrity monitoring for critical system files.
"""

import hashlib
import json
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from .alert_system import AlertSystem


class FileGuardian:
    """
    중요 파일의 무결성을 주기적으로 검사합니다.
    파일 변조 시 즉시 알림을 발생시킵니다.
    """

    CHECK_INTERVAL = 120   # 초

    def __init__(self, alert_system: AlertSystem, baseline_file: str = "memory/file_baseline.json"):
        self._alert    = alert_system
        self._baseline_path = Path(baseline_file)
        self._baseline_path.parent.mkdir(parents=True, exist_ok=True)
        self._baseline: Dict[str, str] = self._load_baseline()
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._violations: List[dict] = []

    def watch_files(self, paths: List[str]):
        """감시할 파일 목록 등록 및 베이스라인 수집."""
        for p in paths:
            path = Path(p)
            if path.exists():
                h = self._hash(path)
                self._baseline[str(path)] = h
                print(f"[FileGuardian] 📋 베이스라인 등록: {path.name}")

        self._save_baseline()

    def start(self):
        """백그라운드 무결성 감시 시작."""
        if not self._baseline:
            print("[FileGuardian] ⚠️ 감시 파일 없음 — watch_files()를 먼저 호출하세요")
            return

        self._stop_event.clear()
        self._thread = threading.Thread(target=self._watch_loop, daemon=True)
        self._thread.start()
        print(f"[FileGuardian] ✅ 파일 무결성 감시 시작 ({len(self._baseline)}개 파일)")

    def stop(self):
        self._stop_event.set()

    def get_violations(self) -> List[dict]:
        return list(self._violations)

    # ── Internal ─────────────────────────────────────────

    def _watch_loop(self):
        while not self._stop_event.is_set():
            self._check_integrity()
            self._stop_event.wait(timeout=self.CHECK_INTERVAL)

    def _check_integrity(self):
        for filepath, expected_hash in list(self._baseline.items()):
            path = Path(filepath)

            if not path.exists():
                entry = {
                    "file":        filepath,
                    "event":       "deleted",
                    "detected_at": datetime.now().isoformat(),
                }
                self._violations.append(entry)
                self._alert.critical(
                    threat=f"파일 삭제 감지: {path.name}",
                    source="file_guardian",
                )
                continue

            current_hash = self._hash(path)
            if current_hash != expected_hash:
                entry = {
                    "file":          filepath,
                    "event":         "modified",
                    "expected_hash": expected_hash[:16],
                    "current_hash":  current_hash[:16],
                    "detected_at":   datetime.now().isoformat(),
                }
                self._violations.append(entry)
                self._alert.critical(
                    threat=f"파일 변조 감지: {path.name}",
                    source="file_guardian",
                )
                # 베이스라인 업데이트 (재알림 방지)
                self._baseline[filepath] = current_hash
                self._save_baseline()

    @staticmethod
    def _hash(path: Path) -> str:
        sha256 = hashlib.sha256()
        try:
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(8192), b""):
                    sha256.update(chunk)
        except Exception:
            return ""
        return sha256.hexdigest()

    def _load_baseline(self) -> Dict[str, str]:
        try:
            if self._baseline_path.exists():
                return json.loads(self._baseline_path.read_text(encoding="utf-8"))
        except Exception:
            pass
        return {}

    def _save_baseline(self):
        try:
            self._baseline_path.write_text(
                json.dumps(self._baseline, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except Exception as e:
            print(f"[FileGuardian] ⚠️ 베이스라인 저장 실패: {e}")
