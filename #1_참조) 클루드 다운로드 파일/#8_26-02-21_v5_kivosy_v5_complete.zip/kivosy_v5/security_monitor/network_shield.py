"""
KIVOSY v5.0 - Network Shield
Responsibility: Monitoring inbound connections for anomalies.
Read-only network access.
"""

import threading
import time
from datetime import datetime
from typing import List, Optional, Set

from .alert_system import AlertSystem


# 감시할 포트 (외부 스캔 의심)
SENSITIVE_PORTS: Set[int] = {22, 23, 3389, 4444, 5555, 8080, 31337}


class NetworkShield:
    """
    비정상 네트워크 연결 모니터링.
    읽기 전용 — 연결을 차단하지 않고 알림만 발생시킵니다.
    """

    CHECK_INTERVAL = 60   # 초

    def __init__(self, alert_system: AlertSystem):
        self._alert     = alert_system
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._known_connections: Set[str] = set()
        self._anomalies: List[dict] = []

    def start(self):
        """백그라운드 네트워크 감시 시작."""
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._watch_loop, daemon=True)
        self._thread.start()
        print(f"[NetworkShield] ✅ 네트워크 감시 시작 (간격: {self.CHECK_INTERVAL}s)")

    def stop(self):
        self._stop_event.set()
        print("[NetworkShield] 🛑 네트워크 감시 중단")

    def get_anomalies(self) -> List[dict]:
        return list(self._anomalies)

    # ── Internal ─────────────────────────────────────────

    def _watch_loop(self):
        while not self._stop_event.is_set():
            self._check_connections()
            self._stop_event.wait(timeout=self.CHECK_INTERVAL)

    def _check_connections(self):
        try:
            import psutil
        except ImportError:
            print("[NetworkShield] ⚠️ psutil 미설치")
            self.stop()
            return

        try:
            connections = psutil.net_connections(kind="inet")
            for conn in connections:
                if conn.status != "ESTABLISHED":
                    continue

                raddr = conn.raddr
                if not raddr:
                    continue

                conn_key = f"{raddr.ip}:{raddr.port}"

                # 새 연결이고 민감 포트라면 알림
                if raddr.port in SENSITIVE_PORTS and conn_key not in self._known_connections:
                    entry = {
                        "remote_ip":   raddr.ip,
                        "remote_port": raddr.port,
                        "local_port":  conn.laddr.port if conn.laddr else None,
                        "pid":         conn.pid,
                        "detected_at": datetime.now().isoformat(),
                    }
                    self._anomalies.append(entry)
                    self._alert.warning(
                        message=f"민감 포트 연결: {raddr.ip}:{raddr.port} (PID={conn.pid})",
                        source="network_shield",
                    )

                self._known_connections.add(conn_key)

        except Exception as e:
            print(f"[NetworkShield] ⚠️ 네트워크 스캔 오류: {e}")
