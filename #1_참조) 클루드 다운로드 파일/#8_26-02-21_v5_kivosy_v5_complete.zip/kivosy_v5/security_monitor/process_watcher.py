"""
KIVOSY v5.0 - Process Watcher
Responsibility: Detecting suspicious processes running on the system.
Runs in background thread with read-only system access.
"""

import threading
import time
from datetime import datetime
from typing import List, Optional

from .alert_system import AlertSystem


# 의심스러운 프로세스 이름 목록
SUSPICIOUS_PROCESS_NAMES = [
    "wireshark", "tcpdump", "nmap", "netcat", "nc",
    "keylogger", "screengrab", "spy",
    "meterpreter", "cobaltstrike", "beacon",
    "mimikatz", "pwdump",
    "sqlmap", "burpsuite",
]


class ProcessWatcher:
    """
    백그라운드에서 의심 프로세스를 주기적으로 감시합니다.
    읽기 전용 시스템 접근만 사용합니다.
    """

    CHECK_INTERVAL = 30   # 초

    def __init__(self, alert_system: AlertSystem):
        self._alert  = alert_system
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._detected: List[dict] = []

    def start(self):
        """백그라운드 감시 시작."""
        if self._thread and self._thread.is_alive():
            print("[ProcessWatcher] 이미 실행 중")
            return

        self._stop_event.clear()
        self._thread = threading.Thread(target=self._watch_loop, daemon=True)
        self._thread.start()
        print(f"[ProcessWatcher] ✅ 프로세스 감시 시작 (간격: {self.CHECK_INTERVAL}s)")

    def stop(self):
        """감시 중단."""
        self._stop_event.set()
        print("[ProcessWatcher] 🛑 프로세스 감시 중단")

    def get_detections(self) -> List[dict]:
        return list(self._detected)

    # ── Internal ─────────────────────────────────────────

    def _watch_loop(self):
        while not self._stop_event.is_set():
            self._check_processes()
            self._stop_event.wait(timeout=self.CHECK_INTERVAL)

    def _check_processes(self):
        try:
            import psutil
        except ImportError:
            print("[ProcessWatcher] ⚠️ psutil 미설치 — pip install psutil")
            self.stop()
            return

        try:
            for proc in psutil.process_iter(["pid", "name", "cmdline"]):
                proc_name = (proc.info.get("name") or "").lower()
                for suspicious in SUSPICIOUS_PROCESS_NAMES:
                    if suspicious in proc_name:
                        entry = {
                            "pid":         proc.info["pid"],
                            "name":        proc.info["name"],
                            "detected_at": datetime.now().isoformat(),
                        }
                        self._detected.append(entry)
                        self._alert.critical(
                            threat=f"의심 프로세스 감지: {proc.info['name']} (PID={proc.info['pid']})",
                            source="process_watcher",
                        )
                        break
        except Exception as e:
            print(f"[ProcessWatcher] ⚠️ 프로세스 스캔 오류: {e}")
