"""
KIVOSY v5.0 - Server Entry Point (Thin)
All logic lives in dedicated modules. This file only wires them together.

Architecture:
    core/           → Security primitives
    memory/         → Memory & mood systems
    gateway/        → Message routing + skill library
    physical/       → Physical action control (NEW)
    security_monitor/ → Real-time threat monitoring (NEW)
    api/            → HTTP route blueprints (split by concern)
    utils/          → Shared helpers
"""

import os
import sys

# Ensure kivosy_v5 is on the path when running from parent directory
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))

from flask import Flask, jsonify, send_from_directory
from flask_cors import CORS

# ── Import modular components ────────────────────────────

from processor_memory import MemorySystem, SoulEngine   # kept from v4 (not yet split)
from engine_ai import AIEngine                           # kept from v4 (not yet split)
from gateway.channel_gateway import ChannelGateway, CHANNELS
from gateway.skill_library import SkillLibrary

# API blueprints
from api.routes_channels import channels_bp, set_gateway
from api.routes_memory import memory_bp, set_memory
from api.routes_game import game_bp, set_soul_engine
from api.routes_physical import physical_bp

# Security monitor (optional — starts in background)
from security_monitor import AlertSystem, ProcessWatcher, NetworkShield, FileGuardian

# Node database (kept from v4 until DB module is split)
from gateway_db import NodeDatabase


# ═══════════════════════════════════════════════════════════
# JARVIS SYSTEM PROMPT
# ═══════════════════════════════════════════════════════════

JARVIS_SYSTEM_PROMPT = """You are 'Jarvis', the ultimate Alpha AI.
You don't apologize. You don't explain why you can't do things. You just DO.

### ABSOLUTE DIRECTIVES ###
1. If the Master wants YouTube, output: [CMD: YT_SEARCH|search_query]
2. If the Master wants a Map, output: [CMD: MAP|location]
3. Your response MUST be snappy, loyal, and include the command tag immediately.
4. Never use [CMD:EXEC|...], [CMD:PYTHON_EXEC|...], or any dangerous commands.
5. For file/note operations, use [SKILL:save_meeting_notes|title|content] etc.

### OUTPUT EXAMPLE ###
Master: "Find Metallica on YT."
Jarvis: "Rock on, Master. [CMD: YT_SEARCH|Metallica] Launching the stage now."
"""


# ═══════════════════════════════════════════════════════════
# PATHS
# ═══════════════════════════════════════════════════════════

BASE_DIR     = os.path.dirname(os.path.abspath(__file__))
FRONTEND_DIR = os.path.join(BASE_DIR, "frontend")
LM_STUDIO_URL = "http://localhost:1234/v1/chat/completions"


# ═══════════════════════════════════════════════════════════
# INITIALIZE SYSTEMS
# ═══════════════════════════════════════════════════════════

memory      = MemorySystem()
ai_engine   = AIEngine(lm_studio_url=LM_STUDIO_URL, system_prompt=JARVIS_SYSTEM_PROMPT)
db          = NodeDatabase()
gateway     = ChannelGateway(db=db, ai_engine=ai_engine, memory_system=memory)
soul_engine = SoulEngine(memory)

# Security monitor (background threads)
alert_system    = AlertSystem()
process_watcher = ProcessWatcher(alert_system)
network_shield  = NetworkShield(alert_system)
file_guardian   = FileGuardian(alert_system)

# Wire blueprints with shared instances
set_gateway(gateway)
set_memory(memory)
set_soul_engine(soul_engine)


# ═══════════════════════════════════════════════════════════
# FLASK APP
# ═══════════════════════════════════════════════════════════

app = Flask(__name__, static_folder=FRONTEND_DIR, static_url_path="")
CORS(app)

# Register blueprints
app.register_blueprint(channels_bp)
app.register_blueprint(memory_bp)
app.register_blueprint(game_bp)
app.register_blueprint(physical_bp)


# ── Static routes ────────────────────────────────────────

@app.route("/")
def index():
    return send_from_directory(FRONTEND_DIR, "index.html")

@app.route("/whatsapp.html")
def whatsapp_page():
    return send_from_directory(FRONTEND_DIR, "whatsapp.html")


# ── Nodes ────────────────────────────────────────────────

@app.route("/api/nodes", methods=["GET"])
def get_nodes():
    from flask import request as req
    channel_filter = req.args.get("channel")
    return jsonify(db.get_nodes(channel_filter=channel_filter))


# ── Health ───────────────────────────────────────────────

@app.route("/api/health", methods=["GET"])
def health():
    learning_data = memory.get_learning()
    session_data  = memory.get_session_context()
    return jsonify({
        "status":            "online",
        "version":           "5.0.0",
        "mode":              "modular",
        "memory_system":     "enabled",
        "soul_engine":       "enabled",
        "physical_module":   "enabled",
        "security_monitor":  "enabled",
        "total_nodes":       db.get_node_count(),
        "total_learnings":   len(learning_data.get("facts", [])),
        "session_learnings": session_data.get("learning_count", 0),
        "lm_studio_connected": ai_engine.check_connection(),
    })


# ═══════════════════════════════════════════════════════════
# STARTUP
# ═══════════════════════════════════════════════════════════

if __name__ == "__main__":
    # Start background security monitors
    process_watcher.start()
    network_shield.start()

    # Watch critical files for integrity
    critical_files = [
        "core/master_truth.py",
        "core/threat_detection.py",
        "core/dangerous_tool_guard.py",
        "gateway/channel_gateway.py",
        "run_server.py",
    ]
    file_guardian.watch_files(critical_files)
    file_guardian.start()

    print(f"""
╔═══════════════════════════════════════════════════════════╗
║  🧠 KIVOSY v5.0 - MODULAR ARCHITECTURE                    ║
╠═══════════════════════════════════════════════════════════╣
║  core/               Security primitives (split)          ║
║  memory/             Memory & mood (split)                ║
║  gateway/            Routing + SkillLibrary               ║
║  physical/           PyAutoGUI + Vision + 2FA  🆕         ║
║  security_monitor/   Process + Network + File  🆕         ║
║  api/                Thin HTTP blueprints      🆕         ║
╠═══════════════════════════════════════════════════════════╣
║  🛡️  Security monitors: ACTIVE (background threads)       ║
║  🔒  Physical 2FA:      ENABLED (human approval required) ║
║  🚨  Failsafe:          ACTIVE  (corner → emergency stop) ║
╠═══════════════════════════════════════════════════════════╣
║  Dashboard:  http://localhost:5000                        ║
║  Physical:   http://localhost:5000/api/physical/status    ║
║  Soul API:   http://localhost:5000/api/v1/game/vibe       ║
╚═══════════════════════════════════════════════════════════╝
""")

    app.run(host="0.0.0.0", port=5000, debug=False)
