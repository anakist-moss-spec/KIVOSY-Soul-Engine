"""
KIVOSY v5.0 - Safe API Parser
Responsibility: Defensive parsing of LM Studio / external API responses.
"""

import json
import re
from typing import Any, List, Optional


class SafeAPIParser:
    """
    Defensive parser for LM Studio API responses.
    NEVER crashes on malformed JSON or missing keys.
    """

    @staticmethod
    def extract_content(response_data: Any, fallback: str = "") -> str:
        """
        Safely extract content from API response with multiple fallback strategies.
        """
        try:
            if isinstance(response_data, dict):
                # Strategy 1: Standard OpenAI format
                choices = response_data.get("choices", [])
                if choices:
                    first = choices[0]
                    if isinstance(first, dict):
                        message = first.get("message", {})
                        if isinstance(message, dict):
                            content = message.get("content")
                            if content is not None:
                                return str(content)

                # Strategy 2: Direct content field
                content = response_data.get("content")
                if content is not None:
                    return str(content)

                # Strategy 3: Text field
                text = response_data.get("text")
                if text is not None:
                    return str(text)

            if isinstance(response_data, str):
                return response_data

            print(f"[SafeParser] ⚠️ Could not extract content from: {type(response_data)}")
            return fallback

        except Exception as e:
            print(f"[SafeParser] ⚠️ Exception during extraction: {e}")
            return fallback

    @staticmethod
    def safe_json_extract(text: str, pattern: str = r'\[[\s\S]*?\]') -> Optional[List]:
        """Safely extract and parse JSON array from text."""
        try:
            m = re.search(pattern, text, re.DOTALL)
            if m:
                return json.loads(m.group(0))
        except (json.JSONDecodeError, AttributeError) as e:
            print(f"[SafeParser] ⚠️ JSON extraction failed: {e}")
        return None
