"""
KIVOSY v5.0 - Unified Logger
"""

import logging
import sys
from pathlib import Path


def KivosyLogger(name: str, log_file: str = "kivosy.log") -> logging.Logger:
    """
    KIVOSY 통합 로거 팩토리.

    Args:
        name:     모듈 이름 (e.g., "gateway", "physical")
        log_file: 로그 파일 경로

    Returns:
        설정된 Logger 인스턴스
    """
    logger = logging.getLogger(f"kivosy.{name}")
    if logger.handlers:
        return logger   # 이미 설정됨

    logger.setLevel(logging.DEBUG)

    formatter = logging.Formatter(
        "%(asctime)s [%(name)s] %(levelname)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # Console handler
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.INFO)
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    # File handler
    try:
        fh = logging.FileHandler(log_file, encoding="utf-8")
        fh.setLevel(logging.DEBUG)
        fh.setFormatter(formatter)
        logger.addHandler(fh)
    except Exception as e:
        print(f"[Logger] ⚠️ 파일 핸들러 설정 실패: {e}")

    return logger
