"""
KIVOSY v4.3.0 - Memory Processor Module
Chief Security Architect: Claude (Anthropic)

v4.3.0 변경사항:
✅ MoodContext: 세션 간 감정/상태 기억 (파일 영속 저장)
✅ TriggerSystem: "오늘 힘들었어" → 저녁에 자동 위로 트리거
✅ ProactiveAction: 실제로 "무언가를 해주는" 시뮬레이션 레이어
✅ ChannelTrust 연동 (security_core v4.3.0)
✅ 기존 모든 메모리 기능 100% 유지
"""

from datetime import datetime, timedelta
import json
import os
import re
import uuid
from pathlib import Path
from typing import Dict, List, Optional, Any
import requests

from security_core import (
    MasterTruthTable,
    PromptInjectionDetector,
    UntrustedContentHandler,
    ChannelTrust,
)


# ═══════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════

class SafeParser:
    @staticmethod
    def safe_json_extract(text: str, pattern: str = r'\[[\s\S]*?\]') -> Optional[List]:
        try:
            m = re.search(pattern, text)
            if m:
                return json.loads(m.group(0))
        except (json.JSONDecodeError, AttributeError) as e:
            print(f"[Memory.SafeParser] ⚠️ JSON 파싱 실패: {e}")
        return None


# ═══════════════════════════════════════════════════════════
# MOOD CONTEXT (신규)
# ═══════════════════════════════════════════════════════════

class MoodContext:
    """
    세션 간 감정/상태 기억.

    SoulEngine이 실시간 무드 점수를 계산하는 것과 달리,
    MoodContext는 공장장이 언급한 감정 상태를 파일에 영속 저장합니다.

    예:
        "오늘 미팅이 너무 힘들었어"
        → morning_note: "미팅 힘듦" 저장
        → 저녁에 check_triggers() 호출 시 위로 메시지 트리거
    """

    # 감정 키워드 → 상태 레이블
    STRESS_KEYWORDS   = ["힘들", "피곤", "지쳐", "바빠", "힘드", "스트레스", "최악", "짜증"]
    HAPPY_KEYWORDS    = ["좋았", "신나", "행복", "성공", "완료", "해냈", "칭찬"]
    TIRED_KEYWORDS    = ["졸려", "피곤", "힘들", "쉬고싶", "눕고싶"]
    ANXIOUS_KEYWORDS  = ["걱정", "불안", "두렵", "무서", "긴장"]

    def __init__(self, mood_file: Path):
        self._file = mood_file
        self._data = self._load()

    # ── 기록 ──────────────────────────────────────────────

    def record_from_message(self, message: str) -> Optional[Dict]:
        """
        메시지에서 감정 상태를 감지해 기록.
        감지된 경우 기록 딕셔너리 반환, 아니면 None.
        """
        detected = self._detect(message)
        if not detected:
            return None

        entry = {
            "id":          str(uuid.uuid4())[:8],
            "recorded_at": datetime.now().isoformat(),
            "hour":        datetime.now().hour,
            "states":      detected,
            "raw_snippet": message[:80],
            "triggered":   False,   # 트리거 발화 여부
        }
        self._data.setdefault("entries", []).append(entry)
        # 최근 50개만 유지
        self._data["entries"] = self._data["entries"][-50:]
        self._save()

        labels = ", ".join(detected)
        print(f"[MoodContext] 😶 감정 기록: {labels} | {message[:40]}")
        return entry

    def _detect(self, text: str) -> List[str]:
        states = []
        if any(kw in text for kw in self.STRESS_KEYWORDS):
            states.append("stressed")
        if any(kw in text for kw in self.HAPPY_KEYWORDS):
            states.append("happy")
        if any(kw in text for kw in self.TIRED_KEYWORDS):
            states.append("tired")
        if any(kw in text for kw in self.ANXIOUS_KEYWORDS):
            states.append("anxious")
        return states

    # ── 트리거 확인 ───────────────────────────────────────

    def get_pending_triggers(self, current_hour: int = None) -> List[Dict]:
        """
        현재 시각 기준으로 발화 대기 중인 감정 트리거 목록 반환.

        규칙:
        - 아침(6~12시)에 "stressed/tired/anxious" 기록
          → 저녁(18~23시)에 트리거
        - 낮(12~18시)에 기록
          → 퇴근 시간대(18~20시)에 트리거
        """
        if current_hour is None:
            current_hour = datetime.now().hour

        pending = []
        for entry in self._data.get("entries", []):
            if entry.get("triggered"):
                continue

            negative_states = {"stressed", "tired", "anxious"}
            entry_states = set(entry.get("states", []))
            if not entry_states & negative_states:
                continue

            recorded_hour = entry.get("hour", 0)
            should_trigger = False

            if 6 <= recorded_hour < 12 and 18 <= current_hour <= 23:
                should_trigger = True
            elif 12 <= recorded_hour < 18 and 18 <= current_hour <= 20:
                should_trigger = True

            if should_trigger:
                pending.append(entry)

        return pending

    def mark_triggered(self, entry_id: str):
        """트리거 발화 완료 표시."""
        for entry in self._data.get("entries", []):
            if entry.get("id") == entry_id:
                entry["triggered"] = True
                entry["triggered_at"] = datetime.now().isoformat()
        self._save()

    def get_today_summary(self) -> Dict:
        """오늘 감정 요약."""
        today = datetime.now().date().isoformat()
        today_entries = [
            e for e in self._data.get("entries", [])
            if e.get("recorded_at", "").startswith(today)
        ]
        all_states: List[str] = []
        for e in today_entries:
            all_states.extend(e.get("states", []))

        from collections import Counter
        counts = Counter(all_states)
        dominant = counts.most_common(1)[0][0] if counts else "neutral"
        return {
            "date":          today,
            "entry_count":   len(today_entries),
            "dominant_mood": dominant,
            "state_counts":  dict(counts),
        }

    # ── 내부 ─────────────────────────────────────────────

    def _load(self) -> Dict:
        try:
            if self._file.exists():
                return json.loads(self._file.read_text(encoding="utf-8"))
        except Exception as e:
            print(f"[MoodContext] ⚠️ 로드 실패: {e}")
        return {"entries": []}

    def _save(self):
        try:
            self._file.write_text(
                json.dumps(self._data, ensure_ascii=False, indent=2),
                encoding="utf-8"
            )
        except Exception as e:
            print(f"[MoodContext] ⚠️ 저장 실패: {e}")


# ═══════════════════════════════════════════════════════════
# PROACTIVE ACTION LAYER (신규)
# ═══════════════════════════════════════════════════════════

class ProactiveAction:
    """
    "말하는" 것을 넘어 "행동하는" AI를 위한 레이어.

    현재 버전: 시뮬레이션 (실제 외부 API 연동 전 단계)
    - 음악 큐 (추후 Spotify/멜론 API 연동)
    - 알림 메시지 생성 (추후 푸시 연동)
    - 미팅 요약 저장 (추후 캘린더 API 연동)

    각 액션은 action_log.json에 기록됩니다.
    """

    def __init__(self, action_log_file: Path):
        self._file = action_log_file
        self._data = self._load()

    # ── 트리거 기반 자동 액션 ─────────────────────────────

    def on_evening_checkin(self, mood_entry: Dict) -> Dict:
        """
        저녁 체크인: 힘들었던 하루 감지 시 자동 실행.
        반환값을 게이트웨이가 응답에 삽입합니다.
        """
        states = mood_entry.get("states", [])
        snippet = mood_entry.get("raw_snippet", "")

        # 음악 큐
        if "stressed" in states or "tired" in states:
            music = self._queue_music("relaxing")
        elif "anxious" in states:
            music = self._queue_music("calming")
        else:
            music = self._queue_music("upbeat")

        # 위로 메시지 생성
        comfort_msg = self._build_comfort_message(states, snippet)

        action = {
            "type":        "evening_checkin",
            "executed_at": datetime.now().isoformat(),
            "mood_states": states,
            "music_queued": music,
            "comfort_msg": comfort_msg,
        }
        self._log(action)
        return action

    def save_meeting_notes(self, notes: str, title: str = "미팅 노트") -> Dict:
        """미팅 노트 저장 (Skill 라이브러리 액션)."""
        action = {
            "type":        "save_meeting_notes",
            "executed_at": datetime.now().isoformat(),
            "title":       title,
            "preview":     notes[:100],
            "status":      "saved",   # 추후 Notion/Obsidian API 연동
        }
        self._log(action)
        print(f"[ProactiveAction] 📝 미팅 노트 저장: {title}")
        return action

    def summarize_and_store(self, content: str, category: str = "general") -> Dict:
        """요약 후 저장 (Skill 라이브러리 액션)."""
        # 실제 요약은 AIEngine이 수행 — 여기선 저장 레이어만 담당
        action = {
            "type":        "summarize_and_store",
            "executed_at": datetime.now().isoformat(),
            "category":    category,
            "preview":     content[:80],
            "status":      "stored",
        }
        self._log(action)
        print(f"[ProactiveAction] 💾 요약 저장: {category}")
        return action

    def get_recent_actions(self, limit: int = 5) -> List[Dict]:
        return self._data.get("actions", [])[-limit:]

    # ── 내부 헬퍼 ─────────────────────────────────────────

    def _queue_music(self, mood: str) -> str:
        """음악 큐 시뮬레이션. 추후 실제 API로 교체."""
        playlists = {
            "relaxing": "로파이 힙합 — 공부/휴식 비트",
            "calming":  "잔잔한 어쿠스틱 — 마음 진정",
            "upbeat":   "공장장 최애곡 믹스",
        }
        selected = playlists.get(mood, "기본 플레이리스트")
        print(f"[ProactiveAction] 🎵 음악 큐: {selected}")
        return selected

    def _build_comfort_message(self, states: List[str], context: str) -> str:
        if "stressed" in states and "tired" in states:
            return (
                f"공장장님, 오늘 정말 고생 많으셨어요. "
                f"아까 '{context[:30]}' 하셨잖아요 — 그게 계속 마음에 걸렸어요. "
                f"편하게 쉬실 수 있게 좋아하시는 음악 틀어뒀습니다. 🎵"
            )
        if "anxious" in states:
            return (
                f"걱정되는 일이 있으셨죠? 괜찮아요, 공장장님이라면 충분히 해내실 거예요. "
                f"잠깐 음악 들으면서 숨 한번 고르세요. 🎵"
            )
        return (
            "오늘도 수고 많으셨어요, 공장장님. "
            "이제 좀 쉬세요. 음악 준비해뒀습니다. 🎵"
        )

    def _log(self, action: Dict):
        self._data.setdefault("actions", []).append(action)
        self._data["actions"] = self._data["actions"][-200:]
        self._save()

    def _load(self) -> Dict:
        try:
            if self._file.exists():
                return json.loads(self._file.read_text(encoding="utf-8"))
        except Exception as e:
            print(f"[ProactiveAction] ⚠️ 로드 실패: {e}")
        return {"actions": []}

    def _save(self):
        try:
            self._file.write_text(
                json.dumps(self._data, ensure_ascii=False, indent=2),
                encoding="utf-8"
            )
        except Exception as e:
            print(f"[ProactiveAction] ⚠️ 저장 실패: {e}")


# ═══════════════════════════════════════════════════════════
# UNTRUSTED LAYER (기존 유지)
# ═══════════════════════════════════════════════════════════

class UntrustedLayer:
    def __init__(self, untrusted_file: Path):
        self._file = untrusted_file
        self._ensure_file()

    def _ensure_file(self):
        if not self._file.exists():
            self._save({"version": "4.3.0",
                        "created_at": datetime.now().isoformat(),
                        "untrusted_claims": [], "rejected_claims": []})

    def add_claim(self, claim: str, source: str, reason: str = "unverified"):
        data = self._load()
        data["untrusted_claims"].append({
            "claim": claim, "source": source, "reason": reason,
            "timestamp": datetime.now().isoformat(), "verification_status": "pending"
        })
        self._save(data)
        print(f"🛡️ [UNTRUSTED] 격리: {claim[:60]}... ({reason})")

    def reject_claim(self, claim: str, reason: str):
        data = self._load()
        data["rejected_claims"].append({
            "claim": claim, "reason": reason,
            "rejected_at": datetime.now().isoformat()
        })
        self._save(data)
        print(f"🚫 [UNTRUSTED] 거부: {claim[:60]}...")

    def get_claims(self) -> List[Dict]:
        return self._load().get("untrusted_claims", [])

    def _load(self) -> Dict:
        try:
            if self._file.exists():
                return json.loads(self._file.read_text(encoding="utf-8"))
        except:
            pass
        return {"untrusted_claims": [], "rejected_claims": []}

    def _save(self, data: Dict):
        self._file.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


# ═══════════════════════════════════════════════════════════
# MEMORY SYSTEM (기존 유지 + 신규 연동)
# ═══════════════════════════════════════════════════════════

class MemorySystem:
    """
    v4.3.0: MoodContext + ProactiveAction 연동 추가.
    기존 API 완전 호환.
    """

    def __init__(self, memory_dir: str = None):
        if memory_dir is None:
            memory_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "memory")

        self.memory_dir      = Path(memory_dir)
        self.preferences_file = self.memory_dir / "preferences.json"
        self.learning_file    = self.memory_dir / "learning.json"
        self.session_file     = self.memory_dir / "session.json"
        self.untrusted_file   = self.memory_dir / "untrusted.json"
        self.mood_file        = self.memory_dir / "mood_context.json"     # 신규
        self.action_log_file  = self.memory_dir / "action_log.json"       # 신규

        self.untrusted_layer   = UntrustedLayer(self.untrusted_file)
        self.injection_detector = PromptInjectionDetector()

        # 신규 컴포넌트
        self.mood_context    = MoodContext(self.mood_file)
        self.proactive       = ProactiveAction(self.action_log_file)

        self._ensure_memory_structure()

    # ── 구조 초기화 ───────────────────────────────────────

    def _ensure_memory_structure(self):
        self.memory_dir.mkdir(exist_ok=True)

        if not self.preferences_file.exists():
            self._save_json(self.preferences_file, {
                "version": "4.3.0", "created_at": datetime.now().isoformat(),
                "user": {"name": "공장장", "role": "Factory Owner",
                         "timezone": "Asia/Seoul", "language": "ko",
                         "communication_style": "professional"},
                "ai": {"response_style": "proactive", "thinking_display": True,
                       "tone": "friendly-professional", "secretary_mode": True},
                "preferences": {"summary_length": "medium", "technical_depth": "moderate",
                                 "emoji_usage": True, "proactive_suggestions": True},
                "security": {"untrusted_layer_enabled": True,
                             "master_truth_enforcement": True, "auto_verify_claims": True},
                "soul": {"mood_tracking": True, "proactive_evening_checkin": True},  # 신규
            })
            print("✅ preferences.json 생성 (v4.3.0)")

        if not self.learning_file.exists():
            self._save_json(self.learning_file, {
                "version": "4.3.0", "created_at": datetime.now().isoformat(),
                "facts": [], "patterns": [], "insights": [], "habits": [],
                "verified_facts_count": 0, "rejected_facts_count": 0,
            })
            print("✅ learning.json 생성 (v4.3.0)")

        if not self.session_file.exists():
            self._reset_session_data()
            print("✅ session.json 생성 (v4.3.0)")

    # ── 기본 조회 (기존 API 유지) ─────────────────────────

    def get_preferences(self) -> Dict:
        return self._load_json(self.preferences_file)

    def get_learning(self) -> Dict:
        return self._load_json(self.learning_file)

    def get_session_context(self) -> Dict:
        return self._load_json(self.session_file)

    # ── 컨텍스트 프롬프트 빌드 ───────────────────────────

    def build_context_prompt(self) -> str:
        try:
            prefs   = self.get_preferences()
            learning = self.get_learning()
            session  = self.get_session_context()
        except Exception as e:
            print(f"[Memory] ⚠️ 데이터 로드 실패, 기본값 사용: {e}")
            prefs    = {"user": {"name": "공장장", "role": "Factory Owner",
                                  "language": "ko", "timezone": "Asia/Seoul",
                                  "communication_style": "professional"},
                        "ai": {"response_style": "proactive", "thinking_display": True},
                        "preferences": {}}
            learning = {"facts": [], "patterns": []}
            session  = {"session_id": "unknown", "message_count": 0, "learning_count": 0}

        user_info = prefs.get("user", {})
        recent_facts    = learning.get("facts", [])[-10:]
        recent_patterns = learning.get("patterns", [])[-5:]

        # 감정 컨텍스트 삽입
        today_mood  = self.mood_context.get_today_summary()
        mood_prompt = ""
        if today_mood["entry_count"] > 0:
            mood_prompt = (
                f"\n😶 오늘의 감정 컨텍스트: {today_mood['dominant_mood']} "
                f"({today_mood['entry_count']}회 감지)\n"
                f"→ 응답 시 공장장의 감정 상태를 고려하여 공감적으로 반응하세요.\n"
            )

        # 대기 트리거 확인
        pending = self.mood_context.get_pending_triggers()
        trigger_prompt = ""
        if pending:
            trigger_prompt = (
                f"\n🔔 저녁 트리거 활성: 오늘 {len(pending)}개의 힘든 순간이 기록됨. "
                f"현재 응답에 따뜻한 위로를 자연스럽게 포함하세요.\n"
            )

        context = f"""[KIVOSY v4.3.0 MEMORY SYSTEM]

👤 FACTORY OWNER:
이름: {user_info.get('name', '공장장')} ({user_info.get('role', 'Factory Owner')})
언어: {user_info.get('language', 'ko')} | 시간대: {user_info.get('timezone', 'Asia/Seoul')}
{mood_prompt}{trigger_prompt}
{MasterTruthTable.get_system_truths_prompt()}

🤖 YOUR ROLE:
당신은 공장장의 프로액티브 AI 비서 자비스입니다.
- 메모리를 항상 참조하고 개인화된 응답을 제공합니다.
- 감정 상태를 파악하고 공감적으로 반응합니다.
- 단순히 대화하는 것을 넘어 실제로 행동합니다 (음악, 노트 저장 등).
- 3단계 응답 형식을 반드시 준수합니다.

📚 축적 지식 ({len(learning.get('facts', []))}개):
"""
        for i, fact in enumerate(recent_facts, 1):
            content    = fact.get("content", "")[:80]
            confidence = fact.get("confidence", 0.5)
            is_valid, _ = MasterTruthTable.verify_claim(content)
            if not is_valid:
                content = f"🚨 [MASTER TRUTH 위반] {content}"
                confidence = 0.0
            emoji = "🟢" if confidence > 0.7 else "🟡" if confidence > 0.3 else "🔴"
            context += f"{i}. {emoji} {content} (확신도: {confidence:.1f})\n"

        if not recent_facts:
            context += "(아직 학습된 사실 없음 — 관찰 시작)\n"

        if recent_patterns:
            context += "\n🔍 관찰된 패턴:\n"
            for p in recent_patterns:
                context += f"- {p.get('content', '')}\n"

        context += f"""
📊 현재 세션:
세션 ID: {session.get('session_id', '')[:8]}
메시지: {session.get('message_count', 0)} | 학습: {session.get('learning_count', 0)}

🎯 필수 응답 형식 (3단계):

<think>
[내부 추론 — 사용자에게 비표시]
[감정 상태 확인: 오늘 힘든 일이 있었는가?]
[메모리 참조: 관련 사실/패턴이 있는가?]
[Master Truth 검증]
</think>

<summary>
[한 문장: 사용자 메시지 요약]
</summary>

<insight>
[메모리 기반 통찰 — 구체적 사실 참조]
[감정 상태가 있다면 공감 표현]
</insight>

<suggestion>
[프로액티브 제안 또는 실제 행동 결과]
[예: 음악 큐, 노트 저장 등]
</suggestion>
"""
        return context

    # ── 신규: 감정 기반 처리 ─────────────────────────────

    def process_mood_and_trigger(self, user_message: str) -> Optional[Dict]:
        """
        메시지에서 감정 감지 → 필요 시 프로액티브 액션 실행.
        액션이 실행된 경우 딕셔너리 반환, 아니면 None.
        """
        # 감정 기록
        mood_entry = self.mood_context.record_from_message(user_message)

        # 저녁 트리거 확인
        pending_triggers = self.mood_context.get_pending_triggers()
        if pending_triggers:
            trigger = pending_triggers[0]
            action  = self.proactive.on_evening_checkin(trigger)
            self.mood_context.mark_triggered(trigger["id"])
            print(f"[Memory] 🔔 저녁 트리거 발화: {trigger['id']}")
            return action

        return None

    # ── 학습 추출 (기존 유지) ────────────────────────────

    def extract_learnings(self, user_message: str, ai_response: str,
                          lm_studio_url: str) -> List[Dict]:
        learnings = []
        learnings.extend(self._extract_regex(user_message))
        try:
            learnings.extend(self._extract_llm_powered(user_message, lm_studio_url))
        except Exception as e:
            print(f"[Learning] ⚠️ LLM 추출 실패: {e}")

        verified = []
        for item in learnings:
            is_valid, correction = MasterTruthTable.verify_claim(item["content"])
            if is_valid:
                verified.append(item)
            else:
                self.untrusted_layer.reject_claim(item["content"], correction)
                session = self.get_session_context()
                session["security_alerts"] = session.get("security_alerts", 0) + 1
                self._save_json(self.session_file, session)
        return verified

    def _extract_regex(self, text: str) -> List[Dict]:
        learnings = []
        patterns = [
            (r'나는 (.+?)(?:을|를|이|가) 좋아', "preference", 0.7),
            (r'내 이름은 (.+?)(?:이다|입니다|야|이야)', "fact", 0.9),
            (r'나는 (.+?)(?:에서|에) (?:일하|근무)', "fact", 0.8),
            (r'매일|매주|항상 (.+?)(?:한다|해)', "habit", 0.7),
        ]
        for pattern, type_, conf in patterns:
            for m in re.finditer(pattern, text):
                learnings.append({
                    "type": type_, "content": f"공장장은 {m.group(1).strip()}",
                    "learned_at": datetime.now().isoformat(),
                    "source": "regex", "confidence": conf,
                })
        return learnings

    def _extract_llm_powered(self, user_message: str, lm_studio_url: str) -> List[Dict]:
        extraction_prompt = f"""사용자 메시지에서 학습할 정보를 JSON 배열로 추출하세요.

메시지: "{user_message}"

추출 대상: 선호사항, 사실, 습관, 목표, 개인 정보

형식:
[
  {{"type": "preference", "content": "공장장은 커피를 좋아함", "confidence": 0.9}}
]

학습 정보 없으면: []
JSON만 반환."""

        try:
            resp = requests.post(
                lm_studio_url,
                json={"messages": [{"role": "user", "content": extraction_prompt}],
                      "temperature": 0.3, "max_tokens": 800},
                timeout=15
            )
            if resp.ok:
                choices = resp.json().get("choices", [])
                raw = choices[0].get("message", {}).get("content", "[]") if choices else "[]"
                extracted = SafeParser.safe_json_extract(raw)
                if extracted:
                    return [
                        {"type": item.get("type", "fact"), "content": item["content"],
                         "learned_at": datetime.now().isoformat(),
                         "source": "llm", "confidence": float(item.get("confidence", 0.7))}
                        for item in extracted if isinstance(item, dict) and "content" in item
                    ]
        except requests.Timeout:
            print("[Learning LLM] ⏱️ 타임아웃")
        except Exception as e:
            print(f"[Learning LLM] ⚠️ 오류: {e}")
        return []

    def update_learning(self, new_learnings: List[Dict]):
        if not new_learnings:
            return
        data = self.get_learning()
        added = reinforced = rejected = 0

        for item in new_learnings:
            content = item["content"]
            is_valid, correction = MasterTruthTable.verify_claim(content)
            if not is_valid:
                self.untrusted_layer.reject_claim(content, correction)
                rejected += 1
                continue

            duplicate = False
            for existing in data["facts"]:
                if self._similarity(content, existing.get("content", "")) > 0.75:
                    duplicate = True
                    if item.get("confidence", 0) > existing.get("confidence", 0):
                        existing["confidence"] = item["confidence"]
                        existing["last_reinforced"] = datetime.now().isoformat()
                        reinforced += 1
                    break

            if not duplicate:
                data["facts"].append(item)
                added += 1

        if added or reinforced:
            data["verified_facts_count"] = data.get("verified_facts_count", 0) + added
            data["rejected_facts_count"] = data.get("rejected_facts_count", 0) + rejected
            self._save_json(self.learning_file, data)
            session = self.get_session_context()
            session["learning_count"] = session.get("learning_count", 0) + added
            self._save_json(self.session_file, session)
            print(f"[Learning] 📚 +{added}개 신규 | {reinforced}개 강화 | 🚫{rejected}개 거부")

    def _similarity(self, a: str, b: str) -> float:
        sa, sb = set(a.lower().split()), set(b.lower().split())
        if not sa or not sb:
            return 0.0
        return len(sa & sb) / len(sa | sb)

    def update_session(self):
        session = self.get_session_context()
        session["message_count"] = session.get("message_count", 0) + 1
        self._save_json(self.session_file, session)

    def reset_session(self):
        self._reset_session_data()
        print(f"[Memory] 🔄 세션 리셋")

    def _reset_session_data(self):
        self._save_json(self.session_file, {
            "session_id": str(uuid.uuid4()),
            "started_at": datetime.now().isoformat(),
            "message_count": 0, "context": [],
            "learning_count": 0, "security_alerts": 0,
        })

    def _save_json(self, path: Path, data: Dict):
        try:
            path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as e:
            print(f"[Memory] ⚠️ 저장 실패 {path}: {e}")

    def _load_json(self, path: Path) -> Dict:
        try:
            if path.exists():
                return json.loads(path.read_text(encoding="utf-8"))
        except Exception as e:
            print(f"[Memory] ⚠️ 로드 실패 {path}: {e}")
        return {}


# ═══════════════════════════════════════════════════════════
# SOUL ENGINE (기존 유지)
# ═══════════════════════════════════════════════════════════

class SoulEngine:
    def __init__(self, memory_system: MemorySystem):
        self.memory = memory_system

    def get_mood_score(self) -> Dict[str, float]:
        session  = self.memory.get_session_context()
        learning = self.memory.get_learning()
        mood = {"energy": 0.5, "stress": 0.5, "focus": 0.5, "social": 0.5}
        try:
            msg_count  = session.get("message_count", 0)
            learn_count = session.get("learning_count", 0)
            if msg_count > 10:
                mood["energy"] = min(0.5 + msg_count / 100, 1.0)
            if learn_count > 5:
                mood["focus"] = min(0.5 + learn_count / 20, 1.0)

            # MoodContext 반영 (신규)
            today = self.memory.mood_context.get_today_summary()
            dominant = today.get("dominant_mood", "neutral")
            if dominant in ("stressed", "tired"):
                mood["stress"] = min(mood["stress"] + 0.3, 1.0)
            elif dominant == "happy":
                mood["energy"] = min(mood["energy"] + 0.2, 1.0)

            for fact in learning.get("facts", [])[-10:]:
                c = fact.get("content", "").lower()
                if any(kw in c for kw in ["피곤", "바쁨", "힘듦", "스트레스"]):
                    mood["stress"] = min(mood["stress"] + 0.1, 1.0)
                if any(kw in c for kw in ["활발", "열정", "에너지"]):
                    mood["energy"] = min(mood["energy"] + 0.1, 1.0)
        except Exception as e:
            print(f"[SoulEngine] ⚠️ 무드 계산 오류: {e}")
        return mood

    def get_weather_keywords(self) -> List[str]:
        mood = self.get_mood_score()
        kws = []
        if mood["energy"] > 0.7:   kws.append("sunny")
        elif mood["energy"] < 0.3: kws.append("cloudy")
        if mood["stress"] > 0.7:   kws.append("stormy")
        elif mood["stress"] < 0.3: kws.append("calm")
        if mood["focus"] > 0.7:    kws.append("clear")
        return kws or ["neutral"]

    def get_anonymized_export(self) -> Dict:
        return {
            "mood_scores":       self.get_mood_score(),
            "weather_keywords":  self.get_weather_keywords(),
            "timestamp":         datetime.now().isoformat(),
            "version":           "1.0",
        }


# ═══════════════════════════════════════════════════════════
# EXPORTS
# ═══════════════════════════════════════════════════════════

__all__ = [
    "MemorySystem",
    "SoulEngine",
    "UntrustedLayer",
    "MoodContext",
    "ProactiveAction",
]
