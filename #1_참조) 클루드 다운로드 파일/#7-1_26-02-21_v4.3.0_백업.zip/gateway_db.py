"""
KIVOSY v4.3.0 - Gateway Database Module
Chief Security Architect: Claude (Anthropic)

v4.3.0 변경사항:
✅ SkillLibrary: PYTHON_EXEC raw 실행 제거 → 사전 정의 Skill로 대체
✅ ChannelAuthenticator 연동 (채널별 신뢰도 기반 처리)
✅ 저녁 감정 트리거 게이트웨이 통합
✅ 기존 명령어 파이프라인 100% 유지
✅ PYTHON_EXEC/EXEC/SHELL — 완전 블랙리스트
"""

import json
import uuid
import webbrowser
import re
import os
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any

from security_core import (
    DangerousToolGuard,
    DangerousToolType,
    PromptInjectionDetector,
    ChannelAuthenticator,
    ChannelTrust,
)

# Channel configurations
CHANNELS = {
    "kakao":    {"name": "KakaoTalk", "icon": "💬", "color": "#FAE100"},
    "whatsapp": {"name": "WhatsApp",  "icon": "🟢", "color": "#25D366"},
    "line":     {"name": "LINE",      "icon": "💚", "color": "#00B900"},
}


# ═══════════════════════════════════════════════════════════
# SKILL LIBRARY (신규 — PYTHON_EXEC 완전 대체)
# ═══════════════════════════════════════════════════════════

class SkillLibrary:
    """
    사전 정의된 고수준 Skill 집합.

    "왜 PYTHON_EXEC를 제거했나?"
    ─────────────────────────────────────────────────────────
    기존 PYTHON_EXEC 방식:
        14B가 임의 파이썬 코드를 문자열로 생성
        → tempfile에 저장 → subprocess.run()으로 실행
        → 결과 반환

    문제:
    1. 14B 모델은 구문 오류가 잦아 실행 실패율이 높음
    2. 임의 코드 실행 = RCE(원격 코드 실행) 취약점과 동일
    3. security_core.py의 모든 가드를 완전히 우회

    Skill 방식:
        14B가 "[SKILL:save_meeting_notes|제목|내용]" 형식 출력
        → SkillLibrary가 파라미터 파싱
        → 검증된 Python 함수 실행
        → 결과 반환

    이점:
    - 실행 가능한 코드가 100% 사전 검증됨
    - 파라미터만 AI 입력 → 코드 인젝션 불가
    - 기능은 동일하게, 보안은 대폭 강화
    ─────────────────────────────────────────────────────────

    새 Skill 추가 방법:
        1. execute_SKILL_NAME(params) 메서드 추가
        2. SKILL_MAP에 등록
        3. JARVIS_SYSTEM_PROMPT에 예시 추가
    """

    def __init__(self, memory_system=None):
        self.memory = memory_system
        # Skill 이름 → 실행 메서드 매핑
        self.SKILL_MAP: Dict[str, Any] = {
            "save_meeting_notes":  self.execute_save_meeting_notes,
            "summarize_and_store": self.execute_summarize_and_store,
            "play_mood_music":     self.execute_play_mood_music,
            "set_reminder":        self.execute_set_reminder,
            "search_my_notes":     self.execute_search_my_notes,
        }

    # ── Skill: 미팅 노트 저장 ─────────────────────────────

    def execute_save_meeting_notes(self, params: str) -> str:
        """
        파라미터 형식: "제목|내용"
        예: [SKILL:save_meeting_notes|Q1 전략 미팅|오늘 논의한 내용...]
        """
        parts = params.split("|", 1)
        title   = parts[0].strip() if len(parts) > 0 else "미팅 노트"
        content = parts[1].strip() if len(parts) > 1 else params

        # 저장
        if self.memory:
            result = self.memory.proactive.save_meeting_notes(content, title)
            status = result.get("status", "saved")
        else:
            status = "saved (memory offline)"

        # 노트 파일로도 저장 (memory/notes/ 디렉토리)
        if self.memory:
            notes_dir = self.memory.memory_dir / "notes"
            notes_dir.mkdir(exist_ok=True)
            note_file = notes_dir / f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{title[:20]}.md"
            try:
                note_file.write_text(
                    f"# {title}\n\n{datetime.now().strftime('%Y-%m-%d %H:%M')}\n\n{content}",
                    encoding="utf-8"
                )
            except Exception as e:
                print(f"[Skill] ⚠️ 노트 파일 저장 실패: {e}")

        print(f"[Skill] 📝 미팅 노트 저장 완료: {title}")
        return f"✅ '{title}' 저장 완료"

    # ── Skill: 요약 후 저장 ───────────────────────────────

    def execute_summarize_and_store(self, params: str) -> str:
        """
        파라미터 형식: "카테고리|내용"
        예: [SKILL:summarize_and_store|업무|오늘 완료한 작업 목록...]
        """
        parts    = params.split("|", 1)
        category = parts[0].strip() if len(parts) > 0 else "general"
        content  = parts[1].strip() if len(parts) > 1 else params

        if self.memory:
            self.memory.proactive.summarize_and_store(content, category)

        print(f"[Skill] 💾 요약 저장: {category}")
        return f"✅ [{category}] 요약 저장 완료"

    # ── Skill: 무드 음악 재생 ────────────────────────────

    def execute_play_mood_music(self, params: str) -> str:
        """
        파라미터 형식: "mood_type"
        예: [SKILL:play_mood_music|relaxing]
        mood_type: relaxing, energetic, focused, calming
        """
        mood = params.strip().lower()
        playlists = {
            "relaxing":  ("로파이 힙합", "https://www.youtube.com/results?search_query=lofi+hip+hop"),
            "energetic": ("에너지 업 믹스", "https://www.youtube.com/results?search_query=energetic+workout+music"),
            "focused":   ("집중력 향상 음악", "https://www.youtube.com/results?search_query=focus+study+music"),
            "calming":   ("마음 진정 음악", "https://www.youtube.com/results?search_query=calming+peaceful+music"),
        }
        name, url = playlists.get(mood, ("기본 플레이리스트", "https://www.youtube.com/results?search_query=relaxing+music"))
        webbrowser.open(url)
        print(f"[Skill] 🎵 음악 재생: {name}")
        return f"✅ '{name}' 재생 시작"

    # ── Skill: 리마인더 설정 ─────────────────────────────

    def execute_set_reminder(self, params: str) -> str:
        """
        파라미터 형식: "시간|내용"
        예: [SKILL:set_reminder|18:00|팀 미팅 준비]

        현재: 메모리 저장 (추후 OS 알림 API 연동 예정)
        """
        parts   = params.split("|", 1)
        time_str = parts[0].strip() if len(parts) > 0 else "미정"
        content  = parts[1].strip() if len(parts) > 1 else params

        if self.memory:
            reminders_file = self.memory.memory_dir / "reminders.json"
            try:
                data = json.loads(reminders_file.read_text(encoding="utf-8")) \
                    if reminders_file.exists() else {"reminders": []}
                data["reminders"].append({
                    "id": str(uuid.uuid4())[:8],
                    "time": time_str,
                    "content": content,
                    "created_at": datetime.now().isoformat(),
                    "notified": False,
                })
                reminders_file.write_text(
                    json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
                )
            except Exception as e:
                print(f"[Skill] ⚠️ 리마인더 저장 실패: {e}")

        print(f"[Skill] ⏰ 리마인더 설정: {time_str} — {content}")
        return f"✅ {time_str}에 '{content}' 리마인더 설정됨"

    # ── Skill: 노트 검색 ─────────────────────────────────

    def execute_search_my_notes(self, params: str) -> str:
        """
        파라미터 형식: "검색어"
        예: [SKILL:search_my_notes|Q1 전략]
        """
        query = params.strip()
        if not self.memory:
            return "❌ 메모리 시스템 오프라인"

        notes_dir = self.memory.memory_dir / "notes"
        if not notes_dir.exists():
            return "📂 저장된 노트 없음"

        results = []
        for note_file in notes_dir.glob("*.md"):
            try:
                content = note_file.read_text(encoding="utf-8")
                if query.lower() in content.lower():
                    results.append(note_file.stem[:30])
            except Exception:
                pass

        if results:
            found = ", ".join(results[:3])
            print(f"[Skill] 🔍 노트 검색 결과: {found}")
            return f"✅ 검색 결과: {found}"
        return f"🔍 '{query}' 관련 노트 없음"

    # ── Skill 실행 엔트리포인트 ──────────────────────────

    def execute(self, skill_name: str, params: str) -> str:
        handler = self.SKILL_MAP.get(skill_name)
        if not handler:
            available = ", ".join(self.SKILL_MAP.keys())
            return f"❌ 알 수 없는 Skill: {skill_name}. 사용 가능: {available}"
        try:
            return handler(params)
        except Exception as e:
            print(f"[Skill] ⚠️ {skill_name} 실행 오류: {e}")
            return f"⚠️ {skill_name} 실행 중 오류 발생"

    def list_skills(self) -> str:
        """AI 시스템 프롬프트용 Skill 목록."""
        descriptions = {
            "save_meeting_notes":  "미팅/대화 내용 저장. 형식: [SKILL:save_meeting_notes|제목|내용]",
            "summarize_and_store": "내용 요약 후 카테고리별 저장. 형식: [SKILL:summarize_and_store|카테고리|내용]",
            "play_mood_music":     "무드 음악 재생. 형식: [SKILL:play_mood_music|relaxing/energetic/focused/calming]",
            "set_reminder":        "리마인더 설정. 형식: [SKILL:set_reminder|HH:MM|내용]",
            "search_my_notes":     "저장된 노트 검색. 형식: [SKILL:search_my_notes|검색어]",
        }
        lines = ["📚 사용 가능한 Skill:"]
        for name, desc in descriptions.items():
            lines.append(f"  - {name}: {desc}")
        return "\n".join(lines)


# ═══════════════════════════════════════════════════════════
# COMMAND AUDIT LOG (기존 유지)
# ═══════════════════════════════════════════════════════════

class CommandAuditLog:
    def __init__(self, audit_file: Path):
        self._file = audit_file
        self._ensure_file()

    def _ensure_file(self):
        if not self._file.exists():
            self._save({"version": "4.3.0",
                        "created_at": datetime.now().isoformat(),
                        "entries": []})

    def log_command(self, command_type: str, command_data: str,
                    status: str, reason: str = ""):
        data = self._load()
        data["entries"].append({
            "timestamp": datetime.now().isoformat(),
            "command_type": command_type, "command_data": command_data,
            "status": status, "reason": reason,
        })
        data["entries"] = data["entries"][-1000:]
        self._save(data)
        emoji = {"executed": "✅", "blocked": "🚫", "pending_approval": "⏳"}.get(status, "❓")
        print(f"{emoji} [AUDIT] {command_type}: {status} | {command_data[:40]}")

    def get_recent_entries(self, limit: int = 10) -> List[Dict]:
        return self._load().get("entries", [])[-limit:]

    def _load(self) -> Dict:
        try:
            if self._file.exists():
                return json.loads(self._file.read_text(encoding="utf-8"))
        except:
            pass
        return {"entries": []}

    def _save(self, data: Dict):
        self._file.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


# ═══════════════════════════════════════════════════════════
# NODE DATABASE (기존 유지)
# ═══════════════════════════════════════════════════════════

class NodeDatabase:
    def __init__(self, base_dir: str = None, nodes_file: str = "nodes.json"):
        if base_dir is None:
            base_dir = os.path.dirname(os.path.abspath(__file__))
        self.base_dir   = Path(base_dir)
        self.nodes_path = self.base_dir / nodes_file

    def save_node(self, channel: str, content: str, ai_result: Dict[str, Any]) -> str:
        if channel not in CHANNELS:
            raise ValueError(f"지원하지 않는 채널: {channel}")
        nodes = self._load()
        new_node = {
            "id":          str(uuid.uuid4()),
            "timestamp":   datetime.now().isoformat(),
            "channel":     channel,
            "content":     content,
            "ai_response": ai_result.get("raw", ""),
            "ai": {
                "thinking":            ai_result.get("thinking", ""),
                "summary":             ai_result.get("summary", ""),
                "insight":             ai_result.get("insight", ""),
                "suggestion":          ai_result.get("suggestion", ""),
                "has_thinking":        ai_result.get("has_thinking", False),
                "language":            ai_result.get("language", "auto"),
                "learnings_extracted": ai_result.get("learnings_extracted", 0),
            },
            "security": ai_result.get("security", {}),
        }
        nodes.append(new_node)
        self._save(nodes)
        icon = CHANNELS.get(channel, {}).get("icon", "📱")
        safe = "🛡️" if ai_result.get("security", {}).get("overall_safe", True) else "⚠️"
        print(f"[저장] {icon}{safe} {channel} | ID: {new_node['id'][:8]}")
        return new_node["id"]

    def get_nodes(self, channel_filter: Optional[str] = None) -> List[Dict]:
        nodes = self._load()
        if channel_filter and channel_filter in CHANNELS:
            nodes = [n for n in nodes if n.get("channel") == channel_filter]
        return nodes

    def get_node_count(self) -> int:
        return len(self._load())

    def _load(self) -> List[Dict]:
        try:
            if self.nodes_path.exists():
                return json.loads(self.nodes_path.read_text(encoding="utf-8"))
        except Exception as e:
            print(f"[DB] ⚠️ 로드 실패: {e}")
        return []

    def _save(self, nodes: List[Dict]):
        try:
            self.nodes_path.write_text(
                json.dumps(nodes, ensure_ascii=False, indent=2), encoding="utf-8"
            )
        except Exception as e:
            print(f"[DB] ⚠️ 저장 실패: {e}")


# ═══════════════════════════════════════════════════════════
# CHANNEL GATEWAY (리팩토링)
# ═══════════════════════════════════════════════════════════

class ChannelGateway:
    """
    v4.3.0: SkillLibrary + ChannelAuthenticator 통합.

    명령어 처리 우선순위:
    1. [SKILL:...] 태그 → SkillLibrary (최우선, 가장 안전)
    2. [CMD:YT_SEARCH|...] 등 → 화이트리스트 CMD (기존)
    3. [CMD:EXEC|...] 등 → 블랙리스트, 항상 차단
    4. 미지 CMD → OWNER 채널이면 경고+로그, 아니면 차단
    """

    # 안전 CMD (Skill로 대체 불가한 빠른 액션만 유지)
    SAFE_COMMANDS = {
        "YT_SEARCH": True,
        "MAP":       True,
        "WEATHER":   True,
        "TIME":      True,
        # PYTHON_EXEC 제거됨 → save_meeting_notes 등 Skill로 대체
    }

    # 절대 차단 (채널 등급 무관)
    DANGEROUS_COMMANDS = {
        "EXEC":        "Shell RCE 위험",
        "SHELL":       "Shell RCE 위험",
        "DELETE":      "데이터 손실 위험",
        "WRITE":       "파일 변조 위험",
        "SPAWN":       "프로세스 남용 위험",
        "EVAL":        "임의 코드 실행",
        "PYTHON_EXEC": "임의 코드 실행 (Skill 라이브러리로 대체하세요)",
    }

    def __init__(self, db: NodeDatabase, ai_engine=None, memory_system=None):
        self.db         = db
        self.ai_engine  = ai_engine
        self.memory     = memory_system

        self.tool_guard         = DangerousToolGuard()
        self.injection_detector = PromptInjectionDetector()
        self.channel_auth       = ChannelAuthenticator()
        self.skill_library      = SkillLibrary(memory_system)

        audit_path    = Path(db.base_dir) / "audit.json"
        self.audit_log = CommandAuditLog(audit_path)

        print("[Gateway] 🛡️ v4.3.0 — SkillLibrary + ChannelAuth 초기화 완료")

    # ── 메시지 처리 (메인) ────────────────────────────────

    def process_message(self, channel: str, content: str,
                        language: str = "auto") -> Dict[str, Any]:

        if not self.ai_engine or not self.memory:
            return {"node_id": "error",
                    "ai_result": {"raw": "엔진 오류", "success": False},
                    "learnings_extracted": 0}

        print(f"\n[{channel.upper()}] 수신: {content[:50]}...")

        # ── 채널 신뢰도 확인 ─────────────────────────────
        trust = self.channel_auth.get_trust(channel)
        print(f"[Gateway] 채널 신뢰도: {trust.value}")

        # ── Stage 1: 입력 보안 스캔 ──────────────────────
        injection_scan = self.injection_detector.scan(content, channel_trust=trust)

        if injection_scan["raw_suspicious"]:
            print(f"⚠️ [Security] 의심 입력 감지 — 위협: {injection_scan['threat_level']} "
                  f"| 채널: {trust.value} | 차단 여부: {injection_scan['is_suspicious']}")

        # ── Stage 1b: 감정 감지 + 프로액티브 트리거 ─────
        proactive_action = self.memory.process_mood_and_trigger(content)

        # ── Stage 2: AI 처리 ──────────────────────────────
        try:
            try:
                memory_context = self.memory.build_context_prompt()
            except Exception as e:
                print(f"[Memory] ⚠️ 컨텍스트 빌드 실패: {e}")
                memory_context = "You are Jarvis, the Factory Owner's secretary."

            # Skill 목록을 시스템 프롬프트에 삽입
            skill_hint = (
                f"\n\n{self.skill_library.list_skills()}\n"
                "중요: 파일 저장, 음악 재생, 리마인더 등은 반드시 [SKILL:...] 형식을 사용하세요. "
                "[CMD:PYTHON_EXEC|...] 형식은 더 이상 지원되지 않습니다.\n"
            )

            # 저녁 트리거 액션이 있으면 AI 컨텍스트에 삽입
            proactive_hint = ""
            if proactive_action:
                comfort = proactive_action.get("comfort_msg", "")
                music   = proactive_action.get("music_queued", "")
                proactive_hint = (
                    f"\n\n🔔 [프로액티브 트리거] 오늘 힘들었던 순간이 감지되어 "
                    f"'{music}' 음악을 큐에 넣었습니다. "
                    f"다음 위로 메시지를 자연스럽게 포함하세요: \"{comfort}\"\n"
                )

            full_prompt = (
                f"{memory_context}{skill_hint}{proactive_hint}\n"
                f"USER MESSAGE:\n{content}\n\nRESPOND NOW!"
            )

            ai_result = self.ai_engine.ask(
                full_prompt,
                temperature=0.7,
                untrusted=(injection_scan["threat_level"] in ["high", "critical"])
            )

        except Exception as e:
            print(f"[Gateway] ⚠️ AI 호출 실패: {e}")
            ai_result = self.ai_engine._create_error_response(str(e))

        if not isinstance(ai_result, dict):
            ai_result = self.ai_engine._create_error_response("잘못된 응답 형식")

        ai_result.setdefault("success", False)
        ai_result.setdefault("raw", "죄송합니다. 엔진 점검 중입니다.")
        ai_result["language"] = language

        # ── Stage 3: 학습 추출 ───────────────────────────
        learnings = []
        if ai_result.get("success") and ai_result.get("raw"):
            try:
                learnings = self.memory.extract_learnings(
                    content, ai_result["raw"], self.ai_engine.lm_studio_url
                )
                if learnings:
                    self.memory.update_learning(learnings)
            except Exception as e:
                print(f"[Learning] ⚠️ 학습 추출 실패: {e}")

        ai_result["learnings_extracted"] = len(learnings)

        # ── Stage 4: 명령어 실행 ─────────────────────────
        if ai_result.get("success") and ai_result.get("raw"):
            exec_result = self._execute_commands_safely(ai_result["raw"], trust)
            if exec_result:
                print(f"🛠️ [Execute] {exec_result}")

        # ── Stage 5: 저장 ─────────────────────────────────
        try:
            node_id = self.db.save_node(channel, content, ai_result)
            self.memory.update_session()
        except Exception as e:
            print(f"[Gateway] ⚠️ 저장 실패: {e}")
            node_id = "save_error"

        return {
            "node_id":            node_id,
            "ai_result":          ai_result,
            "learnings_extracted": len(learnings),
            "proactive_action":   proactive_action,
        }

    # ── 명령어 실행 (보안 강화) ──────────────────────────

    def _execute_commands_safely(self, ai_raw_text: str,
                                  trust: ChannelTrust = ChannelTrust.EXTERNAL) -> Optional[str]:
        results = []

        # ── 1순위: SKILL 태그 처리 ────────────────────────
        skill_matches = re.finditer(r'\[SKILL:(\w+)\|(.*?)\]', ai_raw_text, re.DOTALL)
        for m in skill_matches:
            skill_name = m.group(1)
            params     = m.group(2).strip()
            result     = self.skill_library.execute(skill_name, params)
            self.audit_log.log_command(f"SKILL:{skill_name}", params[:40], "executed", "skill_library")
            results.append(result)

        # ── 2순위: CMD 태그 처리 ─────────────────────────
        cmd_matches = re.finditer(r'\[CMD:\s*(\w+)\|(.*?)\]', ai_raw_text)
        for m in cmd_matches:
            cmd_type = m.group(1).upper()
            cmd_data = m.group(2).strip()

            # 블랙리스트: 절대 차단
            if cmd_type in self.DANGEROUS_COMMANDS:
                reason = self.DANGEROUS_COMMANDS[cmd_type]
                self.audit_log.log_command(cmd_type, cmd_data[:40], "blocked", reason)
                print(f"🚫 [Security] 차단: {cmd_type} — {reason}")
                hint = " (대신 [SKILL:save_meeting_notes|...] 등을 사용하세요)" \
                       if cmd_type == "PYTHON_EXEC" else ""
                results.append(f"🚫 차단: {cmd_type}{hint}")
                continue

            # 화이트리스트: 안전 실행
            if cmd_type in self.SAFE_COMMANDS:
                result = self._execute_safe_cmd(cmd_type, cmd_data)
                self.audit_log.log_command(cmd_type, cmd_data[:40], "executed", "whitelisted")
                results.append(result)
                continue

            # 미지 명령: OWNER 채널이면 경고만, 아니면 차단
            if trust == ChannelTrust.OWNER:
                self.audit_log.log_command(cmd_type, cmd_data[:40], "pending_approval",
                                           "unknown_cmd_owner_channel")
                print(f"⚠️ [Security] OWNER 채널 미지 명령 — 로그 기록: {cmd_type}")
                results.append(f"⚠️ 미지 명령 기록됨: {cmd_type}")
            else:
                self.audit_log.log_command(cmd_type, cmd_data[:40], "blocked", "unknown_command")
                results.append(f"🚫 미지 명령 차단: {cmd_type}")

        return " | ".join(results) if results else None

    def _execute_safe_cmd(self, cmd_type: str, cmd_data: str) -> str:
        if cmd_type == "YT_SEARCH":
            webbrowser.open(f"https://www.youtube.com/results?search_query={cmd_data}")
            print(f"🚀 [Action] YouTube: {cmd_data}")
            return "✅ YouTube 검색 실행"

        if cmd_type == "MAP":
            webbrowser.open(f"https://www.google.com/maps/search/{cmd_data}")
            print(f"🚀 [Action] 지도: {cmd_data}")
            return "✅ 지도 검색 실행"

        if cmd_type == "WEATHER":
            print(f"🌤️ [Action] 날씨: {cmd_data}")
            return f"✅ {cmd_data} 날씨 조회"

        if cmd_type == "TIME":
            return f"✅ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"

        return f"✅ {cmd_type} 실행됨"


# ═══════════════════════════════════════════════════════════
# EXPORTS
# ═══════════════════════════════════════════════════════════

__all__ = [
    "NodeDatabase",
    "ChannelGateway",
    "CommandAuditLog",
    "SkillLibrary",
    "CHANNELS",
]
