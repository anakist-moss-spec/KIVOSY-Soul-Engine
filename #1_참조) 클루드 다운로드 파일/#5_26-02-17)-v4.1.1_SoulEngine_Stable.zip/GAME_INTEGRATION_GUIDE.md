# SOUL ENGINE - GAME DEVELOPER INTEGRATION GUIDE
**API Version:** 1.0  
**Last Updated:** 2025-01-31

---

## 🎮 QUICK START

### Step 1: Test the API

```bash
# Test if Soul Engine is running
curl http://localhost:5000/api/v1/game/vibe

# Expected response:
{
  "status": "success",
  "data": {
    "mood_scores": {
      "energy": 0.7,
      "stress": 0.3,
      "focus": 0.8,
      "social": 0.6
    },
    "weather_keywords": ["sunny", "calm"],
    "timestamp": "2025-01-31T10:00:00Z",
    "version": "1.0"
  }
}
```

---

## 🛠️ INTEGRATION EXAMPLES

### Unity (C#)

```csharp
using UnityEngine;
using System.Collections;
using UnityEngine.Networking;
using System;

[Serializable]
public class MoodScores
{
    public float energy;
    public float stress;
    public float focus;
    public float social;
}

[Serializable]
public class SoulEngineData
{
    public MoodScores mood_scores;
    public string[] weather_keywords;
    public string timestamp;
    public string version;
}

[Serializable]
public class SoulEngineResponse
{
    public string status;
    public SoulEngineData data;
}

public class SoulEngineClient : MonoBehaviour
{
    private const string API_URL = "http://localhost:5000/api/v1/game/vibe";
    
    // Fetch mood data every 60 seconds
    void Start()
    {
        InvokeRepeating("FetchMoodData", 0f, 60f);
    }
    
    void FetchMoodData()
    {
        StartCoroutine(GetMoodCoroutine());
    }
    
    IEnumerator GetMoodCoroutine()
    {
        using (UnityWebRequest request = UnityWebRequest.Get(API_URL))
        {
            yield return request.SendWebRequest();
            
            if (request.result == UnityWebRequest.Result.Success)
            {
                SoulEngineResponse response = JsonUtility.FromJson<SoulEngineResponse>(request.downloadHandler.text);
                
                if (response.status == "success")
                {
                    ApplyMoodToGame(response.data);
                }
            }
            else
            {
                Debug.LogWarning("Soul Engine request failed: " + request.error);
            }
        }
    }
    
    void ApplyMoodToGame(SoulEngineData data)
    {
        // Example: Adjust lighting based on energy
        if (data.mood_scores.energy > 0.7f)
        {
            RenderSettings.ambientLight = Color.yellow; // Bright
        }
        else if (data.mood_scores.energy < 0.3f)
        {
            RenderSettings.ambientLight = Color.gray; // Dim
        }
        
        // Example: Adjust music based on stress
        if (data.mood_scores.stress > 0.7f)
        {
            AudioManager.Instance.PlayTenseMusicTrack();
        }
        else
        {
            AudioManager.Instance.PlayCalmMusicTrack();
        }
        
        // Example: Weather effects
        foreach (string keyword in data.weather_keywords)
        {
            switch (keyword)
            {
                case "sunny":
                    WeatherSystem.SetWeather(Weather.Sunny);
                    break;
                case "stormy":
                    WeatherSystem.SetWeather(Weather.Stormy);
                    break;
                case "calm":
                    WeatherSystem.SetWind(0.1f);
                    break;
            }
        }
        
        Debug.Log($"Soul Engine applied: Energy={data.mood_scores.energy}, Stress={data.mood_scores.stress}");
    }
}
```

---

### JavaScript (Web Game)

```javascript
// Soul Engine Client for Web Games
class SoulEngineClient {
    constructor(apiUrl = 'http://localhost:5000/api/v1/game/vibe') {
        this.apiUrl = apiUrl;
        this.currentMood = null;
        this.updateInterval = 60000; // 60 seconds
    }
    
    // Start automatic polling
    start() {
        this.fetchMood();
        setInterval(() => this.fetchMood(), this.updateInterval);
    }
    
    // Fetch mood data from Soul Engine
    async fetchMood() {
        try {
            const response = await fetch(this.apiUrl);
            const json = await response.json();
            
            if (json.status === 'success') {
                this.currentMood = json.data;
                this.onMoodUpdate(this.currentMood);
            }
        } catch (error) {
            console.warn('Soul Engine fetch failed:', error);
        }
    }
    
    // Override this method to apply mood to your game
    onMoodUpdate(moodData) {
        console.log('Mood updated:', moodData);
        
        // Example: Apply mood to game visuals
        const { energy, stress, focus, social } = moodData.mood_scores;
        
        // Adjust game lighting
        if (energy > 0.7) {
            document.body.style.filter = 'brightness(1.2)';
        } else if (energy < 0.3) {
            document.body.style.filter = 'brightness(0.8)';
        }
        
        // Adjust UI theme
        if (stress > 0.7) {
            document.body.classList.add('stressed-theme');
        } else {
            document.body.classList.remove('stressed-theme');
        }
        
        // Weather keywords
        const weather = moodData.weather_keywords[0] || 'neutral';
        this.applyWeather(weather);
    }
    
    applyWeather(keyword) {
        const weatherEffects = {
            'sunny': () => this.showSunnyEffect(),
            'stormy': () => this.showStormyEffect(),
            'calm': () => this.showCalmEffect(),
            'clear': () => this.showClearEffect(),
            'cloudy': () => this.showCloudyEffect()
        };
        
        if (weatherEffects[keyword]) {
            weatherEffects[keyword]();
        }
    }
    
    showSunnyEffect() {
        // Implement sunny visual effect
        console.log('☀️ Sunny weather applied');
    }
    
    showStormyEffect() {
        // Implement stormy visual effect
        console.log('⛈️ Stormy weather applied');
    }
    
    showCalmEffect() {
        // Implement calm visual effect
        console.log('😌 Calm atmosphere applied');
    }
    
    showClearEffect() {
        // Implement clear visual effect
        console.log('✨ Clear sky applied');
    }
    
    showCloudyEffect() {
        // Implement cloudy visual effect
        console.log('☁️ Cloudy weather applied');
    }
}

// Usage
const soulEngine = new SoulEngineClient();
soulEngine.start();
```

---

### Python (Backend Game Server)

```python
import requests
import time
from typing import Dict, List, Optional

class SoulEngineClient:
    """Python client for Soul Engine API"""
    
    def __init__(self, api_url: str = "http://localhost:5000/api/v1/game/vibe"):
        self.api_url = api_url
        self.current_mood: Optional[Dict] = None
    
    def fetch_mood(self) -> Optional[Dict]:
        """Fetch current mood data from Soul Engine"""
        try:
            response = requests.get(self.api_url, timeout=5)
            
            if response.status_code == 200:
                data = response.json()
                if data.get('status') == 'success':
                    self.current_mood = data['data']
                    return self.current_mood
        
        except requests.RequestException as e:
            print(f"Soul Engine fetch failed: {e}")
        
        return None
    
    def get_mood_scores(self) -> Dict[str, float]:
        """Get mood scores (energy, stress, focus, social)"""
        if self.current_mood:
            return self.current_mood.get('mood_scores', {})
        return {}
    
    def get_weather_keywords(self) -> List[str]:
        """Get weather keywords for environment effects"""
        if self.current_mood:
            return self.current_mood.get('weather_keywords', [])
        return []
    
    def is_player_stressed(self) -> bool:
        """Check if player is currently stressed"""
        scores = self.get_mood_scores()
        return scores.get('stress', 0.5) > 0.7
    
    def is_player_energetic(self) -> bool:
        """Check if player is currently energetic"""
        scores = self.get_mood_scores()
        return scores.get('energy', 0.5) > 0.7
    
    def get_recommended_difficulty(self) -> str:
        """Recommend game difficulty based on mood"""
        scores = self.get_mood_scores()
        
        energy = scores.get('energy', 0.5)
        focus = scores.get('focus', 0.5)
        stress = scores.get('stress', 0.5)
        
        # High energy + high focus + low stress = challenge player
        if energy > 0.7 and focus > 0.7 and stress < 0.3:
            return "hard"
        
        # High stress = make it easier
        elif stress > 0.7:
            return "easy"
        
        else:
            return "normal"

# Example usage
if __name__ == "__main__":
    client = SoulEngineClient()
    
    while True:
        mood = client.fetch_mood()
        
        if mood:
            print(f"Energy: {mood['mood_scores']['energy']:.2f}")
            print(f"Stress: {mood['mood_scores']['stress']:.2f}")
            print(f"Weather: {', '.join(mood['weather_keywords'])}")
            print(f"Recommended difficulty: {client.get_recommended_difficulty()}")
            print("---")
        
        time.sleep(60)  # Poll every 60 seconds
```

---

## 🎨 CREATIVE USE CASES

### 1. Dynamic Tarot Card Reading

```javascript
// Tarot game example
function selectTarotCards(moodData) {
    const { energy, stress, focus } = moodData.mood_scores;
    
    // Select cards based on player's mood
    if (stress > 0.7) {
        // Draw calming, healing cards
        return ['The Star', 'Temperance', 'Four of Swords'];
    } else if (energy > 0.8 && focus > 0.8) {
        // Draw powerful, transformative cards
        return ['The Magician', 'The Sun', 'Ace of Wands'];
    } else {
        // Draw balanced, neutral cards
        return shuffleCards(tarotDeck);
    }
}
```

### 2. Open-World Weather System

```csharp
// Unity weather system example
void UpdateGameWeather(SoulEngineData data)
{
    WeatherType weather = WeatherType.Neutral;
    
    // Map mood to weather
    if (data.weather_keywords.Contains("sunny"))
    {
        weather = WeatherType.Sunny;
    }
    else if (data.weather_keywords.Contains("stormy"))
    {
        weather = WeatherType.Stormy;
    }
    else if (data.weather_keywords.Contains("calm"))
    {
        weather = WeatherType.Calm;
    }
    
    // Apply weather with smooth transition
    WeatherManager.Instance.TransitionTo(weather, transitionTime: 30f);
}
```

### 3. Adaptive NPC Dialogue

```javascript
// NPC dialogue adapts to player mood
function getNPCDialogue(moodData) {
    const stress = moodData.mood_scores.stress;
    
    if (stress > 0.7) {
        return {
            greeting: "You look like you could use a break. Want to sit down?",
            tone: "empathetic",
            questDifficulty: "easy"
        };
    } else {
        return {
            greeting: "You seem ready for adventure! I have a challenge for you.",
            tone: "encouraging",
            questDifficulty: "hard"
        };
    }
}
```

---

## ⚙️ CONFIGURATION OPTIONS

### Polling Frequency

```javascript
// Adjust based on your game's needs
const CONFIG = {
    // Real-time games (action, racing)
    realtime: { pollInterval: 30000 },  // 30 seconds
    
    // Turn-based games (Tarot, strategy)
    turnBased: { pollInterval: 120000 }, // 2 minutes
    
    // Ambient games (visual novels)
    ambient: { pollInterval: 300000 }   // 5 minutes
};
```

### Error Handling

```javascript
async function fetchWithRetry(url, maxRetries = 3) {
    for (let i = 0; i < maxRetries; i++) {
        try {
            const response = await fetch(url);
            return await response.json();
        } catch (error) {
            if (i === maxRetries - 1) throw error;
            await new Promise(r => setTimeout(r, 1000 * (i + 1)));
        }
    }
}
```

---

## 🔒 SECURITY BEST PRACTICES

### 1. Rate Limiting

```javascript
// Implement client-side rate limiting
class RateLimitedClient {
    constructor(apiUrl, maxRequestsPerHour = 100) {
        this.apiUrl = apiUrl;
        this.maxRequests = maxRequestsPerHour;
        this.requests = [];
    }
    
    canMakeRequest() {
        const oneHourAgo = Date.now() - (60 * 60 * 1000);
        this.requests = this.requests.filter(t => t > oneHourAgo);
        return this.requests.length < this.maxRequests;
    }
    
    async fetch() {
        if (!this.canMakeRequest()) {
            console.warn('Rate limit reached');
            return null;
        }
        
        this.requests.push(Date.now());
        const response = await fetch(this.apiUrl);
        return response.json();
    }
}
```

### 2. Fallback Handling

```javascript
// Always have a default mood state
const DEFAULT_MOOD = {
    mood_scores: {
        energy: 0.5,
        stress: 0.5,
        focus: 0.5,
        social: 0.5
    },
    weather_keywords: ['neutral']
};

function getMoodOrDefault(response) {
    return response?.status === 'success' 
        ? response.data 
        : DEFAULT_MOOD;
}
```

---

## 📊 TESTING YOUR INTEGRATION

### Test Checklist

- [ ] API connectivity verified
- [ ] Mood data parsing successful
- [ ] Game responds to all mood score ranges (0.0 - 1.0)
- [ ] Weather keywords applied correctly
- [ ] Graceful fallback when API unavailable
- [ ] Rate limiting respected
- [ ] Performance impact acceptable (<5ms per update)

### Mock API for Testing

```javascript
// For offline testing
const MOCK_API_RESPONSES = [
    {
        status: 'success',
        data: {
            mood_scores: { energy: 0.9, stress: 0.2, focus: 0.8, social: 0.7 },
            weather_keywords: ['sunny', 'clear']
        }
    },
    {
        status: 'success',
        data: {
            mood_scores: { energy: 0.3, stress: 0.8, focus: 0.4, social: 0.3 },
            weather_keywords: ['stormy', 'cloudy']
        }
    }
];

function mockFetchMood() {
    return MOCK_API_RESPONSES[Math.floor(Math.random() * MOCK_API_RESPONSES.length)];
}
```

---

## 🚀 DEPLOYMENT

### Production Checklist

- [ ] Change API URL from localhost to production server
- [ ] Enable HTTPS (wss:// for WebSocket if added later)
- [ ] Configure CORS on server side if needed
- [ ] Set appropriate polling intervals (avoid overloading)
- [ ] Implement comprehensive error logging
- [ ] Monitor API latency and uptime
- [ ] Set up fallback/default mood state

---

## 🆘 TROUBLESHOOTING

### Common Issues

**1. API Returns 404**
```
Solution: Verify server is running and endpoint is /api/v1/game/vibe
```

**2. CORS Error (Web Games)**
```
Solution: Server has CORS enabled by default. If still errors, check browser console.
```

**3. Mood Scores Always 0.5**
```
Solution: This is normal for new sessions. Scores update as user interacts with KIVOSY.
```

**4. Weather Keywords Always 'neutral'**
```
Solution: This is the default when mood is balanced (energy/stress around 0.5).
```

---

## 📞 SUPPORT

For integration support or feature requests:
- **Architecture:** See `SOUL_ENGINE_ARCHITECTURE.md`
- **Server Code:** See `server_fixed.py`
- **Questions:** Contact Factory Manager (공장장님)

---

**Happy coding! 🎮✨**

*Build games that feel alive with Soul Engine!*
