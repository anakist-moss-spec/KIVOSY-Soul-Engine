"""
KIVOSY v4.1 - Personal AI Infrastructure (PAI)
Chief Engineer: Claude (Anthropic)
Version: 4.1.1 - Soul Engine Edition

Evolution: Simple Logger → Jarvis → Proactive Secretary → Soul Engine

🆕 NEW in v4.1.1:
✅ Fixed 'role' KeyError with defensive parsing
✅ Soul Engine API (/api/v1/game/vibe) for game integration
✅ Anonymized mood/vibe data export for external game servers
✅ Strict data isolation (no personal info leakage)

Features:
✅ Multi-channel unified endpoints
✅ PAI Memory System (preferences + learning)
✅ Context-aware AI responses
✅ Automatic learning from conversations
✅ LM Studio 14B integration
✅ Game-ready anonymized API
"""

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from datetime import datetime
import json
import os
import uuid
import requests
import re
from pathlib import Path
from typing import Optional, Dict, List, Any

# ═══════════════════════════════════════════════════════════
# 경로 자동 최적화
# ═══════════════════════════════════════════════════════════
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FRONTEND_DIR = os.path.join(BASE_DIR, 'frontend')
MEMORY_DIR = os.path.join(BASE_DIR, 'memory')

app = Flask(__name__, static_folder=FRONTEND_DIR, static_url_path='')
CORS(app)

# ═══════════════════════════════════════════════════════════
# LM STUDIO 14B 설정
# ═══════════════════════════════════════════════════════════
LM_STUDIO_URL = "http://localhost:1234/v1/chat/completions"

print(f"""
╔═══════════════════════════════════════════════════════════╗
║  🧠 KIVOSY v4.1.1 - SOUL ENGINE EDITION                   ║
╚═══════════════════════════════════════════════════════════╝
Evolution: SimSimi → Jarvis → Secretary → Soul Engine
Response Format: 3-Step Professional
Learning Engine: Aggressive Zero-Miss Mode
Soul Engine: Game Integration Ready 🎮
LM Studio: {LM_STUDIO_URL}
""")

# ═══════════════════════════════════════════════════════════
# 채널 설정
# ═══════════════════════════════════════════════════════════
CHANNELS = {
    'kakao': {'name': 'KakaoTalk', 'icon': '💬', 'color': '#FAE100'},
    'whatsapp': {'name': 'WhatsApp', 'icon': '🟢', 'color': '#25D366'},
    'line': {'name': 'LINE', 'icon': '💚', 'color': '#00B900'}
}

# ═══════════════════════════════════════════════════════════
# 🆕 v4.1.1: DEFENSIVE API RESPONSE PARSER
# ═══════════════════════════════════════════════════════════

class SafeAPIParser:
    """
    Defensive parser for LM Studio API responses.
    NEVER crashes on malformed JSON or missing keys.
    """
    
    @staticmethod
    def extract_content(response_data: Dict, fallback: str = "") -> str:
        """
        Safely extract content from API response with multiple fallback strategies.
        
        Args:
            response_data: Raw response from LM Studio API
            fallback: Default value if extraction fails
            
        Returns:
            Extracted content or fallback
        """
        try:
            # Strategy 1: Standard OpenAI format
            if isinstance(response_data, dict):
                choices = response_data.get('choices', [])
                if choices and len(choices) > 0:
                    first_choice = choices[0]
                    if isinstance(first_choice, dict):
                        message = first_choice.get('message', {})
                        if isinstance(message, dict):
                            content = message.get('content')
                            if content is not None:
                                return str(content)
                
                # Strategy 2: Direct content field
                content = response_data.get('content')
                if content is not None:
                    return str(content)
                
                # Strategy 3: Text field (some APIs use this)
                text = response_data.get('text')
                if text is not None:
                    return str(text)
            
            # Strategy 4: If response_data is already a string
            if isinstance(response_data, str):
                return response_data
            
            print(f"[SafeParser] ⚠️ Could not extract content from: {type(response_data)}")
            return fallback
            
        except Exception as e:
            print(f"[SafeParser] ⚠️ Exception during extraction: {e}")
            return fallback
    
    @staticmethod
    def safe_json_extract(text: str, pattern: str = r'\[[\s\S]*?\]') -> Optional[List]:
        """
        Safely extract and parse JSON array from text.
        
        Args:
            text: Text containing JSON
            pattern: Regex pattern to find JSON
            
        Returns:
            Parsed list or None if extraction fails
        """
        try:
            json_match = re.search(pattern, text)
            if json_match:
                return json.loads(json_match.group(0))
        except (json.JSONDecodeError, AttributeError) as e:
            print(f"[SafeParser] ⚠️ JSON extraction failed: {e}")
        return None

# ═══════════════════════════════════════════════════════════
# 🆕 v4.1.1: SOUL ENGINE - ANONYMIZED MOOD DATA
# ═══════════════════════════════════════════════════════════

class SoulEngine:
    """
    Soul Engine: Anonymized mood/vibe data for game integration.
    
    STRICT DATA ISOLATION:
    - NO personal info (names, locations, habits)
    - ONLY mood scores and weather keywords
    - NO conversation content
    """
    
    def __init__(self, memory_system):
        self.memory = memory_system
    
    def get_mood_score(self) -> Dict[str, float]:
        """
        Calculate anonymized mood score from recent activity.
        
        Returns:
            {
                'energy': 0.0-1.0,
                'stress': 0.0-1.0,
                'focus': 0.0-1.0,
                'social': 0.0-1.0
            }
        """
        session = self.memory.get_session_context()
        learning = self.memory.get_learning()
        
        # Default neutral state
        mood = {
            'energy': 0.5,
            'stress': 0.5,
            'focus': 0.5,
            'social': 0.5
        }
        
        try:
            # Analyze recent message patterns (anonymized)
            message_count = session.get('message_count', 0)
            learning_count = session.get('learning_count', 0)
            
            # High activity = higher energy
            if message_count > 10:
                mood['energy'] = min(0.5 + (message_count / 100), 1.0)
            
            # Learning activity = higher focus
            if learning_count > 5:
                mood['focus'] = min(0.5 + (learning_count / 20), 1.0)
            
            # Analyze fact types for mood indicators
            recent_facts = learning.get('facts', [])[-10:]
            for fact in recent_facts:
                content_lower = fact.get('content', '').lower()
                
                # Stress indicators (anonymized keywords)
                stress_keywords = ['피곤', '바쁨', '힘듦', '스트레스', 'tired', 'busy', 'stressed']
                if any(kw in content_lower for kw in stress_keywords):
                    mood['stress'] = min(mood['stress'] + 0.1, 1.0)
                
                # Energy indicators
                energy_keywords = ['활발', '열정', '에너지', 'energetic', 'excited', 'active']
                if any(kw in content_lower for kw in energy_keywords):
                    mood['energy'] = min(mood['energy'] + 0.1, 1.0)
            
        except Exception as e:
            print(f"[SoulEngine] ⚠️ Mood calculation error: {e}")
        
        return mood
    
    def get_weather_keywords(self) -> List[str]:
        """
        Extract weather-related mood keywords (for game environment).
        
        Returns:
            List of weather keywords: ['sunny', 'rainy', 'stormy', 'calm']
        """
        mood = self.get_mood_score()
        keywords = []
        
        # Map mood to weather (thematic, not literal)
        if mood['energy'] > 0.7:
            keywords.append('sunny')
        elif mood['energy'] < 0.3:
            keywords.append('cloudy')
        
        if mood['stress'] > 0.7:
            keywords.append('stormy')
        elif mood['stress'] < 0.3:
            keywords.append('calm')
        
        if mood['focus'] > 0.7:
            keywords.append('clear')
        
        return keywords if keywords else ['neutral']
    
    def get_anonymized_export(self) -> Dict:
        """
        Get fully anonymized data for game servers.
        
        GUARANTEED SAFE:
        - No names, locations, personal details
        - Only abstract mood metrics
        """
        return {
            'mood_scores': self.get_mood_score(),
            'weather_keywords': self.get_weather_keywords(),
            'timestamp': datetime.now().isoformat(),
            'version': '1.0'
        }

# ═══════════════════════════════════════════════════════════
# 🆕 v4.1 ENHANCED MEMORY SYSTEM (WITH DEFENSIVE FIXES)
# ═══════════════════════════════════════════════════════════

class MemorySystem:
    """
    v4.1.1 Enhanced PAI Memory System with Defensive Parsing
    
    FIXED in v4.1.1:
    - Defensive API response parsing (no more KeyError)
    - Safe JSON extraction
    - Graceful fallbacks for all LLM calls
    """
    
    def __init__(self, memory_dir: str = MEMORY_DIR):
        self.memory_dir = Path(memory_dir)
        self.preferences_file = self.memory_dir / 'preferences.json'
        self.learning_file = self.memory_dir / 'learning.json'
        self.session_file = self.memory_dir / 'session.json'
        
        self._ensure_memory_structure()
    
    def _ensure_memory_structure(self):
        """Initialize memory directory and files"""
        self.memory_dir.mkdir(exist_ok=True)
        
        # preferences.json (v4.1 enhanced)
        if not self.preferences_file.exists():
            default_preferences = {
                'version': '4.1.1',
                'created_at': datetime.now().isoformat(),
                'user': {
                    'name': '공장장',
                    'role': 'Factory Owner',
                    'timezone': 'Asia/Seoul',
                    'language': 'ko',
                    'communication_style': 'professional'
                },
                'ai': {
                    'response_style': 'proactive',  # 🆕 proactive mode
                    'thinking_display': True,
                    'tone': 'friendly-professional',
                    'secretary_mode': True  # 🆕 observant secretary
                },
                'preferences': {
                    'summary_length': 'medium',
                    'technical_depth': 'moderate',
                    'emoji_usage': True,
                    'proactive_suggestions': True  # 🆕
                }
            }
            self._save_json(self.preferences_file, default_preferences)
            print(f"✅ Created preferences.json (v4.1.1)")
        
        # learning.json (v4.1 enhanced)
        if not self.learning_file.exists():
            default_learning = {
                'version': '4.1.1',
                'created_at': datetime.now().isoformat(),
                'facts': [],
                'patterns': [],
                'insights': [],
                'habits': []  # 🆕 user habits tracking
            }
            self._save_json(self.learning_file, default_learning)
            print(f"✅ Created learning.json (v4.1.1)")
        
        # session.json (v4.1 enhanced)
        if not self.session_file.exists():
            default_session = {
                'session_id': str(uuid.uuid4()),
                'started_at': datetime.now().isoformat(),
                'message_count': 0,
                'context': [],
                'learning_count': 0  # 🆕 track learnings per session
            }
            self._save_json(self.session_file, default_session)
            print(f"✅ Created session.json (v4.1.1)")
    
    def get_preferences(self) -> Dict:
        return self._load_json(self.preferences_file)
    
    def get_learning(self) -> Dict:
        return self._load_json(self.learning_file)
    
    def get_session_context(self) -> Dict:
        return self._load_json(self.session_file)
    
    def build_context_prompt(self) -> str:
        """
        🆕 v4.1: Enhanced context with 3-step response instructions
        """
        prefs = self.get_preferences()
        learning = self.get_learning()
        session = self.get_session_context()
        
        # Get recent learnings with confidence levels
        recent_facts = learning['facts'][-10:] if learning['facts'] else []
        recent_patterns = learning.get('patterns', [])[-5:]
        
        context = f"""[KIVOSY v4.1.1 MEMORY SYSTEM - PROACTIVE SECRETARY MODE]

👤 FACTORY OWNER PROFILE:
Name: {prefs['user']['name']} ({prefs['user']['role']})
Language: {prefs['user']['language']}
Timezone: {prefs['user']['timezone']}
Communication: {prefs['user']['communication_style']}

🤖 YOUR ROLE (Observant Secretary):
You are a PROACTIVE AI SECRETARY who:
- NEVER misses personal details, preferences, or facts
- ALWAYS references memory when relevant
- ALWAYS provides actionable suggestions
- Uses 3-step response format MANDATORY

📚 ACCUMULATED KNOWLEDGE ({len(learning['facts'])} facts):
"""
        
        # Add facts with confidence indicators
        if recent_facts:
            for i, fact in enumerate(recent_facts, 1):
                confidence = fact.get('confidence', 0.5)
                emoji = "🟢" if confidence > 0.7 else "🟡" if confidence > 0.5 else "🔴"
                content = fact.get('content', 'N/A')[:80]
                learned_date = fact.get('learned_at', '')[:10]
                context += f"{i}. {emoji} {content} (learned: {learned_date})\n"
        else:
            context += "(No facts yet - be observant and start learning!)\n"
        
        # Add patterns if any
        if recent_patterns:
            context += f"\n🔍 OBSERVED PATTERNS:\n"
            for pattern in recent_patterns:
                context += f"- {pattern.get('content', 'N/A')}\n"
        
        context += f"""
📊 CURRENT SESSION:
Session: {session['session_id'][:8]}
Messages: {session['message_count']}
Learnings This Session: {session.get('learning_count', 0)}

🎯 MANDATORY 3-STEP RESPONSE FORMAT:

You MUST respond using this exact structure:

<think>
[Your detailed reasoning process]
[Consider: What does memory tell me about Factory Owner?]
[Consider: What patterns or preferences are relevant?]
[Consider: What would be most helpful right now?]
</think>

<summary>
[ONE sentence: What the user said or what happened]
</summary>

<insight>
[What you REALIZED from memory context]
[MUST reference specific facts/patterns when relevant]
[Examples:
 - "Based on your preference for X (learned 3 days ago)..."
 - "This aligns with your usual pattern of Y..."
 - "I notice this is the 3rd time you mentioned Z..."]
[If no memory relevant: "This is new information - I'll remember this."]
</insight>

<suggestion>
[What you recommend PROACTIVELY]
[Examples:
 - "I suggest you... because..."
 - "Based on your usual workflow, you might want to..."
 - "This could be a good time to..."]
[If no suggestion: "Let me know if you need anything else."]
</suggestion>

RULES:
- <think> is HIDDEN from user (for your internal reasoning)
- <summary>, <insight>, <suggestion> are SHOWN to user
- NEVER skip any section
- ALWAYS use exact XML tags
- Keep each section concise but meaningful
"""
        
        return context
    
    def _save_json(self, path, data):
        """Save JSON with error handling"""
        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"[Memory] ⚠️ Failed to save {path}: {e}")
    
    def _load_json(self, path):
        """Load JSON with error handling"""
        try:
            if path.exists():
                with open(path, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except Exception as e:
            print(f"[Memory] ⚠️ Failed to load {path}: {e}")
        return {}
    
    def extract_learnings(self, user_message: str, ai_response: str) -> List[Dict]:
        """
        🆕 v4.1: Multi-pass learning extraction
        - Pass 1: Regex patterns (fast, always runs)
        - Pass 2: LLM extraction (slower, high-quality)
        """
        learnings = []
        
        # Pass 1: Regex-based extraction (always runs)
        learnings.extend(self._extract_regex(user_message))
        
        # Pass 2: LLM-powered extraction (with defensive parsing)
        try:
            learnings.extend(self._extract_llm_powered(user_message))
        except Exception as e:
            print(f"[Learning] ⚠️ LLM extraction failed (continuing): {e}")
        
        return learnings
    
    def _extract_regex(self, text: str) -> List[Dict]:
        """Fast regex-based extraction for obvious patterns"""
        learnings = []
        
        patterns = [
            (r'나는 (.+?)(?:을|를|이|가) 좋아', 'preference', 0.7),
            (r'내 이름은 (.+?)(?:이다|입니다|야|이야)', 'fact', 0.9),
            (r'나는 (.+?)(?:에서|에) (?:일하|근무)', 'fact', 0.8),
            (r'매일|매주|항상 (.+?)(?:한다|해)', 'habit', 0.7),
        ]
        
        for pattern, type_, confidence in patterns:
            matches = re.finditer(pattern, text)
            for match in matches:
                content = f"공장장은 {match.group(1).strip()}"
                learnings.append({
                    'type': type_,
                    'content': content,
                    'learned_at': datetime.now().isoformat(),
                    'source': 'regex',
                    'confidence': confidence
                })
        
        return learnings
    
    def _extract_llm_powered(self, user_message: str) -> List[Dict]:
        """
        🆕 v4.1.1: LLM-powered extraction with DEFENSIVE PARSING
        
        FIXED: No more KeyError crashes
        """
        extraction_prompt = f"""당신은 매우 관찰력이 뛰어난 비서입니다. 사용자의 메시지에서 학습할 만한 모든 정보를 빠짐없이 추출하세요.

사용자 메시지: "{user_message}"

다음을 찾아서 JSON 배열로 반환하세요:
1. 개인 선호사항 (좋아하는 것, 싫어하는 것, 선호하는 것)
2. 사실 정보 (이름, 직업, 위치, 회사, 소속 등)
3. 습관/패턴 (시간, 루틴, 반복적인 행동)
4. 목표/계획 (하고 싶은 것, 계획, 일정)
5. 기타 개인 정보 (취미, 관심사, 중요한 사람/장소 등)

반환 형식 (JSON만):
[
  {{"type": "preference", "content": "공장장은 커피를 좋아함", "confidence": 0.9}},
  {{"type": "fact", "content": "회사는 서울 강남에 위치", "confidence": 0.8}},
  {{"type": "habit", "content": "매일 아침 9시에 출근", "confidence": 0.7}}
]

학습할 정보가 없으면: []

중요: 
- 반드시 JSON 배열만 반환 (다른 텍스트 없이)
- 사소한 정보도 놓치지 마세요
- confidence는 0.5~1.0 사이
- content는 "공장장" 주어로 시작
"""
        
        try:
            response = requests.post(
                LM_STUDIO_URL,
                json={
                    "messages": [{"role": "user", "content": extraction_prompt}],
                    "temperature": 0.3,  # Low temp for structured output
                    "max_tokens": 800
                },
                timeout=15  # Fast extraction
            )
            
            if response.ok:
                # 🆕 DEFENSIVE PARSING - No more crashes!
                response_data = response.json()
                raw = SafeAPIParser.extract_content(response_data, fallback="[]")
                
                # Extract JSON from response
                extracted = SafeAPIParser.safe_json_extract(raw)
                if extracted:
                    learnings = []
                    for item in extracted:
                        if isinstance(item, dict) and 'content' in item:
                            learnings.append({
                                'type': item.get('type', 'fact'),
                                'content': item['content'],
                                'learned_at': datetime.now().isoformat(),
                                'source': 'llm',
                                'confidence': float(item.get('confidence', 0.7))
                            })
                    
                    if learnings:
                        print(f"[Learning LLM] 🧠 Extracted {len(learnings)} items via AI")
                    
                    return learnings
        
        except requests.Timeout:
            print(f"[Learning LLM] ⏱️ Timeout (skipping LLM extraction)")
        except Exception as e:
            print(f"[Learning LLM] ⚠️ Error: {e}")
        
        return []
    
    def update_learning(self, new_learnings: List[Dict]):
        """Update learning.json with deduplication and reinforcement"""
        if not new_learnings:
            return
        
        learning_data = self.get_learning()
        added_count = 0
        reinforced_count = 0
        
        for learning in new_learnings:
            content = learning['content']
            
            # Check for similar existing facts (fuzzy match)
            is_duplicate = False
            for existing in learning_data['facts']:
                similarity = self._similarity(content, existing.get('content', ''))
                if similarity > 0.75:  # 75% similarity threshold
                    is_duplicate = True
                    # Reinforce if new confidence is higher
                    old_conf = existing.get('confidence', 0.5)
                    new_conf = learning.get('confidence', 0.5)
                    if new_conf > old_conf:
                        existing['confidence'] = new_conf
                        existing['last_reinforced'] = datetime.now().isoformat()
                        existing['reinforcement_count'] = existing.get('reinforcement_count', 0) + 1
                        reinforced_count += 1
                        print(f"[Learning] 🔄 Reinforced: {content[:50]}... (conf: {old_conf:.2f}→{new_conf:.2f})")
                    break
            
            if not is_duplicate:
                learning_data['facts'].append(learning)
                added_count += 1
                conf_emoji = "🟢" if learning.get('confidence', 0) > 0.7 else "🟡"
                print(f"[Learning] {conf_emoji} NEW: {content[:60]}...")
        
        if added_count > 0 or reinforced_count > 0:
            self._save_json(self.learning_file, learning_data)
            
            # Update session stats
            session = self.get_session_context()
            session['learning_count'] = session.get('learning_count', 0) + added_count
            self._save_json(self.session_file, session)
            
            print(f"[Learning] 📚 Total: {added_count} new + {reinforced_count} reinforced")
    
    def _similarity(self, a: str, b: str) -> float:
        """Simple fuzzy string matching (Jaccard similarity)"""
        set_a = set(a.lower().split())
        set_b = set(b.lower().split())
        if not set_a or not set_b:
            return 0.0
        intersection = set_a & set_b
        union = set_a | set_b
        return len(intersection) / len(union)
    
    def update_session(self):
        """Update session message count"""
        session = self.get_session_context()
        session['message_count'] = session.get('message_count', 0) + 1
        self._save_json(self.session_file, session)
    
    def reset_session(self):
        """Reset session (new conversation start)"""
        new_session = {
            'session_id': str(uuid.uuid4()),
            'started_at': datetime.now().isoformat(),
            'message_count': 0,
            'context': [],
            'learning_count': 0
        }
        self._save_json(self.session_file, new_session)
        print(f"[Memory] 🔄 Session reset: {new_session['session_id'][:8]}")

# ═══════════════════════════════════════════════════════════
# 3-STEP THINKING PARSER
# ═══════════════════════════════════════════════════════════

class ThinkingParser:
    """Parse 3-step response format (think/summary/insight/suggestion)"""
    
    @staticmethod
    def extract(text: str) -> Dict[str, Any]:
        """Extract all sections from formatted response"""
        
        # Extract each section
        think_match = re.search(r'<think>(.*?)</think>', text, re.DOTALL)
        summary_match = re.search(r'<summary>(.*?)</summary>', text, re.DOTALL)
        insight_match = re.search(r'<insight>(.*?)</insight>', text, re.DOTALL)
        suggestion_match = re.search(r'<suggestion>(.*?)</suggestion>', text, re.DOTALL)
        
        thinking = think_match.group(1).strip() if think_match else ""
        summary = summary_match.group(1).strip() if summary_match else ""
        insight = insight_match.group(1).strip() if insight_match else ""
        suggestion = suggestion_match.group(1).strip() if suggestion_match else ""
        
        # If parsing fails, use the whole text as summary
        if not summary and not insight and not suggestion:
            summary = text.strip()
        
        return {
            'thinking': thinking,
            'summary': summary,
            'insight': insight,
            'suggestion': suggestion,
            'has_thinking': bool(thinking)
        }

# ═══════════════════════════════════════════════════════════
# UNIFIED CHANNEL GATEWAY
# ═══════════════════════════════════════════════════════════

class UnifiedChannelGateway:
    """
    Unified gateway for all messaging channels
    
    v4.1.1: Enhanced with defensive API calls
    """
    
    def __init__(self):
        self.nodes_path = Path(MEMORY_DIR) / 'nodes.json'
    
    def ask_ai(self, text: str, language: str = "auto") -> Dict:
        """
        Ask AI with proactive 3-step response
        
        v4.1.1: Enhanced with defensive parsing
        """
        memory_context = memory.build_context_prompt()
        
        full_prompt = f"""{memory_context}

USER MESSAGE:
{text}

RESPOND NOW using the 3-step format above. Be proactive and reference memory when relevant!
"""
        
        try:
            print(f"[14B AI] 언어: {language.upper()} | 메모리: {len(memory_context)}자 | 모드: PROACTIVE")
            
            response = requests.post(LM_STUDIO_URL, json={
                "messages": [{"role": "user", "content": full_prompt}],
                "temperature": 0.7
            }, timeout=60)
            
            # 🆕 DEFENSIVE PARSING
            response_data = response.json()
            raw = SafeAPIParser.extract_content(
                response_data, 
                fallback="<think>API 응답 파싱 실패</think><summary>AI 응답을 처리할 수 없습니다.</summary>"
            )
            
            print(f"[14B AI] 응답 완료: {len(raw)}자")
            
            # 🆕 v4.1: Aggressive learning extraction (with defensive handling)
            try:
                learnings = memory.extract_learnings(text, raw)
                if learnings:
                    memory.update_learning(learnings)
            except Exception as e:
                print(f"[Learning] ⚠️ Failed to extract learnings (continuing): {e}")
                learnings = []
            
            # Parse 3-step format
            parsed = ThinkingParser.extract(raw)
            
            return {
                'raw': raw,
                'thinking': parsed['thinking'],
                'summary': parsed['summary'],
                'insight': parsed['insight'],  # 🆕
                'suggestion': parsed['suggestion'],  # 🆕
                'has_thinking': parsed['has_thinking'],
                'language': language,
                'learnings_extracted': len(learnings)
            }
            
        except Exception as e:
            print(f"[14B AI] 오류: {e}")
            return {
                'raw': f"<think>오류: {e}</think><summary>AI 응답 실패</summary>",
                'thinking': f"오류: {e}",
                'summary': "AI 응답 실패",
                'insight': '',
                'suggestion': '',
                'has_thinking': True,
                'language': language,
                'learnings_extracted': 0
            }
    
    def save_node(self, channel, content, ai_result):
        """Save node with v4.1 enhanced structure"""
        if channel not in CHANNELS:
            raise ValueError(f"지원하지 않는 채널: {channel}")
        
        nodes = self._load()
        
        new_node = {
            "id": str(uuid.uuid4()),
            "timestamp": datetime.now().isoformat(),
            "channel": channel,
            "content": content,
            "ai_response": ai_result['raw'],
            "ai": {
                "thinking": ai_result['thinking'],
                "summary": ai_result['summary'],
                "insight": ai_result.get('insight', ''),  # 🆕
                "suggestion": ai_result.get('suggestion', ''),  # 🆕
                "has_thinking": ai_result['has_thinking'],
                "language": ai_result['language'],
                "learnings_extracted": ai_result.get('learnings_extracted', 0)
            }
        }
        
        nodes.append(new_node)
        self._save(nodes)
        memory.update_session()
        
        print(f"[저장] {CHANNELS[channel]['icon']} {channel} | ID: {new_node['id'][:8]} | 학습: {ai_result.get('learnings_extracted', 0)}개")
        
        return new_node['id']
    
    def get_nodes(self, channel_filter=None):
        nodes = self._load()
        if channel_filter and channel_filter in CHANNELS:
            nodes = [n for n in nodes if n.get('channel') == channel_filter]
        return nodes
    
    def _load(self):
        if self.nodes_path.exists():
            with open(self.nodes_path, "r", encoding="utf-8") as f:
                return json.load(f)
        return []
    
    def _save(self, nodes):
        with open(self.nodes_path, "w", encoding="utf-8") as f:
            json.dump(nodes, f, ensure_ascii=False, indent=2)

# ═══════════════════════════════════════════════════════════
# INITIALIZE GLOBAL SYSTEMS
# ═══════════════════════════════════════════════════════════

memory = MemorySystem()
gateway = UnifiedChannelGateway()
soul_engine = SoulEngine(memory)  # 🆕 Soul Engine

# ═══════════════════════════════════════════════════════════
# API ENDPOINTS
# ═══════════════════════════════════════════════════════════

@app.route('/')
def index():
    return send_from_directory(FRONTEND_DIR, 'index.html')

@app.route('/whatsapp.html')
def whatsapp_page():
    return send_from_directory(FRONTEND_DIR, 'whatsapp.html')

@app.route('/api/nodes/kakao', methods=['POST'])
def kakao():
    return _handle_channel('kakao')

@app.route('/api/nodes/whatsapp', methods=['POST'])
def whatsapp():
    return _handle_channel('whatsapp')

@app.route('/api/nodes/line', methods=['POST'])
def line():
    return _handle_channel('line')

@app.route('/api/kakao', methods=['POST'])
def legacy_kakao():
    return _handle_channel('kakao')

@app.route('/api/whatsapp', methods=['POST'])
def legacy_whatsapp():
    return _handle_channel('whatsapp')

def _handle_channel(channel):
    try:
        data = request.json
        content = data.get('content', '')
        
        if not content:
            return jsonify({"status": "empty"}), 400
        
        print(f"\n[{channel.upper()}] 수신: {content[:50]}...")
        
        # AI 분석 (Proactive 3-Step + Aggressive Learning)
        ai_result = gateway.ask_ai(content)
        
        # 노드 저장
        node_id = gateway.save_node(channel, content, ai_result)
        
        res = jsonify({
            "status": "success",
            "node_id": node_id,
            "reply": ai_result['raw'],
            "learnings_extracted": ai_result.get('learnings_extracted', 0),
            "has_insight": bool(ai_result.get('insight')),
            "has_suggestion": bool(ai_result.get('suggestion'))
        })
        res.headers.add('Content-Type', 'application/json; charset=utf-8')
        return res, 200
        
    except Exception as e:
        print(f"[{channel.upper()}] 오류: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

# ═══════════════════════════════════════════════════════════
# 🆕 v4.1.1: SOUL ENGINE API (GAME INTEGRATION)
# ═══════════════════════════════════════════════════════════

@app.route('/api/v1/game/vibe', methods=['GET'])
def game_vibe():
    """
    Soul Engine API: Anonymized mood/vibe data for game servers
    
    SECURITY:
    - No personal info (names, locations, habits)
    - Only abstract mood scores
    - No conversation content
    
    Returns:
        {
            "mood_scores": {"energy": 0.7, "stress": 0.3, ...},
            "weather_keywords": ["sunny", "calm"],
            "timestamp": "2025-01-31T10:00:00",
            "version": "1.0"
        }
    """
    try:
        anonymized_data = soul_engine.get_anonymized_export()
        
        print(f"[SoulEngine] 🎮 Game data exported: {anonymized_data['weather_keywords']}")
        
        return jsonify({
            "status": "success",
            "data": anonymized_data
        }), 200
        
    except Exception as e:
        print(f"[SoulEngine] ⚠️ Error: {e}")
        return jsonify({
            "status": "error",
            "message": "Failed to generate vibe data"
        }), 500

# ═══════════════════════════════════════════════════════════
# MEMORY API ENDPOINTS
# ═══════════════════════════════════════════════════════════

@app.route('/api/memory/preferences', methods=['GET'])
def get_preferences():
    return jsonify(memory.get_preferences())

@app.route('/api/memory/learning', methods=['GET'])
def get_learning():
    return jsonify(memory.get_learning())

@app.route('/api/memory/session', methods=['GET'])
def get_session():
    return jsonify(memory.get_session_context())

@app.route('/api/memory/reset-session', methods=['POST'])
def reset_session():
    memory.reset_session()
    return jsonify({"status": "success", "message": "Session reset"})

@app.route('/api/nodes', methods=['GET'])
def get_nodes():
    channel_filter = request.args.get('channel')
    nodes = gateway.get_nodes(channel_filter=channel_filter)
    return jsonify(nodes)

@app.route('/api/health', methods=['GET'])
def health():
    learning_data = memory.get_learning()
    session_data = memory.get_session_context()
    
    return jsonify({
        'status': 'online',
        'version': '4.1.1',
        'mode': 'soul_engine',
        'response_format': '3-step',
        'learning_engine': 'aggressive',
        'memory_system': 'enabled',
        'soul_engine': 'enabled',  # 🆕
        'total_nodes': len(gateway.get_nodes()),
        'total_learnings': len(learning_data.get('facts', [])),
        'session_learnings': session_data.get('learning_count', 0)
    })

# ═══════════════════════════════════════════════════════════
# SERVER STARTUP
# ═══════════════════════════════════════════════════════════

if __name__ == '__main__':
    print(f"""
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║   🧠 KIVOSY v4.1.1 - SOUL ENGINE EDITION                  ║
║                                                           ║
║         Evolution: SimSimi → Jarvis → Secretary → 🎮      ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝

🎯 NEW in v4.1.1:
   ✅ Fixed 'role' KeyError (Defensive Parsing)
   ✅ Soul Engine API (Game Integration)
   ✅ Anonymized Mood Export
   ✅ Zero-Crash Guarantee

🧠 Memory System:
   📁 {memory.preferences_file}
   📚 {memory.learning_file}
   📊 {memory.session_file}

📡 Channels: 💬 Kakao | 🟢 WhatsApp | 💚 LINE

🎮 Soul Engine API:
   GET /api/v1/game/vibe (Anonymized mood data)

🚀 Dashboard: http://localhost:5000

공장장님, 이제 저는 게임 세계와 연결된 비서입니다! 🎯✨🎮
""")
    
    app.run(host='0.0.0.0', port=5000, debug=False)
