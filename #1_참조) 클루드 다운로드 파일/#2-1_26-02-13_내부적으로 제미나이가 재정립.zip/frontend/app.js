async function loadNodes() {
    try {
        const response = await fetch('/api/nodes');
        const nodes = await response.json();
        
        // 상단 통계 업데이트
        updateStats(nodes);

        const nodesGrid = document.getElementById('nodesGrid');
        if (nodes.length === 0) {
            document.getElementById('emptyState').style.display = 'block';
            return;
        }

        nodesGrid.innerHTML = nodes.reverse().map(node => {
            // <Think> 태그 분리 로직
            const thinkMatch = node.ai_response.match(/<(think|Think)>([\s\S]*?)<\/(think|Think)>/i);
            const thinkingProcess = thinkMatch ? thinkMatch[2].trim() : "추론 기록 없음";
            const summary = node.ai_response.replace(/<(think|Think)>[\s\S]*?<\/(think|Think)>/i, "").trim();

            return `
                <div class="node-card">
                    <div style="display:flex; justify-content:space-between; font-size:11px; color:gray; margin-bottom:12px;">
                        <span>📅 ${new Date(node.timestamp).toLocaleString()}</span>
                        <span style="color:var(--user-bubble)">#${node.id.substring(0,5)}</span>
                    </div>
                    <div style="font-weight:bold; margin-bottom:10px;">📥 수신 메시지:</div>
                    <div style="font-size:15px; margin-bottom:15px;">${node.content}</div>
                    
                    <div class="thinking-section">
                        <div style="font-size:11px; font-weight:bold; color:var(--thinking-text); margin-bottom:5px;">💭 14B 과장님의 사고 회로</div>
                        <div class="thinking-text">${thinkingProcess}</div>
                    </div>
                    
                    <div style="border-top: 1px solid rgba(255,255,255,0.1); padding-top:15px; color:var(--user-bubble)">
                        <strong>📝 요약 결과:</strong> ${summary}
                    </div>
                </div>
            `;
        }).join('');
    } catch (e) {
        console.error("데이터 로드 중 오류:", e);
    }
}

function updateStats(nodes) {
    document.getElementById('totalNodes').textContent = nodes.length;
    const thinkingCount = nodes.filter(n => n.ai_response.includes('<think>') || n.ai_response.includes('<Think>')).length;
    document.getElementById('thinkingNodes').textContent = thinkingCount;
    
    const channels = [...new Set(nodes.map(n => n.channel))];
    document.getElementById('channelCount').textContent = channels.length;
}

// 초기화 및 인터벌 설정
document.addEventListener('DOMContentLoaded', () => {
    loadNodes();
    setInterval(loadNodes, 10000);
});