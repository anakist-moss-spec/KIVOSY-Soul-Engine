from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from datetime import datetime
import json
import os
import uuid
import requests
from pathlib import Path

# [업그레이드] 경로 자동 최적화
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FRONTEND_DIR = os.path.join(BASE_DIR, 'frontend')

app = Flask(__name__, static_folder=FRONTEND_DIR, static_url_path='')
CORS(app)

# ═══════════════════════════════════════════════════════════
# CONFIGURATION (LM Studio 14B 연동 설정)
# ═══════════════════════════════════════════════════════════
LM_STUDIO_URL = "http://localhost:1234/v1/chat/completions"

class KakaoChannel:
    def __init__(self):
        self.nodes_path = Path(os.path.join(BASE_DIR, "nodes.json"))

    def ask_ai(self, text):
        prompt = f"사용자가 보낸 다음 메시지를 분석해서 <think> 과정과 요약을 출력해줘.\n메시지 내용: {text}"
        try:
            response = requests.post(LM_STUDIO_URL, json={
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 0.7
            }, timeout=60) # 14B 모델은 생각 시간이 필요하므로 60초로 넉넉히!
            return response.json()['choices'][0]['message']['content']
        except Exception as e:
            return f"<think>에러: {e}</think>AI 응답 실패"

    def save_node(self, original_text, ai_response):
        nodes = []
        if self.nodes_path.exists():
            with open(self.nodes_path, "r", encoding="utf-8") as f:
                nodes = json.load(f)
        
        new_node = {
            "id": str(uuid.uuid4()),
            "timestamp": datetime.now().isoformat(),
            "content": original_text,
            "ai_response": ai_response,
            "channel": "kakao"
        }
        nodes.append(new_node)
        with open(self.nodes_path, "w", encoding="utf-8") as f:
            json.dump(nodes, f, ensure_ascii=False, indent=2)

kakao_gateway = KakaoChannel()

@app.route('/')
def index():
    return send_from_directory(FRONTEND_DIR, 'index.html')

@app.route('/api/kakao', methods=['POST'])
def handle_kakao():
    data = request.json
    content = data.get('content', '')
    if not content: return jsonify({"status": "empty"}), 400
    
    ai_result = kakao_gateway.ask_ai(content)
    kakao_gateway.save_node(content, ai_result)
    
    # [업그레이드] 한글 깨짐 방지 헤더 추가
    res = jsonify({"status": "success", "reply": ai_result})
    res.headers.add('Content-Type', 'application/json; charset=utf-8')
    return res, 200

@app.route('/api/nodes', methods=['GET'])
def get_nodes():
    if kakao_gateway.nodes_path.exists():
        with open(kakao_gateway.nodes_path, "r", encoding="utf-8") as f:
            return jsonify(json.load(f))
    return jsonify([])

if __name__ == '__main__':
    print(f"🚀 KIVOSY 엔진 가동! 대시보드: http://localhost:5000")
    app.run(host='0.0.0.0', port=5000, debug=False)