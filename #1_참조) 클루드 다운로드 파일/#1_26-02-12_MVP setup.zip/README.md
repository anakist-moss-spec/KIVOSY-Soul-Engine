# 🧠 Log-Network v2.0 - OpenClaw Edition

**KIVOSY Global Empire - Premium Architecture**

Inspired by OpenClaw's elegant design and architecture, this version brings enterprise-grade features to your personal knowledge management system.

---

## 🎯 What's New - OpenClaw Edition

### ✅ **Premium UI/UX (ChatTheme.swift-inspired)**
- **OpenClaw Color Palette:** Ultra-thin materials, gradient backgrounds
- **Assistant Bubble Design:** Matching OpenClaw's macOS aesthetic
- **Fluid Animations:** cubic-bezier transitions, backdrop filters
- **Radial Gradients:** Orange/Teal/Purple accent system

### ✅ **Thinking Visualization (AssistantTextParser.swift)**
- **Reasoning Process Display:** `<think>...</think>` tag parsing
- **Segment Separation:** Thinking vs Final Response
- **Visual Indicators:** 💭 badges for thinking-enhanced nodes
- **Collapsible Sections:** Clean presentation of AI reasoning

### ✅ **Telegram Channel Integration (channel.ts-inspired)**
- **Multi-Channel Architecture:** YouTube + Telegram (+ future channels)
- **Webhook Support:** Real-time message capture
- **Bot Integration:** Two-way communication
- **OpenClaw Plugin Pattern:** Modular channel system

### ✅ **Advanced Session Management**
- **Chat Sessions:** OpenClaw-compatible session structure
- **Preview System:** Quick session overviews
- **Usage Tracking:** Token counting, cost estimation
- **State Management:** Conversation continuity

---

## 📦 Quick Start

### Prerequisites
- Python 3.8+
- (Optional) Telegram Bot Token
- (Optional) LM Studio for local LLM

### Installation

```bash
# 1. Install dependencies
cd backend
pip install -r requirements.txt

# 2. (Optional) Set Telegram bot token
export TELEGRAM_BOT_TOKEN="your-bot-token-here"

# 3. Start server
python server.py
```

### Access Dashboard

```
http://localhost:5000
```

You'll see the OpenClaw-inspired premium interface! 🎨

---

## 🎨 OpenClaw Design System

### Color Palette

```css
/* Surface Colors */
--surface: #1a1a1e              /* Main background */
--surface-light: #25252a        /* Elevated surfaces */
--card: #2d2d32                 /* Card backgrounds */

/* User/Assistant Bubbles */
--user-bubble: rgb(127, 184, 212)              /* Teal blue */
--assistant-bubble: rgba(46, 46, 50, 0.88)     /* Dark gray */

/* Accent Gradients */
--accent-orange: rgba(255, 149, 0, 0.14)   /* Top-left glow */
--accent-teal: rgba(90, 200, 250, 0.12)    /* Top-right glow */
--accent-purple: rgba(175, 82, 222, 0.1)   /* Center glow */

/* Thinking Colors */
--thinking-bg: rgba(255, 200, 100, 0.08)   /* Warm yellow */
--thinking-border: rgba(255, 200, 100, 0.2)
--thinking-text: rgba(255, 200, 150, 0.9)
```

### Typography

```css
/* Headings */
font-family: 'SF Pro Display', -apple-system, BlinkMacSystemFont

/* Code/Context */
font-family: 'SF Mono', 'Monaco', 'Courier New', monospace
```

### Materials

- **Ultra-thin:** `rgba(255, 255, 255, 0.05)` + `blur(40px)`
- **Thin:** `rgba(255, 255, 255, 0.08)` + `blur(20px)`
- **Backdrop Filter:** `saturate(180%)` for vibrancy

---

## 💭 Thinking Visualization

### How It Works

The system parses LLM responses for thinking tags:

```xml
<think>
This is the reasoning process...
I'm analyzing the problem step by step.
</think>

<final>
This is the final answer presented to the user.
</final>
```

### Backend Parsing (AssistantTextParser)

```python
segments = AssistantTextParser.parse_segments(raw_text)

# Returns:
[
  ThinkingSegment(kind='thinking', text='reasoning...'),
  ThinkingSegment(kind='response', text='final answer...')
]
```

### Frontend Display

Thinking sections appear with special styling:

```css
.thinking-section {
  background: var(--thinking-bg);
  border: 1px solid var(--thinking-border);
  /* Warm yellow glow */
}
```

### Enable Thinking

In `server.py` line 46:

```python
LLM_CONFIG = {
    'local': {
        'enabled': True,
        'supports_thinking': True  # ← Set this
    }
}
```

---

## ✈️ Telegram Integration

### Setup Telegram Bot

1. **Create Bot:**
   ```
   Message @BotFather on Telegram
   /newbot
   Follow prompts
   Copy bot token
   ```

2. **Configure Log-Network:**
   ```bash
   export TELEGRAM_BOT_TOKEN="123456:ABC-DEF..."
   ```

3. **Start Server:**
   ```bash
   python server.py
   ```
   
   Look for:
   ```
   Channels: YouTube ✅ | Telegram ✅ Active
   ```

### Telegram Webhook

Set webhook URL:

```bash
curl -X POST "https://api.telegram.org/bot<TOKEN>/setWebhook" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://yourdomain.com/api/telegram/webhook"}'
```

### Send Messages via API

```bash
curl -X POST http://localhost:5000/api/telegram/send \
  -H "Content-Type: application/json" \
  -d '{
    "chat_id": "12345678",
    "text": "Hello from Log-Network!"
  }'
```

### Capture Telegram Messages

Messages are automatically captured when sent to your bot:

1. User messages bot
2. Webhook → `/api/telegram/webhook`
3. Processed → `/api/capture`
4. Appears on dashboard with ✈️ badge

---

## 🔧 API Endpoints

### OpenClaw-Compatible API

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/health` | System status (ok, channels, thinking) |
| POST | `/api/capture` | Multi-channel capture |
| GET | `/api/nodes` | All nodes with thinking data |
| GET | `/api/nodes/<id>` | Specific node |
| GET | `/api/nodes/<id>/thinking` | **Thinking process view** |
| GET | `/api/nodes/<id>/context` | Context injection |
| GET | `/api/stats` | Dashboard stats |
| POST | `/api/llm/test` | Test LLM + thinking |
| POST | `/api/telegram/webhook` | **Telegram webhook** |
| POST | `/api/telegram/send` | **Send Telegram message** |

### Example: Test Thinking

```bash
curl -X POST http://localhost:5000/api/llm/test \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "Explain quantum computing",
    "enable_thinking": true
  }'
```

Response:
```json
{
  "success": true,
  "mode": "local",
  "response": "Quantum computing uses qubits...",
  "thinking": "First, I need to consider...",
  "segments": [
    {"kind": "thinking", "text": "First..."},
    {"kind": "response", "text": "Quantum..."}
  ],
  "thinking_enabled": true
}
```

---

## 🎯 Usage Guide

### 1. Capture from YouTube

Watch any YouTube video (30%+ completion) → Purple notification → Node created

### 2. Capture from Telegram

Message your bot on Telegram → Webhook processes → Node created with ✈️ badge

### 3. View Thinking Process

Click any node → If it has 💭 badge → See thinking section with reasoning

### 4. Context Injection

Click "View Context" → Modal opens → Copy to clipboard → Paste into ChatGPT/Claude

---

## 🏗️ Architecture Comparison

### OpenClaw → Log-Network Mapping

| OpenClaw Component | Log-Network Equivalent |
|-------------------|------------------------|
| `ChatTheme.swift` | CSS `:root` variables + gradients |
| `AssistantTextParser.swift` | `AssistantTextParser` Python class |
| `channel.ts` (Telegram) | `TelegramChannel` Python class |
| `ChatMessageViews.swift` | `.node-card` CSS components |
| `ChatSessions.swift` | `sessions.json` data structure |
| `runtime.ts` | Global runtime configuration |

### Plugin Pattern

OpenClaw uses:
```typescript
api.registerChannel({ plugin: telegramPlugin });
```

Log-Network uses:
```python
telegram_channel = TelegramChannel()
# Auto-registered on server start
```

---

## 📊 Data Schema

### Node Structure (Enhanced)

```json
{
  "node_id": "uuid",
  "parent_id": "uuid-or-null",
  "timestamp": "ISO-8601",
  "source_metadata": {
    "type": "telegram",
    "chat_id": "12345",
    "message_id": 789,
    "from_user": "@username"
  },
  "content_summary": "AI-generated summary",
  "context_snapshot": {
    "thinking_process": "Step 1: Analyze...",  // NEW
    "segments": [                               // NEW
      {"kind": "thinking", "text": "..."},
      {"kind": "response", "text": "..."}
    ],
    "brain_state": "...",
    "llm_mode": "local"
  },
  "visual_state": {
    "dust_level": 0.0,
    "opacity": 1.0,
    "color": "#667eea"
  }
}
```

---

## 🎨 Customization

### Change Color Palette

Edit `frontend/index.html` lines 15-30:

```css
:root {
  --user-bubble: rgb(127, 184, 212);  /* ← Change this */
  --accent-teal: rgba(90, 200, 250, 0.12);  /* ← And this */
}
```

### Add New Channel

1. Create channel class in `server.py`:
   ```python
   class SlackChannel:
       def process_update(self, data):
           # Convert to capture format
           pass
   ```

2. Add webhook endpoint:
   ```python
   @app.route('/api/slack/webhook', methods=['POST'])
   def slack_webhook():
       # Process Slack events
       pass
   ```

3. Update stats tracking

### Disable Thinking

Set in `server.py`:

```python
LLM_CONFIG['local']['supports_thinking'] = False
```

---

## 🚀 Deployment

### Local Development
```bash
python server.py  # http://localhost:5000
```

### Production (with Telegram webhooks)

1. **Deploy to Heroku/Railway/AWS**
2. **Enable HTTPS** (required for Telegram)
3. **Set webhook:**
   ```bash
   curl -X POST "https://api.telegram.org/bot<TOKEN>/setWebhook" \
     -d "url=https://yourdomain.com/api/telegram/webhook"
   ```
4. **Set environment variables:**
   ```bash
   TELEGRAM_BOT_TOKEN=your-token
   ```

---

## 💡 Pro Tips

### Tip 1: Test Thinking Locally

Use LM Studio with a model that supports chain-of-thought:

```
Mistral-7B-Instruct
Llama-3-8B-Instruct
```

Prompt format:
```
Use <think>...</think> for your reasoning and <final>...</final> for your answer.
```

### Tip 2: Multi-Channel Strategy

- **YouTube:** Background learning, research
- **Telegram:** Quick notes, mobile capture
- **Future:** Slack (work), Discord (communities)

### Tip 3: Custom Thinking Prompts

Edit `server.py` line 235:

```python
if enable_thinking and config.get('supports_thinking'):
    system_message += """
    
You are an expert analyzer. Use <think>...</think> tags to show your 
step-by-step reasoning process before providing your final answer in 
<final>...</final> tags.
"""
```

---

## 🔍 Troubleshooting

### Thinking Not Showing

**Problem:** No 💭 badges on nodes

**Solutions:**
1. Check `supports_thinking: True` in server.py
2. Verify LLM is using thinking tags
3. Test with `/api/llm/test?enable_thinking=true`

### Telegram Not Working

**Problem:** "Telegram ❌ Disabled"

**Solutions:**
1. Set environment variable: `export TELEGRAM_BOT_TOKEN="..."`
2. Verify token is valid (test with BotFather)
3. Check server logs for Telegram errors

### OpenClaw UI Not Loading

**Problem:** Page shows default styling

**Solutions:**
1. Clear browser cache (Ctrl+Shift+R)
2. Check frontend/index.html is being served
3. Verify CSS variables in `:root` block

---

## 📈 Roadmap

### Phase 3: Advanced Features
- [ ] Voice note capture (Telegram voice messages)
- [ ] Image analysis integration
- [ ] Real-time collaborative sessions
- [ ] Mind map 3D visualization

### Phase 4: Enterprise
- [ ] Multi-user support
- [ ] Team workspaces
- [ ] Role-based access control
- [ ] Cloud sync

---

## 🙏 Credits

**Inspired by:**
- **OpenClaw:** Premium UI/UX design system
- **ChatTheme.swift:** Color palette & materials
- **AssistantTextParser.swift:** Thinking visualization
- **Telegram SDK:** Channel integration pattern

**Built for:**
- **KIVOSY Global Empire**
- **Personal knowledge management**
- **AI-powered productivity**

---

**🎉 You now have an OpenClaw-grade knowledge management system!**

**Enjoy your premium Log-Network experience! 🧠✨**
