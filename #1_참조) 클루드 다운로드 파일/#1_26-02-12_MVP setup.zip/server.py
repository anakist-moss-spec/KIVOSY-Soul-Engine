"""
Log-Network Backend Server - OpenClaw-Inspired Edition
KIVOSY Global Empire - Premium Architecture

Features:
- Telegram Channel Integration (OpenClaw-style)
- Multi-channel support (YouTube, Telegram, future: Slack, Discord)
- Advanced thinking visualization support
- Session management with preview system
- OpenClaw-compatible API design
"""

from flask import Flask, request, jsonify, send_from_directory, Response
from flask_cors import CORS
from datetime import datetime
import json
import os
import uuid
from pathlib import Path
import requests
import asyncio
from typing import Optional, Dict, List, Any
from dataclasses import dataclass, asdict
import re

app = Flask(__name__, static_folder='../frontend', static_url_path='')
CORS(app)

# ═══════════════════════════════════════════════════════════
# OPENCLAW-INSPIRED ARCHITECTURE
# ═══════════════════════════════════════════════════════════

@dataclass
class ThinkingSegment:
    """OpenClaw-style thinking/response segmentation"""
    kind: str  # 'thinking' or 'response'
    text: str
    
@dataclass
class MessageContent:
    """OpenClaw ChatMessageContent equivalent"""
    type: str
    text: Optional[str] = None
    thinking: Optional[str] = None
    thinking_signature: Optional[str] = None
    mime_type: Optional[str] = None
    file_name: Optional[str] = None
    
@dataclass
class ChatMessage:
    """OpenClaw ChatMessage structure"""
    role: str  # 'user', 'assistant', 'system'
    content: List[MessageContent]
    timestamp: float
    usage: Optional[Dict] = None
    stop_reason: Optional[str] = None

# ═══════════════════════════════════════════════════════════
# TELEGRAM CHANNEL INTEGRATION
# ═══════════════════════════════════════════════════════════

class TelegramChannel:
    """OpenClaw-style channel plugin for Telegram"""
    
    def __init__(self, bot_token: Optional[str] = None):
        self.bot_token = bot_token or os.getenv('TELEGRAM_BOT_TOKEN')
        self.base_url = f"https://api.telegram.org/bot{self.bot_token}" if self.bot_token else None
        self.active = bool(self.bot_token)
        
    def send_message(self, chat_id: str, text: str, parse_mode: str = "Markdown") -> bool:
        """Send message to Telegram chat"""
        if not self.active:
            return False
            
        try:
            response = requests.post(
                f"{self.base_url}/sendMessage",
                json={
                    "chat_id": chat_id,
                    "text": text,
                    "parse_mode": parse_mode
                },
                timeout=10
            )
            return response.ok
        except Exception as e:
            print(f"[Telegram] Error sending message: {e}")
            return False
    
    def get_updates(self, offset: Optional[int] = None) -> List[Dict]:
        """Fetch updates from Telegram (webhook alternative)"""
        if not self.active:
            return []
            
        try:
            params = {"timeout": 30}
            if offset:
                params["offset"] = offset
                
            response = requests.get(
                f"{self.base_url}/getUpdates",
                params=params,
                timeout=35
            )
            
            if response.ok:
                return response.json().get('result', [])
            return []
        except Exception as e:
            print(f"[Telegram] Error getting updates: {e}")
            return []
    
    def process_update(self, update: Dict) -> Optional[Dict]:
        """Process Telegram update into Log-Network capture format"""
        message = update.get('message', {})
        
        if not message:
            return None
            
        return {
            'source': {
                'type': 'telegram',
                'chat_id': message.get('chat', {}).get('id'),
                'message_id': message.get('message_id'),
                'from_user': message.get('from', {}).get('username'),
                'chat_type': message.get('chat', {}).get('type')
            },
            'content': {
                'summary': message.get('text', '')[:500],
                'tags': ['telegram', 'chat', 'auto-captured']
            },
            'metadata': {
                'captured_at': datetime.fromtimestamp(message.get('date', 0)).isoformat(),
                'platform': 'telegram'
            }
        }

# Initialize Telegram channel
telegram_channel = TelegramChannel()

# ═══════════════════════════════════════════════════════════
# ASSISTANT TEXT PARSER (OpenClaw-style)
# ═══════════════════════════════════════════════════════════

class AssistantTextParser:
    """
    Parse assistant responses to extract thinking vs final response
    Based on OpenClaw's AssistantTextParser.swift
    """
    
    @staticmethod
    def parse_segments(raw_text: str) -> List[ThinkingSegment]:
        """Parse text into thinking and response segments"""
        trimmed = raw_text.strip()
        
        if not trimmed:
            return []
            
        if '<' not in raw_text:
            return [ThinkingSegment(kind='response', text=trimmed)]
        
        segments = []
        
        # Find all <think> and <final> tags
        think_pattern = r'<think[^>]*>(.*?)</think>'
        final_pattern = r'<final[^>]*>(.*?)</final>'
        
        # Extract thinking blocks
        think_matches = re.finditer(think_pattern, raw_text, re.DOTALL | re.IGNORECASE)
        final_matches = re.finditer(final_pattern, raw_text, re.DOTALL | re.IGNORECASE)
        
        # Combine all matches with positions
        all_matches = []
        
        for match in think_matches:
            all_matches.append({
                'kind': 'thinking',
                'text': match.group(1).strip(),
                'start': match.start(),
                'end': match.end()
            })
        
        for match in final_matches:
            all_matches.append({
                'kind': 'response',
                'text': match.group(1).strip(),
                'start': match.start(),
                'end': match.end()
            })
        
        # Sort by position
        all_matches.sort(key=lambda x: x['start'])
        
        # Add text segments between tags
        last_end = 0
        for match in all_matches:
            # Add text before this tag (if any)
            if match['start'] > last_end:
                between_text = raw_text[last_end:match['start']].strip()
                if between_text:
                    segments.append(ThinkingSegment(kind='response', text=between_text))
            
            # Add the tag content
            if match['text']:
                segments.append(ThinkingSegment(kind=match['kind'], text=match['text']))
            
            last_end = match['end']
        
        # Add remaining text after last tag
        if last_end < len(raw_text):
            remaining = raw_text[last_end:].strip()
            if remaining:
                segments.append(ThinkingSegment(kind='response', text=remaining))
        
        return segments if segments else [ThinkingSegment(kind='response', text=trimmed)]
    
    @staticmethod
    def has_visible_content(raw_text: str) -> bool:
        """Check if text has any visible content"""
        return bool(AssistantTextParser.parse_segments(raw_text))

# ═══════════════════════════════════════════════════════════
# LLM CONFIGURATION
# ═══════════════════════════════════════════════════════════

LLM_CONFIG = {
    'local': {
        'enabled': True,
        'endpoint': 'http://localhost:1234/v1/chat/completions',
        'model': 'local-model',
        'api_key': 'not-needed',
        'supports_thinking': True  # Extended thinking support
    },
    'cloud': {
        'enabled': False,
        'endpoint': 'https://api.openai.com/v1/chat/completions',
        'model': 'gpt-3.5-turbo',
        'api_key': 'your-api-key-here',
        'supports_thinking': False
    },
    'active': 'local'
}

if LLM_CONFIG['local']['enabled']:
    LLM_CONFIG['active'] = 'local'
elif LLM_CONFIG['cloud']['enabled']:
    LLM_CONFIG['active'] = 'cloud'

SUPPORTED_LANGUAGES = ['en', 'ko', 'ja', 'es', 'fr', 'de', 'it', 'pt', 'zh']

# ═══════════════════════════════════════════════════════════
# DATA MANAGEMENT
# ═══════════════════════════════════════════════════════════

DATA_DIR = Path(__file__).parent / 'data'
NODES_FILE = DATA_DIR / 'nodes.json'
SESSIONS_FILE = DATA_DIR / 'sessions.json'

DATA_DIR.mkdir(exist_ok=True)

if not NODES_FILE.exists():
    with open(NODES_FILE, 'w', encoding='utf-8') as f:
        json.dump({
            'nodes': [],
            'metadata': {
                'version': '2.0',
                'created_at': datetime.utcnow().isoformat(),
                'supported_languages': SUPPORTED_LANGUAGES,
                'llm_config': LLM_CONFIG['active'],
                'channels': ['youtube', 'telegram']
            }
        }, f, indent=2, ensure_ascii=False)

if not SESSIONS_FILE.exists():
    with open(SESSIONS_FILE, 'w', encoding='utf-8') as f:
        json.dump({
            'sessions': [],
            'defaults': {
                'model': LLM_CONFIG[LLM_CONFIG['active']]['model'],
                'context_tokens': 8000
            }
        }, f, indent=2, ensure_ascii=False)

def load_nodes():
    with open(NODES_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_nodes(data):
    with open(NODES_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def load_sessions():
    with open(SESSIONS_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_sessions(data):
    with open(SESSIONS_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def calculate_dust_level(timestamp):
    try:
        created = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
        age_hours = (datetime.utcnow() - created.replace(tzinfo=None)).total_seconds() / 3600
        
        if age_hours < 1: return 0.0
        elif age_hours < 24: return 0.2
        elif age_hours < 72: return 0.4
        elif age_hours < 168: return 0.6
        else: return 0.8
    except:
        return 0.0

# ═══════════════════════════════════════════════════════════
# LLM INTEGRATION WITH THINKING SUPPORT
# ═══════════════════════════════════════════════════════════

def call_llm(prompt: str, system_message: str = "You are a helpful assistant.", 
             enable_thinking: bool = False) -> Dict[str, Any]:
    """
    Call LLM with optional extended thinking support
    Returns dict with 'text', 'thinking', and 'segments'
    """
    config = LLM_CONFIG[LLM_CONFIG['active']]
    
    try:
        headers = {'Content-Type': 'application/json'}
        
        if LLM_CONFIG['active'] == 'cloud':
            headers['Authorization'] = f"Bearer {config['api_key']}"
        
        # Enhance prompt for thinking if supported
        if enable_thinking and config.get('supports_thinking'):
            system_message += "\n\nYou can use <think>...</think> tags for your reasoning process and <final>...</final> for your final answer."
        
        payload = {
            'model': config['model'],
            'messages': [
                {'role': 'system', 'content': system_message},
                {'role': 'user', 'content': prompt}
            ],
            'temperature': 0.7,
            'max_tokens': 1000
        }
        
        response = requests.post(
            config['endpoint'],
            headers=headers,
            json=payload,
            timeout=30
        )
        
        if response.ok:
            result = response.json()
            raw_text = result['choices'][0]['message']['content']
            
            # Parse thinking segments
            segments = AssistantTextParser.parse_segments(raw_text)
            
            # Extract pure thinking and response
            thinking_parts = [s.text for s in segments if s.kind == 'thinking']
            response_parts = [s.text for s in segments if s.kind == 'response']
            
            return {
                'success': True,
                'text': '\n\n'.join(response_parts) if response_parts else raw_text,
                'thinking': '\n\n'.join(thinking_parts) if thinking_parts else None,
                'segments': [{'kind': s.kind, 'text': s.text} for s in segments],
                'raw': raw_text
            }
        else:
            print(f"[LLM] Error: {response.status_code} - {response.text}")
            return {'success': False, 'text': None, 'thinking': None}
            
    except Exception as e:
        print(f"[LLM] Exception: {str(e)}")
        return {'success': False, 'text': None, 'thinking': None}

def generate_smart_summary(node_data: Dict, enable_thinking: bool = False) -> Dict:
    """Generate summary with optional thinking process"""
    if not (LLM_CONFIG['local']['enabled'] or LLM_CONFIG['cloud']['enabled']):
        return {
            'summary': node_data.get('content', {}).get('summary', ''),
            'thinking': None
        }
    
    title = node_data.get('source', {}).get('title', 'Unknown')
    description = node_data.get('content', {}).get('description_preview', '')
    
    prompt = f"""Summarize this content in 1-2 concise sentences:
    
Title: {title}
Description: {description[:300]}

Focus on the main topic and key insights."""
    
    system_prompt = "You are a concise summarization assistant."
    
    result = call_llm(prompt, system_prompt, enable_thinking=enable_thinking)
    
    return {
        'summary': result.get('text') if result.get('success') else node_data.get('content', {}).get('summary', ''),
        'thinking': result.get('thinking'),
        'segments': result.get('segments', [])
    }

# ═══════════════════════════════════════════════════════════
# API ENDPOINTS - OPENCLAW COMPATIBLE
# ═══════════════════════════════════════════════════════════

@app.route('/')
def index():
    return send_from_directory('../frontend', 'index.html')

@app.route('/api/health', methods=['GET'])
def health():
    """OpenClaw-style health check"""
    data = load_nodes()
    
    languages_in_use = set()
    for node in data.get('nodes', []):
        lang = node.get('source_metadata', {}).get('language', 'en')
        languages_in_use.add(lang)
    
    return jsonify({
        'ok': True,
        'status': 'online',
        'nodes': len(data['nodes']),
        'version': '2.0.0',
        'timestamp': datetime.utcnow().isoformat(),
        'llm_mode': LLM_CONFIG['active'],
        'llm_available': LLM_CONFIG['local']['enabled'] or LLM_CONFIG['cloud']['enabled'],
        'thinking_enabled': LLM_CONFIG[LLM_CONFIG['active']].get('supports_thinking', False),
        'supported_languages': SUPPORTED_LANGUAGES,
        'languages': list(languages_in_use),
        'channels': {
            'youtube': True,
            'telegram': telegram_channel.active
        }
    })

@app.route('/api/capture', methods=['POST'])
def capture():
    """Multi-channel capture endpoint with thinking support"""
    try:
        capture_data = request.json
        node_id = str(uuid.uuid4())
        
        detected_language = capture_data.get('source', {}).get('language', 'en')
        channel_type = capture_data.get('source', {}).get('type', 'unknown')
        
        # Generate AI summary with thinking if enabled
        enable_thinking = LLM_CONFIG[LLM_CONFIG['active']].get('supports_thinking', False)
        ai_result = generate_smart_summary(capture_data, enable_thinking=enable_thinking)
        
        node = {
            'node_id': node_id,
            'parent_id': None,
            'timestamp': capture_data.get('metadata', {}).get('captured_at', datetime.utcnow().isoformat()),
            'source_metadata': capture_data.get('source', {}),
            'content_summary': ai_result['summary'],
            'tags': capture_data.get('content', {}).get('tags', []),
            'context_snapshot': {
                'last_interaction': ai_result['summary'],
                'brain_state': 'Initial capture',
                'thinking_process': ai_result.get('thinking'),  # OpenClaw-style thinking
                'segments': ai_result.get('segments', []),
                'metadata': capture_data.get('metadata', {}),
                'llm_mode': LLM_CONFIG['active']
            },
            'visual_state': {
                'dust_level': 0.0,
                'opacity': 1.0,
                'color': '#667eea'
            },
            'i18n': {
                'detected_language': detected_language,
                'content_language': detected_language,
                'supported_translations': [],
                'title_translations': {},
                'summary_translations': {}
            }
        }
        
        data = load_nodes()
        
        # Auto-branching
        if data['nodes']:
            best_match = None
            best_score = 0
            
            for existing_node in data['nodes']:
                existing_tags = set(existing_node.get('tags', []))
                new_tags = set(node['tags'])
                
                if existing_tags or new_tags:
                    intersection = len(existing_tags & new_tags)
                    union = len(existing_tags | new_tags)
                    similarity = intersection / union if union > 0 else 0
                    
                    if similarity > best_score and similarity > 0.3:
                        best_score = similarity
                        best_match = existing_node['node_id']
            
            if best_match:
                node['parent_id'] = best_match
        
        data['nodes'].append(node)
        data['metadata']['last_updated'] = datetime.utcnow().isoformat()
        data['metadata']['total_nodes'] = len(data['nodes'])
        
        save_nodes(data)
        
        print(f"[Log-Network] ✅ Captured [{channel_type}] [{detected_language}]: {node['source_metadata'].get('title', 'Unknown')}")
        
        return jsonify({
            'success': True,
            'node_id': node_id,
            'message': 'Node captured successfully',
            'parent_id': node['parent_id'],
            'language': detected_language,
            'ai_enhanced': bool(ai_result['thinking']),
            'thinking_available': bool(ai_result.get('thinking')),
            'channel': channel_type
        }), 201
        
    except Exception as e:
        print(f"[Log-Network] ❌ Error: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/nodes', methods=['GET'])
def get_nodes():
    """Get all nodes with dust levels and thinking data"""
    data = load_nodes()
    
    for node in data['nodes']:
        node['visual_state']['dust_level'] = calculate_dust_level(node['timestamp'])
        node['visual_state']['opacity'] = 1.0 - (node['visual_state']['dust_level'] * 0.5)
    
    return jsonify(data)

@app.route('/api/nodes/<node_id>', methods=['GET'])
def get_node(node_id):
    """Get specific node with full thinking process"""
    data = load_nodes()
    node = next((n for n in data['nodes'] if n['node_id'] == node_id), None)
    
    if not node:
        return jsonify({'error': 'Node not found'}), 404
    
    node['visual_state']['dust_level'] = calculate_dust_level(node['timestamp'])
    
    return jsonify(node)

@app.route('/api/nodes/<node_id>/thinking', methods=['GET'])
def get_thinking(node_id):
    """Get thinking process for a node (OpenClaw-inspired)"""
    data = load_nodes()
    node = next((n for n in data['nodes'] if n['node_id'] == node_id), None)
    
    if not node:
        return jsonify({'error': 'Node not found'}), 404
    
    thinking = node.get('context_snapshot', {}).get('thinking_process')
    segments = node.get('context_snapshot', {}).get('segments', [])
    
    return jsonify({
        'node_id': node_id,
        'has_thinking': bool(thinking),
        'thinking': thinking,
        'segments': segments,
        'timestamp': node['timestamp']
    })

@app.route('/api/nodes/<node_id>/context', methods=['GET'])
def get_context(node_id):
    """Context injection with thinking process"""
    data = load_nodes()
    node = next((n for n in data['nodes'] if n['node_id'] == node_id), None)
    
    if not node:
        return jsonify({'error': 'Node not found'}), 404
    
    language = node.get('i18n', {}).get('detected_language', 'en')
    thinking = node.get('context_snapshot', {}).get('thinking_process', '')
    
    context_prompt = f"""[CONTEXT INJECTION - Previous Session]

Language: {language.upper()}
Source: {node['source_metadata'].get('type', 'unknown').upper()}
Title: {node['source_metadata'].get('title', 'Unknown')}
URL: {node['source_metadata'].get('url', 'N/A')}

Summary: {node['content_summary']}

Tags: {', '.join(node['tags'])}
"""
    
    if thinking:
        context_prompt += f"""
Previous Thinking Process:
{thinking}
"""
    
    context_prompt += f"""
Previous Brain State:
{node['context_snapshot'].get('brain_state', 'No previous context')}

---
Please continue our conversation from this context. Consider the language context ({language}) when responding.
"""
    
    return jsonify({
        'node_id': node_id,
        'context_prompt': context_prompt,
        'raw_snapshot': node['context_snapshot'],
        'language': language,
        'has_thinking': bool(thinking),
        'copy_ready': True
    })

@app.route('/api/stats', methods=['GET'])
def get_stats():
    """Dashboard statistics with channel breakdown"""
    data = load_nodes()
    nodes = data['nodes']
    
    total_nodes = len(nodes)
    youtube_nodes = len([n for n in nodes if n['source_metadata'].get('type') == 'youtube'])
    telegram_nodes = len([n for n in nodes if n['source_metadata'].get('type') == 'telegram'])
    dusty_nodes = len([n for n in nodes if calculate_dust_level(n['timestamp']) > 0.5])
    
    # Thinking-enhanced nodes
    thinking_nodes = len([n for n in nodes if n.get('context_snapshot', {}).get('thinking_process')])
    
    language_counts = {}
    for node in nodes:
        lang = node.get('i18n', {}).get('detected_language', 'en')
        language_counts[lang] = language_counts.get(lang, 0) + 1
    
    return jsonify({
        'total_nodes': total_nodes,
        'youtube_captures': youtube_nodes,
        'telegram_captures': telegram_nodes,
        'dusty_nodes': dusty_nodes,
        'thinking_enhanced': thinking_nodes,
        'last_capture': nodes[-1]['timestamp'] if nodes else None,
        'language_distribution': language_counts,
        'llm_mode': LLM_CONFIG['active'],
        'supported_languages': SUPPORTED_LANGUAGES,
        'channels': {
            'youtube': youtube_nodes,
            'telegram': telegram_nodes
        }
    })

# ═══════════════════════════════════════════════════════════
# TELEGRAM WEBHOOK ENDPOINTS
# ═══════════════════════════════════════════════════════════

@app.route('/api/telegram/webhook', methods=['POST'])
def telegram_webhook():
    """Telegram webhook endpoint"""
    if not telegram_channel.active:
        return jsonify({'error': 'Telegram not configured'}), 400
    
    try:
        update = request.json
        capture_data = telegram_channel.process_update(update)
        
        if capture_data:
            # Forward to capture endpoint
            response = requests.post(
                'http://localhost:5000/api/capture',
                json=capture_data
            )
            return jsonify({'success': True, 'captured': response.ok})
        
        return jsonify({'success': True, 'captured': False})
        
    except Exception as e:
        print(f"[Telegram Webhook] Error: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/telegram/send', methods=['POST'])
def telegram_send():
    """Send message via Telegram"""
    if not telegram_channel.active:
        return jsonify({'error': 'Telegram not configured'}), 400
    
    data = request.json
    chat_id = data.get('chat_id')
    text = data.get('text')
    
    if not chat_id or not text:
        return jsonify({'error': 'Missing chat_id or text'}), 400
    
    success = telegram_channel.send_message(chat_id, text)
    
    return jsonify({'success': success})

@app.route('/api/llm/test', methods=['POST'])
def test_llm():
    """Test LLM with thinking support"""
    test_prompt = request.json.get('prompt', 'Hello, are you working?')
    enable_thinking = request.json.get('enable_thinking', False)
    
    result = call_llm(test_prompt, enable_thinking=enable_thinking)
    
    return jsonify({
        'success': result.get('success'),
        'mode': LLM_CONFIG['active'],
        'response': result.get('text'),
        'thinking': result.get('thinking'),
        'segments': result.get('segments'),
        'endpoint': LLM_CONFIG[LLM_CONFIG['active']]['endpoint'],
        'thinking_enabled': enable_thinking
    })

# ═══════════════════════════════════════════════════════════
# SERVER STARTUP
# ═══════════════════════════════════════════════════════════

if __name__ == '__main__':
    telegram_status = "✅ Active" if telegram_channel.active else "❌ Disabled (set TELEGRAM_BOT_TOKEN)"
    
    print(f"""
    ╔═══════════════════════════════════════════════════════════╗
    ║                                                           ║
    ║         🧠 LOG-NETWORK v2.0 - OPENCLAW EDITION            ║
    ║                                                           ║
    ║         KIVOSY Global Empire - Premium Architecture       ║
    ║                                                           ║
    ╚═══════════════════════════════════════════════════════════╝
    
    Server running at: http://localhost:5000
    
    🔧 Configuration:
       • LLM Mode: {LLM_CONFIG['active'].upper()} ({LLM_CONFIG[LLM_CONFIG['active']]['endpoint']})
       • Thinking: {LLM_CONFIG[LLM_CONFIG['active']].get('supports_thinking', False)}
       • Multilingual: {len(SUPPORTED_LANGUAGES)} languages
       • Channels: YouTube ✅ | Telegram {telegram_status}
    
    📡 API Endpoints (OpenClaw-Compatible):
       • GET  /api/health              - System status
       • POST /api/capture             - Multi-channel capture
       • GET  /api/nodes               - All nodes with thinking
       • GET  /api/nodes/<id>          - Specific node
       • GET  /api/nodes/<id>/thinking - Thinking process view
       • GET  /api/nodes/<id>/context  - Context injection
       • GET  /api/stats               - Dashboard stats
       • POST /api/llm/test            - Test LLM + thinking
       • POST /api/telegram/webhook    - Telegram webhook
       • POST /api/telegram/send       - Send Telegram message
    
    Frontend Dashboard: http://localhost:5000
    
    Ready to capture your multilingual, multi-channel digital life! 🚀
    """)
    
    app.run(host='localhost', port=5000, debug=True)
