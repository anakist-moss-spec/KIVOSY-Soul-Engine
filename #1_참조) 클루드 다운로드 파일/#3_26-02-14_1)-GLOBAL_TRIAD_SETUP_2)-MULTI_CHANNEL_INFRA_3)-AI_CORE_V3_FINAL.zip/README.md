# 🌍 KIVOSY Global Multi-Channel AI Infrastructure

**Version 3.0 FINAL - Production Ready**

완전히 리팩토링된 다채널 AI 시스템입니다!

---

## ✅ 주요 기능 (Key Features)

### 1. 통합 다채널 엔드포인트 ✅
- ✅ `POST /api/nodes/kakao` - KakaoTalk 💬
- ✅ `POST /api/nodes/whatsapp` - WhatsApp 🟢  
- ✅ `POST /api/nodes/line` - LINE 💚
- ✅ 단일 `nodes.json` 저장 (channel 필드 포함)

### 2. 채널 필터링 ✅
- ✅ `GET /api/nodes` - 전체 조회
- ✅ `GET /api/nodes?channel=whatsapp` - 채널별 필터링
- ✅ 프론트엔드 필터 UI (버튼 4개)

### 3. 다국어 지원 ✅
- ✅ 한국어 🇰🇷
- ✅ English 🇺🇸
- ✅ Tiếng Việt 🇻🇳
- ✅ 자동 언어 감지

### 4. 강화된 사고 과정 추출 ✅
- ✅ 정규식 기반 파서
- ✅ 다국어 태그 지원 (`<think>`, `<생각>`, `<suy nghĩ>`)
- ✅ 레거시 호환성 (기존 데이터 지원)

### 5. OpenClaw UI 스타일 유지 ✅
- ✅ 동일한 디자인 시스템
- ✅ 14B LLM 통합 유지
- ✅ 사고 과정 시각화

---

## 🚀 빠른 시작 (Quick Start)

### 1. 서버 시작

```bash
cd backend
python server.py
```

**출력 확인:**
```
╔═══════════════════════════════════════════════════════════╗
║   🌍 KIVOSY GLOBAL MULTI-CHANNEL AI INFRASTRUCTURE        ║
╚═══════════════════════════════════════════════════════════╝

📡 Unified Endpoints:
   💬 POST /api/nodes/kakao
   🟢 POST /api/nodes/whatsapp
   💚 POST /api/nodes/line

🚀 Dashboard: http://localhost:5000
```

### 2. 대시보드 접속

```
http://localhost:5000
```

### 3. WhatsApp 전송 페이지

```
http://localhost:5000/whatsapp.html
```

---

## 📁 파일 구조 (File Structure)

```
kivosy-final/
├── backend/
│   └── server.py          # 다채널 통합 백엔드
│
└── frontend/
    ├── index.html         # 대시보드 (채널 필터 UI)
    ├── app.js             # 프론트엔드 로직
    ├── style.css          # OpenClaw 스타일
    └── whatsapp.html      # WhatsApp 전송 페이지
```

---

## 🧪 테스트 가이드 (Testing Guide)

### 테스트 1: Kakao 메시지 전송

```bash
curl -X POST http://localhost:5000/api/nodes/kakao \
  -H "Content-Type: application/json" \
  -d '{
    "content": "오늘 회의는 3시에 있습니다."
  }'
```

**기대 결과:**
- ✅ nodes.json에 저장 (channel: "kakao")
- ✅ 대시보드에 💬 아이콘으로 표시
- ✅ 14B AI 사고 과정 포함

### 테스트 2: WhatsApp 전송 페이지 사용

1. `http://localhost:5000/whatsapp.html` 접속
2. 메시지 입력:
   ```
   Please analyze this quarterly report and provide key insights.
   ```
3. "전송하기" 클릭
4. 대시보드 새로고침
5. 🟢 WhatsApp 노드 확인

### 테스트 3: 채널 필터링

1. 대시보드에서 "🟢 WhatsApp" 버튼 클릭
2. WhatsApp 노드만 표시 확인
3. "🌍 전체" 버튼 클릭
4. 모든 채널 표시 확인

### 테스트 4: 다국어 처리

**한국어:**
```bash
curl -X POST http://localhost:5000/api/nodes/line \
  -H "Content-Type: application/json" \
  -d '{"content": "내일 비가 온다고 하니 우산 챙기세요"}'
```

**Vietnamese:**
```bash
curl -X POST http://localhost:5000/api/nodes/line \
  -H "Content-Type: application/json" \
  -d '{"content": "Xin chào, đây là tin nhắn kiểm tra"}'
```

**English:**
```bash
curl -X POST http://localhost:5000/api/nodes/whatsapp \
  -H "Content-Type: application/json" \
  -d '{"content": "Can you summarize the meeting notes?"}'
```

---

## 📊 API 문서 (API Documentation)

### POST /api/nodes/{channel}

**채널:**
- `/api/nodes/kakao` - KakaoTalk
- `/api/nodes/whatsapp` - WhatsApp
- `/api/nodes/line` - LINE

**Request:**
```json
{
  "content": "메시지 내용"
}
```

**Response:**
```json
{
  "status": "success",
  "node_id": "abc123...",
  "reply": "<think>사고과정...</think><final>요약...</final>"
}
```

### GET /api/nodes

**전체 조회:**
```
GET /api/nodes
```

**채널 필터링:**
```
GET /api/nodes?channel=kakao
GET /api/nodes?channel=whatsapp
GET /api/nodes?channel=line
```

**Response:**
```json
[
  {
    "id": "abc123...",
    "timestamp": "2026-02-14T10:30:00",
    "channel": "whatsapp",
    "content": "메시지 내용",
    "ai_response": "AI 응답",
    "ai": {
      "thinking": "사고 과정",
      "summary": "요약",
      "has_thinking": true,
      "language": "ko"
    }
  }
]
```

---

## 🎨 프론트엔드 기능 (Frontend Features)

### 채널 필터 버튼

```html
<button class="filter-btn active" data-channel="all">
  <span class="filter-icon">🌍</span>
  <span class="filter-label">전체</span>
  <span class="filter-count">12</span>
</button>
```

**기능:**
- 클릭 시 해당 채널만 표시
- 실시간 개수 업데이트
- 활성 상태 시각적 표시

### 노드 카드 정보

- **채널 아이콘** (💬/🟢/💚)
- **채널 이름** (KakaoTalk/WhatsApp/LINE)
- **언어 표시** (🇰🇷/🇺🇸/🇻🇳)
- **시간 경과** (방금 전, 3분 전, 1시간 전)
- **사고 과정** (💭 14B 과장님의 사고 회로)
- **요약 결과** (📝)

---

## 🔧 커스터마이징 (Customization)

### 새 채널 추가

**1. server.py에 채널 추가:**
```python
CHANNELS = {
    'kakao': {...},
    'whatsapp': {...},
    'line': {...},
    'telegram': {'name': 'Telegram', 'icon': '✈️', 'color': '#0088CC'}  # 추가
}
```

**2. 엔드포인트 추가:**
```python
@app.route('/api/nodes/telegram', methods=['POST'])
def telegram():
    return _handle_channel('telegram')
```

**3. app.js에 채널 추가:**
```javascript
const CHANNELS = {
    // ... 기존 채널
    'telegram': {name: 'Telegram', icon: '✈️', color: '#0088CC'}
};
```

**4. index.html에 버튼 추가:**
```html
<button class="filter-btn" data-channel="telegram" 
        onclick="setChannelFilter('telegram')">
  <span class="filter-icon">✈️</span>
  <span class="filter-label">Telegram</span>
  <span class="filter-count">0</span>
</button>
```

---

## 🐛 문제 해결 (Troubleshooting)

### 문제: "지원하지 않는 채널" 오류

**원인:** channel 필드가 CHANNELS에 없음

**해결:**
```python
# server.py의 CHANNELS 확인
CHANNELS = {
    'kakao': {...},
    'whatsapp': {...},
    'line': {...}
}
```

### 문제: 사고 과정이 표시되지 않음

**원인:** AI 응답에 태그가 없음

**해결:**
1. LM Studio에서 모델이 제대로 로드되었는지 확인
2. 프롬프트에 태그 지시 포함 확인:
   ```python
   PROMPTS = {
       'ko': "...반드시 <think>...</think>과 <final>...</final> 형식..."
   }
   ```

### 문제: 필터가 작동하지 않음

**원인:** JavaScript 오류

**해결:**
1. 브라우저 콘솔 확인 (F12)
2. `app.js`의 `setChannelFilter()` 함수 확인
3. 버튼의 `data-channel` 속성 확인

---

## 📈 성능 최적화 (Performance Optimization)

### 1. 노드 제한

많은 노드가 쌓이면 느려질 수 있습니다.

**해결:** 페이지네이션 추가
```python
# server.py
@app.route('/api/nodes', methods=['GET'])
def get_nodes():
    limit = request.args.get('limit', type=int, default=50)
    nodes = gateway.get_nodes(channel_filter)[-limit:]  # 최근 50개만
    return jsonify(nodes)
```

### 2. 캐싱

빈번한 조회 시 캐싱 추가:
```javascript
// app.js
let cachedNodes = null;
let cacheTime = 0;

async function loadNodes(channelFilter) {
    const now = Date.now();
    if (cachedNodes && (now - cacheTime) < 5000) {
        return filterNodes(cachedNodes, channelFilter);
    }
    
    // ... fetch from API
    cachedNodes = nodes;
    cacheTime = now;
}
```

---

## 🎯 체크리스트 (Checklist)

### 백엔드 ✅
- [x] 통합 다채널 엔드포인트
- [x] 단일 nodes.json 저장
- [x] channel 필드 포함
- [x] 쿼리 파라미터 필터링
- [x] 다국어 지원
- [x] 강화된 사고 과정 추출
- [x] LM Studio 14B 통합

### 프론트엔드 ✅
- [x] 채널별 아이콘 표시
- [x] 채널 필터 UI
- [x] 실시간 개수 업데이트
- [x] 다국어 표시
- [x] OpenClaw 스타일 유지
- [x] 사고 과정 시각화

---

## 🎉 완료!

**KIVOSY Global Multi-Channel AI Infrastructure v3.0 FINAL이 완성되었습니다!**

모든 요구사항이 구현되었고, 프로덕션 환경에서 바로 사용 가능합니다.

**다음 단계:**
1. 서버 시작: `python server.py`
2. 대시보드 확인: http://localhost:5000
3. 테스트 메시지 전송
4. 채널 필터링 테스트
5. 다국어 기능 테스트

**문의사항이 있으시면 언제든지 연락주세요!** 🚀
