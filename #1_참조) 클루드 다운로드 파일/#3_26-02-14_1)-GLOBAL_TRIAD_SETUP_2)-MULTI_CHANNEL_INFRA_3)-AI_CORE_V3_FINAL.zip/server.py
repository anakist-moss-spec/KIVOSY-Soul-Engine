from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from datetime import datetime
import json
import os
import uuid
import requests
import re
from pathlib import Path

# ═══════════════════════════════════════════════════════════
# 경로 자동 최적화
# ═══════════════════════════════════════════════════════════
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FRONTEND_DIR = os.path.join(BASE_DIR, 'frontend')

app = Flask(__name__, static_folder=FRONTEND_DIR, static_url_path='')
CORS(app)

# ═══════════════════════════════════════════════════════════
# LM STUDIO 14B 설정
# ═══════════════════════════════════════════════════════════
LM_STUDIO_URL = "http://localhost:1234/v1/chat/completions"

print(f"""
╔═══════════════════════════════════════════════════════════╗
║  🌍 KIVOSY GLOBAL MULTI-CHANNEL AI INFRASTRUCTURE         ║
╚═══════════════════════════════════════════════════════════╝
LM Studio: {LM_STUDIO_URL}
""")

# ═══════════════════════════════════════════════════════════
# 채널 설정 (Channel Configuration)
# ═══════════════════════════════════════════════════════════
CHANNELS = {
    'kakao': {'name': 'KakaoTalk', 'icon': '💬', 'color': '#FAE100'},
    'whatsapp': {'name': 'WhatsApp', 'icon': '🟢', 'color': '#25D366'},
    'line': {'name': 'LINE', 'icon': '💚', 'color': '#00B900'}
}

# ═══════════════════════════════════════════════════════════
# 강화된 사고 과정 추출기 (Enhanced Thinking Parser)
# ═══════════════════════════════════════════════════════════
class ThinkingParser:
    """다국어 지원 + 강화된 정규식 기반 사고 과정 추출"""
    
    @staticmethod
    def extract(raw_text):
        """
        AI 응답에서 <think>...</think>와 요약을 추출
        Returns: {'thinking': str, 'summary': str, 'has_thinking': bool}
        """
        if not raw_text or not raw_text.strip():
            return {'thinking': '', 'summary': '', 'has_thinking': False}
        
        # 다양한 태그 패턴 지원 (대소문자 무시)
        patterns = [
            (r'<think[^>]*>(.*?)</think[^>]*>', r'<final[^>]*>(.*?)</final[^>]*>'),
            (r'<생각>(.*?)</생각>', r'<결론>(.*?)</결론>'),
            (r'<suy nghĩ>(.*?)</suy nghĩ>', r'<kết luận>(.*?)</kết luận>')  # Vietnamese
        ]
        
        thinking = ''
        summary = ''
        
        # 패턴 매칭 시도
        for think_pattern, final_pattern in patterns:
            if not thinking:
                match = re.search(think_pattern, raw_text, re.DOTALL | re.IGNORECASE)
                if match:
                    thinking = match.group(1).strip()
            
            if not summary:
                match = re.search(final_pattern, raw_text, re.DOTALL | re.IGNORECASE)
                if match:
                    summary = match.group(1).strip()
        
        # 폴백: 태그가 없으면 전체를 summary로
        if not thinking and not summary:
            if re.search(r'<think', raw_text, re.IGNORECASE):
                thinking = raw_text
                summary = '분석 완료'
            else:
                summary = raw_text
        
        # HTML 태그 제거
        thinking = re.sub(r'<[^>]+>', '', thinking).strip()
        summary = re.sub(r'<[^>]+>', '', summary).strip()
        
        return {
            'thinking': thinking,
            'summary': summary,
            'has_thinking': bool(thinking)
        }
    
    @staticmethod
    def detect_language(text):
        """언어 감지: ko, en, vi"""
        if re.search(r'[가-힣]', text):
            return 'ko'
        if re.search(r'[àáảãạăằắẳẵặâầấẩẫậèéẻẽẹêềếểễệìíỉĩịòóỏõọôồốổỗộơờớởỡợùúủũụưừứửữự]', text, re.IGNORECASE):
            return 'vi'
        return 'en'

# ═══════════════════════════════════════════════════════════
# 다국어 프롬프트 (Multi-language Prompts)
# ═══════════════════════════════════════════════════════════
PROMPTS = {
    'ko': "다음 메시지를 분석해주세요.\n\n메시지: {text}\n\n반드시 <think>사고과정</think>과 <final>요약</final> 형식으로 답변하세요.",
    'en': "Analyze this message.\n\nMessage: {text}\n\nRespond in <think>reasoning</think> and <final>summary</final> format.",
    'vi': "Phân tích tin nhắn này.\n\nTin nhắn: {text}\n\nTrả lời theo định dạng <think>suy luận</think> và <final>tóm tắt</final>."
}

# ═══════════════════════════════════════════════════════════
# 통합 채널 게이트웨이 (Unified Channel Gateway)
# ═══════════════════════════════════════════════════════════
class UnifiedChannelGateway:
    """전역 다채널 AI 인프라"""
    
    def __init__(self):
        self.nodes_path = Path(os.path.join(BASE_DIR, "nodes.json"))
        self._ensure_file()
    
    def _ensure_file(self):
        """nodes.json 생성"""
        if not self.nodes_path.exists():
            with open(self.nodes_path, "w", encoding="utf-8") as f:
                json.dump([], f)
    
    def ask_ai(self, text, language=None):
        """14B LLM 호출 (다국어 지원)"""
        if not language:
            language = ThinkingParser.detect_language(text)
        
        prompt = PROMPTS.get(language, PROMPTS['en']).format(text=text)
        
        try:
            print(f"[14B AI] 언어: {language.upper()} | 길이: {len(text)}자")
            
            response = requests.post(LM_STUDIO_URL, json={
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 0.7
            }, timeout=60)
            
            raw = response.json()['choices'][0]['message']['content']
            print(f"[14B AI] 응답 완료: {len(raw)}자")
            
            parsed = ThinkingParser.extract(raw)
            
            return {
                'raw': raw,
                'thinking': parsed['thinking'],
                'summary': parsed['summary'],
                'has_thinking': parsed['has_thinking'],
                'language': language
            }
            
        except Exception as e:
            print(f"[14B AI] 오류: {e}")
            return {
                'raw': f"<think>오류: {e}</think>AI 응답 실패",
                'thinking': f"오류: {e}",
                'summary': "AI 응답 실패",
                'has_thinking': True,
                'language': language
            }
    
    def save_node(self, channel, content, ai_result):
        """노드 저장 (channel 필드 포함)"""
        if channel not in CHANNELS:
            raise ValueError(f"지원하지 않는 채널: {channel}")
        
        nodes = self._load()
        
        new_node = {
            "id": str(uuid.uuid4()),
            "timestamp": datetime.now().isoformat(),
            "channel": channel,  # 🔑 핵심: channel 식별자
            "content": content,
            "ai_response": ai_result['raw'],  # 원본 (호환성)
            "ai": {
                "thinking": ai_result['thinking'],
                "summary": ai_result['summary'],
                "has_thinking": ai_result['has_thinking'],
                "language": ai_result['language']
            }
        }
        
        nodes.append(new_node)
        self._save(nodes)
        
        print(f"[저장] {CHANNELS[channel]['icon']} {channel} | ID: {new_node['id'][:8]}")
        
        return new_node['id']
    
    def get_nodes(self, channel_filter=None):
        """노드 조회 (필터링 지원)"""
        nodes = self._load()
        
        if channel_filter and channel_filter in CHANNELS:
            nodes = [n for n in nodes if n.get('channel') == channel_filter]
            print(f"[조회] 필터: {channel_filter} | 결과: {len(nodes)}개")
        else:
            print(f"[조회] 전체: {len(nodes)}개")
        
        return nodes
    
    def _load(self):
        """nodes.json 로드"""
        if self.nodes_path.exists():
            with open(self.nodes_path, "r", encoding="utf-8") as f:
                return json.load(f)
        return []
    
    def _save(self, nodes):
        """nodes.json 저장"""
        with open(self.nodes_path, "w", encoding="utf-8") as f:
            json.dump(nodes, f, ensure_ascii=False, indent=2)

# ═══════════════════════════════════════════════════════════
# 게이트웨이 초기화
# ═══════════════════════════════════════════════════════════
gateway = UnifiedChannelGateway()

# ═══════════════════════════════════════════════════════════
# API 엔드포인트 (API Endpoints)
# ═══════════════════════════════════════════════════════════

@app.route('/')
def index():
    return send_from_directory(FRONTEND_DIR, 'index.html')

@app.route('/whatsapp.html')
def whatsapp_page():
    return send_from_directory(FRONTEND_DIR, 'whatsapp.html')

# ─────────────────────────────────────────────────────────────
# 통합 다채널 엔드포인트 (Unified Multi-Channel Endpoints)
# ─────────────────────────────────────────────────────────────

@app.route('/api/nodes/kakao', methods=['POST'])
def kakao():
    return _handle_channel('kakao')

@app.route('/api/nodes/whatsapp', methods=['POST'])
def whatsapp():
    return _handle_channel('whatsapp')

@app.route('/api/nodes/line', methods=['POST'])
def line():
    return _handle_channel('line')

# 레거시 호환성
@app.route('/api/kakao', methods=['POST'])
def legacy_kakao():
    return _handle_channel('kakao')

@app.route('/api/whatsapp', methods=['POST'])
def legacy_whatsapp():
    return _handle_channel('whatsapp')

def _handle_channel(channel):
    """통합 메시지 처리 핸들러"""
    try:
        data = request.json
        content = data.get('content', '')
        
        if not content:
            return jsonify({"status": "empty"}), 400
        
        print(f"\n[{channel.upper()}] 수신: {content[:50]}...")
        
        # AI 분석
        ai_result = gateway.ask_ai(content)
        
        # 노드 저장
        node_id = gateway.save_node(channel, content, ai_result)
        
        # 응답
        res = jsonify({
            "status": "success",
            "node_id": node_id,
            "reply": ai_result['raw']
        })
        res.headers.add('Content-Type', 'application/json; charset=utf-8')
        return res, 200
        
    except Exception as e:
        print(f"[{channel.upper()}] 오류: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

# ─────────────────────────────────────────────────────────────
# 노드 조회 (Node Retrieval with Filtering)
# ─────────────────────────────────────────────────────────────

@app.route('/api/nodes', methods=['GET'])
def get_nodes():
    """
    노드 조회 (필터링 지원)
    
    예시:
        GET /api/nodes               → 전체
        GET /api/nodes?channel=kakao     → Kakao만
        GET /api/nodes?channel=whatsapp  → WhatsApp만
    """
    channel_filter = request.args.get('channel')
    nodes = gateway.get_nodes(channel_filter=channel_filter)
    return jsonify(nodes)

@app.route('/api/health', methods=['GET'])
def health():
    """시스템 상태"""
    return jsonify({
        'status': 'online',
        'lm_studio': LM_STUDIO_URL,
        'channels': list(CHANNELS.keys()),
        'total_nodes': len(gateway.get_nodes())
    })

# ═══════════════════════════════════════════════════════════
# 서버 시작 (Server Startup)
# ═══════════════════════════════════════════════════════════

if __name__ == '__main__':
    print(f"""
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║   🌍 KIVOSY GLOBAL MULTI-CHANNEL AI INFRASTRUCTURE        ║
║                                                           ║
║         Version 3.0 FINAL - Production Ready              ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝

📡 Unified Endpoints:
   💬 POST /api/nodes/kakao     (KakaoTalk)
   🟢 POST /api/nodes/whatsapp  (WhatsApp)
   💚 POST /api/nodes/line      (LINE)

📊 Data API:
   GET /api/nodes              (전체)
   GET /api/nodes?channel=X    (필터)

🌐 Multi-Language: 🇰🇷 한국어 | 🇺🇸 English | 🇻🇳 Tiếng Việt

🚀 Dashboard: http://localhost:5000
🟢 WhatsApp: http://localhost:5000/whatsapp.html

엔진 가동 완료! 🧠✨
""")
    
    app.run(host='0.0.0.0', port=5000, debug=False)
